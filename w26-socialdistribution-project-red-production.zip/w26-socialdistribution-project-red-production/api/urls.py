from django.urls import path
from api.views.authors import authors_list, author_detail
from api.views.entries import entries_list, entry_detail, entry_by_fqid
from api.views.image import entry_image, entry_image_by_fqid
from api.views.followers import followers_list, follower_detail
from api.views.following import following_list, following_detail
from api.views.follow_request import follow_requests_list
from api.views.comments import entry_comments,comment_likes,my_comment_like
from api.views.likes import entry_likes, my_entry_like
from api.views.inbox import author_inbox

from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView, SpectacularRedocView

urlpatterns = [
    # AUTHORS
    path("authors/", authors_list, name="api_authors_list"),
    path("authors", authors_list, name="api_authors_list_noslash"),

    path("authors/<uuid:author_uuid>/", author_detail, name="api_author_detail"),
    path("authors/<uuid:author_uuid>", author_detail, name="api_author_detail_noslash"),

    # ENTRIES
    path("authors/<uuid:author_uuid>/entries/", entries_list, name="api_entries_list"),
    path("authors/<uuid:author_uuid>/entries", entries_list, name="api_entries_list_noslash"),

    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/", entry_detail, name="api_entry_detail"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>", entry_detail, name="api_entry_detail_noslash"),

    # Entry lookup by full url (fqid)
    path("entries/<path:entry_fqid>/", entry_by_fqid, name="api_entry_by_fqid"),
    path("entries/<path:entry_fqid>", entry_by_fqid, name="api_entry_by_fqid_noslash"),

    # IMAGE ENTRIES
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/image/", entry_image, name="api_entry_image"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/image", entry_image, name="api_entry_image_noslash"),

    path("entries/<path:entry_fqid>/image", entry_image_by_fqid, name="api_entry_image_by_fqid"),

    # ENTRY LIKES
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/likes/", entry_likes, name="api_entry_likes"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/likes", entry_likes, name="api_entry_likes_noslash"),

    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/like/", my_entry_like, name="api_my_entry_like"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/like", my_entry_like, name="api_my_entry_like_noslash"),

    # ENTRY COMMENTS
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/comments/", entry_comments, name="api_entry_comments"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/comments", entry_comments, name="api_entry_comments_noslash"),

    # COMMENT LIKES
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/comments/<uuid:comment_uuid>/likes/", comment_likes, name="api_comment_likes"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/comments/<uuid:comment_uuid>/likes", comment_likes, name="api_comment_likes_noslash"),

    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/comments/<uuid:comment_uuid>/like/", my_comment_like, name="api_my_comment_like"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/comments/<uuid:comment_uuid>/like", my_comment_like, name="api_my_comment_like_noslash"),

    # FOLLOWERS
    path("authors/<uuid:author_uuid>/followers/", followers_list, name="api_followers_list"),
    path("authors/<uuid:author_uuid>/followers", followers_list, name="api_followers_list_noslash"),

    path("authors/<uuid:author_uuid>/followers/<path:foreign_fqid>/", follower_detail, name="api_follower_detail"),
    path("authors/<uuid:author_uuid>/followers/<path:foreign_fqid>", follower_detail, name="api_follower_detail_noslash"),

    # FOLLOWING
    path("authors/<uuid:author_uuid>/following/", following_list, name="api_following_list"),
    path("authors/<uuid:author_uuid>/following", following_list, name="api_following_list_noslash"),

    path("authors/<uuid:author_uuid>/following/<path:foreign_fqid>/", following_detail, name="api_following_detail"),
    path("authors/<uuid:author_uuid>/following/<path:foreign_fqid>", following_detail, name="api_following_detail_noslash"),

    # FOLLOW REQUESTS
    path("authors/<uuid:author_uuid>/follow_requests/", follow_requests_list, name="api_follow_requests"),
    path("authors/<uuid:author_uuid>/follow_requests", follow_requests_list, name="api_follow_requests_noslash"),

    # INBOX
    path("authors/<uuid:author_uuid>/inbox/", author_inbox, name="api_author_inbox"),
    path("authors/<uuid:author_uuid>/inbox", author_inbox, name="api_author_inbox_noslash"),

    path('schema/', SpectacularAPIView.as_view(), name='schema'),
    path('docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
]
