from rest_framework import serializers

from authors.models import Author, FollowRequest, Follower
from entries.models import Entry, Comment, Like
from inbox.models import InboxItem

class AuthorSerializer(serializers.ModelSerializer):
    """
    Serializes a local Author model into the API "author object" format
    Use this when returning authors that exist in our database.
    Maps internal model fields into the correct JSON field names given in
    our API spec
    """
    type = serializers.SerializerMethodField()
    id = serializers.URLField(source="fqid", read_only=True)
    displayName = serializers.CharField(source="display_name")
    profileImage = serializers.URLField(source="profile_image", allow_blank=True, allow_null=True, required=False)

    class Meta:
        model = Author
        fields = [
            "type",
            "id",
            "host",
            "displayName",
            "github",
            "profileImage",
            "web",
        ]

    def get_type(self, obj):
        return "author"


class EntryAuthorSerializer(serializers.Serializer):
    """
    Serializer used to validate and represent author objects inside entries
    received from a remote node. Unlike the Author Serializer, this is not
    tied to our db, but validates the json structure and field names before
    storing on our local db.
    """
    type = serializers.CharField()
    id = serializers.CharField()
    host = serializers.CharField(allow_blank=True, required=False)
    displayName = serializers.CharField()
    github = serializers.CharField(allow_blank=True, required=False)
    profileImage = serializers.CharField(allow_blank=True, required=False)
    web = serializers.CharField(allow_blank=True, required=False)


class EntrySerializer(serializers.ModelSerializer):
    """
    Serializes Entry model instances into the API entry object format.
    The author field supports distributed behaviour by resolving the author
    through a FQID (full url), rather than a direct foreign key.

    The `web` field is the FRONTEND (HTML) URL for this entry — distinct from
    the API `id` URL. For local entries it's like:
        http://node/authors/<author_uuid>/entries/<entry_uuid>/
    For remote entries received via inbox we derive it by removing /api/ from
    their fqid, since remote nodes use the same pattern.
    """
    type = serializers.SerializerMethodField()
    id = serializers.URLField(source="fqid", read_only=True)
    # web = frontend page URL for this entry (not the API endpoint)
    web = serializers.SerializerMethodField()
    contentType = serializers.CharField(source="content_type")
    author = serializers.SerializerMethodField()

    class Meta:
        model = Entry
        fields = [
            "type",
            "id",
            "web",
            "title",
            "description",
            "contentType",
            "content",
            "visibility",
            "published",
            "author",
        ]

    def get_type(self, obj):
        return "entry"

    def get_web(self, obj):
        """
        Derive the HTML (browser-facing) URL from the API fqid

        Entries are created with fqid like:
            http://node/api/authors/<uuid>/entries/<uuid>
        The matching frontend URL is:
            http://node/authors/<uuid>/entries/<uuid>/

        We striped '/api' from the path portion to get there, this works for both 
        local entries and remote entries received via inbox (remote nodes should be
        adopting this same path convention)
        We strip '/api' from the path portion to get there.
        """
        # replace the API path prefix with the frontend path prefix
        # e.g. ".../api/authors/..." → ".../authors/..."
        web_url = obj.fqid.replace("/api/authors/", "/authors/")

        # trailing slash added so django can resolve it to the 'entry_detail'
        if not web_url.endswith("/"):
            web_url += "/"

        return web_url

    def get_author(self, obj):
        # Check our database first and see if we have an author under this fqid
        author = Author.objects.filter(fqid=obj.author_fqid).first()
        if author:
            return AuthorSerializer(author).data
        # in the case that the author is remote/ we never stored them locally
        # / the author row was maybe deleted --> fallback to just their fqid
        # ensures a minimal safe placeholder
        return {
            "type": "author",
            "id": obj.author_fqid,
            "host": "",
            "displayName": "Unknown",
            "github": "",
            "profileImage": "",
            "web": "",
        }


class EntryWriteSerializer(serializers.Serializer):
    """
    Serializer used for creating/updating entries via an API request.
    Seperates write validation from read serialization. Also validates
    incoming data.
    """
    title = serializers.CharField(required=False, allow_blank=True, default="")
    description = serializers.CharField(required=False, allow_blank=True, default="")
    contentType = serializers.ChoiceField(
        choices=[
            "text/plain",
            "text/markdown",
            "image/png;base64",
            "image/jpeg;base64",
        ],
        default="text/plain",
    )
    content = serializers.CharField()
    visibility = serializers.ChoiceField(
        choices=["PUBLIC", "FRIENDS", "UNLISTED", "DELETED"],
        default="PUBLIC",
    )


class CommentSerializer(serializers.ModelSerializer):
    """
    Serializes Comment model instances into the API spec format. This keeps 
    the distributed behaviour by returning an embedded author_data if stored
    (in the ccase of a remote comment), and falling back to a local Author 
    lookup through an Fqid --> this makes sure comments remain valid if the
    author somehow doesn't exist locally
    """
    type = serializers.SerializerMethodField()
    id = serializers.URLField(source="fqid", read_only=True)
    entry = serializers.URLField(source="entry_fqid", read_only=True)
    contentType = serializers.CharField(source="content_type")
    author = serializers.SerializerMethodField()

    class Meta:
        model = Comment
        fields = [
            "type",
            "id",
            "entry",
            "author",
            "comment",
            "contentType",
            "published",
        ]

    def get_type(self, obj):
        return "comment"

    def get_author(self, obj):
        if obj.author_data:
            return obj.author_data

        author = Author.objects.filter(fqid=obj.author_fqid).first()
        if author:
            return AuthorSerializer(author).data

        return {
            # fallback case
            "type": "author",
            "id": obj.author_fqid,
            "host": "",
            "displayName": "Unknown",
            "github": "",
            "profileImage": "",
            "web": "",
        }


class CommentWriteSerializer(serializers.Serializer):
    """
    Serializer used for validating incoming comment creation requests.
    Use when trying to ensure comment content and contentType match the
    allowed values. 
    """
    comment = serializers.CharField()
    contentType = serializers.ChoiceField(
        choices=["text/plain", "text/markdown"],
        default="text/plain",
    )


class LikeSerializer(serializers.ModelSerializer):
    """
    Serializes Like model instances into the API like object format. 
    Supports distributed behaviour by falling back to local Author lookup 
    via fqid, and using stored author_data for remote likes
    """
    type = serializers.SerializerMethodField()
    id = serializers.URLField(source="fqid", read_only=True)
    object = serializers.URLField(source="object_fqid", read_only=True)
    author = serializers.SerializerMethodField()

    class Meta:
        model = Like
        fields = [
            "type",
            "id",
            "author",
            "object",
            "published",
        ]

    def get_type(self, obj):
        return "like"

    def get_author(self, obj):
        if obj.author_data:
            return obj.author_data

        author = Author.objects.filter(fqid=obj.author_fqid).first()
        if author:
            return AuthorSerializer(author).data

        return {
            "type": "author",
            "id": obj.author_fqid,
            "host": "",
            "displayName": "Unknown",
            "github": "",
            "profileImage": "",
            "web": "",
        }


class FollowRequestSerializer(serializers.ModelSerializer):
    """
    serialzes the FollowRequest model instances into the API follow object
    format. 
    The actor field represents the requester (can be remote &
    stored as raw json). 
    The object field represents the target local author.
    """
    type = serializers.SerializerMethodField()
    actor = serializers.SerializerMethodField()
    object = serializers.SerializerMethodField()

    class Meta:
        model = FollowRequest
        fields = ["type", "actor", "object", "status"]

    def get_type(self, obj):
        return "Follow"

    def get_actor(self, obj):
        if obj.requester_data:
            return obj.requester_data

        return {
            "type": "author",
            "id": obj.requester_fqid,
            "host": "",
            "displayName": obj.requester_fqid,
            "github": "",
            "profileImage": "",
            "web": "",
        }

    def get_object(self, obj):
        return AuthorSerializer(obj.target).data


class InboxItemSerializer(serializers.ModelSerializer):
    """
    Serializes InboxItem model instances. InboxItems stores the raw objects pushed from 
    other nodes (ex. entries, comments, likes, or follows). this follows the inbox push mode
    """
    id = serializers.UUIDField(source="uuid", read_only=True)
    itemType = serializers.CharField(source="item_type")

    class Meta:
        model = InboxItem
        fields = [
            "id",
            "itemType",
            "recipient_author_fqid",
            "object_fqid",
            "raw_json",
            "processed",
            "received_at",
        ]