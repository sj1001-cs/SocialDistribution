from urllib.parse import unquote,quote
import requests
from requests.auth import HTTPBasicAuth

from django.shortcuts import get_object_or_404
from django.utils.http import urlsafe_base64_decode

from rest_framework import status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from authors.models import Author, Follower, FollowRequest
from entries.access import get_logged_in_author
from api.serializers import AuthorSerializer
from nodes.services import find_node_for_fqid, post_to_author_inbox

def _author_payload(author: Author) -> dict:
    data = AuthorSerializer(author).data
    data["type"] = "author"
    data["id"] = author.fqid
    data["host"] = author.host
    data["displayName"] = author.display_name
    data["github"] = author.github or ""
    data["profileImage"] = author.profile_image or ""
    data["url"] = author.fqid
    data["web"] = author.web or ""
    
    return data

# local author is being a follower
# GET /api/authors/<serial>/following/
@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def following_list(request, author_uuid):
    """
    GET /api/authors/<serial>/following/
        Returns a list of all authors that AUTHOR_SERIAL is following.
        Must be authenticated as AUTHOR_SERIAL.
        
        ONLY [local]

        Example response:
        {
            "type": "following",
            "following": [ { ...author object... }, ... ]
        }
    """


    author = get_object_or_404(Author, uuid=author_uuid)

    # auth check 
    viewer = get_logged_in_author(request)
    if viewer is None or viewer.uuid != author.uuid:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)

    # Follower rows where follower_fqid == me means I follow that author
    # "do i show up as someone's follower?"
    following_records = Follower.objects.filter(follower_fqid=author.fqid)

    following = []
    for record in following_records:
        local = Author.objects.filter(fqid=record.author.fqid).first()
        
        if local:
            following.append(AuthorSerializer(local).data)
        else:
            following.append({"type": "author", "id": record.author.fqid})

    return Response({
        "type": "following",
        "following": following,
    })


# PUT /api/authors/<serial>/following/<foreign_fqid>/
# DELETE /api/authors/<serial>/following/<foreign_fqid>/
# GET /api/authors/<serial>/following/<foreign_fqid>/
@api_view(["GET", "PUT", "DELETE"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def following_detail(request, author_uuid, foreign_fqid):
    """
    ALL [local] METHODS
    NOTEE: For Part 3+: if foreign author is on another node, POST to their inbox.

    GET /api/authors/<serial>/following/<foreign_fqid>/
        Check if AUTHOR_SERIAL is following FOREIGN_AUTHOR_FQID.
        Must be authenticated as AUTHOR_SERIAL.
        Returns the author object if following, 404 if not.

    PUT /api/authors/<serial>/following/<foreign_fqid>/
        AUTHOR_SERIAL sends a follow request to FOREIGN_AUTHOR_FQID.
        Creates a FollowRequest if none exists.
        NOTEE: For Part 3+: if foreign author is on another node, POST to their inbox.
        Must be authenticated as AUTHOR_SERIAL.

    DELETE /api/authors/<serial>/following/<foreign_fqid>/
        AUTHOR_SERIAL unfollows FOREIGN_AUTHOR_FQID.
        Removes the Follower row on the target's side.
        Must be authenticated as AUTHOR_SERIAL.

    NOTEE: foreign_fqid is percent-encoded in the URL.
    Example: /api/authors/111/following/http%3A%2F%2Fnodebbbb%2Fapi%2Fauthors%2F222
    """

    author = get_object_or_404(Author, uuid=author_uuid)
    foreign_fqid = unquote(foreign_fqid)

    viewer = get_logged_in_author(request)
    if viewer is None or viewer.uuid != author.uuid:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)

    # GET | am I following them?
    if request.method == "GET":
        
        is_following = Follower.objects.filter(
            follower_fqid=author.fqid,
            author__fqid=foreign_fqid,
        ).exists()

        # nah
        if not is_following:
            return Response({"error": "Not following"}, status=status.HTTP_404_NOT_FOUND)

        # yeah and return any info them
        local = Author.objects.filter(fqid=foreign_fqid).first()
        if local:
            return Response(AuthorSerializer(local).data)
        return Response({"type": "author", "id": foreign_fqid})

    
    
    # PUT | send follow request
    if request.method == "PUT":

        existing = FollowRequest.objects.filter(
            requester_fqid=author.fqid,
            target__fqid=foreign_fqid,
        ).first()

        if existing:
            # A FollowRequest already exists from a previous interaction.
            # Only a PENDING request means "waiting for approval" — we leave
            # those alone so we don't spam the target with duplicate requests.
            if existing.status == FollowRequest.Status.PENDING:
                return Response(
                    {"success": True, "message": "Follow request already pending"},
                    status=status.HTTP_200_OK,
                )

            # If status is ACCEPTED or REJECTED it means the relationship was
            # established (and later dropped) or was denied previously.
            # In both cases the author wants to follow again, so we reset the
            # existing row to PENDING rather than creating a duplicate row
            # (unique_together would prevent that anyway).
            # This is the core of the "can't re-follow after mutual unfollow" bug:
            # without this branch the old ACCEPTED row was never cleared, so the
            # target never saw a new incoming follow request.
            existing.status = FollowRequest.Status.PENDING
            existing.requester_data = AuthorSerializer(author).data
            existing.save(update_fields=["status", "requester_data"])
            return Response(
                {"success": True, "message": "Follow request sent"},
                status=status.HTTP_201_CREATED,
            )

        # No prior request at all — create a fresh one.
        target = Author.objects.filter(fqid=foreign_fqid.rstrip("/")).first()
        if not target:
            fqid_clean = foreign_fqid.rstrip("/")
            parts = fqid_clean.split("/")
            host = "/".join(parts[:3])

            target = Author.objects.create(
                fqid=fqid_clean,
                host=host,
                display_name=fqid_clean,
                web=fqid_clean,
                user=None,
                is_approved=False,
            )

        # Local target: keep your current behavior
        if target and target.is_local():
            FollowRequest.objects.update_or_create(
                requester_fqid=author.fqid,
                target=target,
                defaults={
                    "requester_data": AuthorSerializer(author).data,
                    "status": FollowRequest.Status.PENDING,
                },
            )
            
            return Response(
                {"success": True, "message": "Follow request sent"},
                status=status.HTTP_201_CREATED,
            )

        # Remote target: send Follow object to their inbox
        node = find_node_for_fqid(foreign_fqid)
        if not node:
            return Response(
                {"error": "No configured remote node matches that author FQID."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        target_local = Author.objects.filter(fqid=foreign_fqid.rstrip("/")).first()
        if target_local:
            object_payload = _author_payload(target_local)
        else:
            object_payload = {
                "type": "author",
                "id": foreign_fqid,
                "url": foreign_fqid,
                "host": "/".join(foreign_fqid.rstrip("/").split("/")[:3]) + "/api/",
                "displayName": "",
                "github": "",
                "profileImage": "",
                "web": foreign_fqid,
            }

        payload = {
            "type": "follow",
            "summary": f"{author.display_name} wants to follow you",
            "actor": _author_payload(author),
            "object": object_payload,
        }

        try:
            resp = post_to_author_inbox(node, foreign_fqid, payload)
        except Exception as exc:
            return Response(
                {"error": f"Failed to contact remote node: {exc}"},
                status=status.HTTP_502_BAD_GATEWAY,
            )

        if 200 <= resp.status_code < 300:
            FollowRequest.objects.update_or_create(
                requester_fqid=author.fqid,
                target=target,
                defaults={
                    "requester_data": AuthorSerializer(author).data,
                    "status": FollowRequest.Status.ACCEPTED,
                    },
                )

            Follower.objects.get_or_create(
                author=target,
                follower_fqid=author.fqid,
            )
            
            return Response(
                {
                    "success": True,
                    "message": "Remote follow request sent",
                    "remote_status": resp.status_code,
                },
                status=status.HTTP_201_CREATED,
            )

        return Response(
            {
                "error": "Remote node rejected follow request",
                "remote_status": resp.status_code,
                "remote_body": resp.text,
            },
            status=status.HTTP_502_BAD_GATEWAY,
        )
    
    
    # DELETE | unfollow
    if request.method == "DELETE":
        target_fqid = foreign_fqid.rstrip("/")
        target = Author.objects.filter(fqid=target_fqid).first()
        if not target:
            fqid_clean = target_fqid
            parts = fqid_clean.split("/")
            host = "/".join(parts[:3])

            target = Author.objects.create(
                fqid=fqid_clean,
                host=host,
                display_name=fqid_clean,
                web=fqid_clean,
                user=None,
                is_approved=False,
            )

        remote_delete_status = None
        remote_delete_error = None

        # Best-effort remote unfollow for remote authors
        if target and not target.is_local():
            node = find_node_for_fqid(target_fqid)

            if node:
                encoded_me = quote(author.fqid.rstrip("/"), safe="")
                remote_url = f"{target_fqid}/followers/{encoded_me}/"

                try:
                    resp = requests.delete(
                        remote_url,
                        auth=HTTPBasicAuth(node.username, node.password),
                        timeout=6,
                    )
                    remote_delete_status = resp.status_code

                    # Some nodes return 2xx, some are buggy.
                    # We record it, but we do not block local unfollow.
                    if not (200 <= resp.status_code < 300):
                        remote_delete_error = resp.text

                except Exception as exc:
                    remote_delete_error = str(exc)

        # Always clean our local side
        Follower.objects.filter(
            author=target,
            follower_fqid=author.fqid.rstrip("/"),
        ).delete()

        FollowRequest.objects.filter(
            requester_fqid=author.fqid.rstrip("/"),
            target=target,
        ).delete()

        response = {
            "success": True,
            "message": "Unfollowed locally",
        }

        if remote_delete_status is not None:
            response["remote_status"] = remote_delete_status

        if remote_delete_error:
            response["remote_warning"] = remote_delete_error

        return Response(response)