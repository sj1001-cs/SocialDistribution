import base64

from django.shortcuts import get_object_or_404
from django.http import HttpResponse

from rest_framework import status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from authors.models import Author
from entries.models import Entry
from entries.access import get_logged_in_author, can_view_entry


def serve_image(entry, viewer):
    """
    decode base64 image entry and return as binary HTTP response.
    Returns a Response error if not an image or not accessible.
    """
    IMAGE_TYPES = ["image/png;base64", "image/jpeg;base64"]
  

    if entry.content_type not in IMAGE_TYPES:
        return Response({"error": "Not an image entry"}, status=status.HTTP_404_NOT_FOUND)

    if not can_view_entry(viewer, entry):
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    # decode base64 content to raw bytes
    try:
        image_bytes = base64.b64decode(entry.content)
    except Exception:
        return Response({"error": "Invalid base64 image data"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    # map content_type to a real MIME type for the HTTP response
    mime = entry.content_type.replace(";base64", "")  # image/png or image/jpeg
    return HttpResponse(image_bytes, content_type=mime)


# GET /api/authors/<serial>/entries/<entry_serial>/image
@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def entry_image(request, author_uuid, entry_uuid):
    """
    GET /api/authors/<serial>/entries/<entry_serial>/image
        Returns the image entry decoded as binary.
        Returns 404 if the entry is not an image.
        [local, remote]

        This allows using the URL directly in an <img> tag or
        in Markdown like: ![alt](http://node/api/authors/x/entries/y/image)
    """
    author = get_object_or_404(Author, uuid=author_uuid)
    entry  = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid, is_deleted=False)
    viewer = get_logged_in_author(request)
    return serve_image(entry, viewer)




# PARTS 3 - 5 
# GET /api/entries/<path:entry_fqid>/image
@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def entry_image_by_fqid(request, entry_fqid):
    """
    GET /api/entries/<path:entry_fqid>/image
        Returns the image entry decoded as binary, looked up by FQID.
        Returns 404 if the entry is not an image.
        [local, remote]

        Uses <path:> URL converter because FQIDs contain slashes.
    """
    entry = Entry.objects.filter(fqid=entry_fqid, is_deleted=False).first()
    if not entry:
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    viewer = get_logged_in_author(request)
    return serve_image(entry, viewer)