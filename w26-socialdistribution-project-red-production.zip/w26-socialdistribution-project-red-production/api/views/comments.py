import uuid

from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from api.serializers import CommentSerializer, CommentWriteSerializer, LikeSerializer
from authors.models import Author
from entries.access import can_view_entry, get_logged_in_author
from entries.models import Comment, Entry, Like
from nodes.services import find_node_for_fqid, post_to_author_inbox


def _get_entry(author_uuid, entry_uuid):
    """
    Helper funciton so every comment/like endpoint resolves the same entry in one place
    The URL always identifies the entry by:
      /api/authors/<author_uuid>/entries/<entry_uuid>/...
    """
    author = get_object_or_404(Author, uuid=author_uuid)
    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid)
    return author, entry


@api_view(["GET", "POST"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def entry_comments(request, author_uuid, entry_uuid):
    """
    GET: Return all comments for one entry.
    Ex.
        /api/authors/<author_uuid>/entries/<entry_uuid>/comments/

    POST: Create a new comment on that entry as the logged-in author.
    Ex.
        /api/authors/<author_uuid>/entries/<entry_uuid>/comments/
      
    """
    _, entry = _get_entry(author_uuid, entry_uuid)

    viewer = get_logged_in_author(request)
    if not can_view_entry(viewer, entry):
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    # GET method - read all comments for the entry
    if request.method == "GET":
        comments = Comment.objects.filter(entry_fqid=entry.fqid).order_by("-published")
        return Response({
            "type": "comments",
            "comments": CommentSerializer(comments, many=True).data,
        })

    # Creating a comment requires a logged-in author
    if viewer is None:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)

    # Using CommentWriteSerializer since this is an incoming creation requests
    #   --> need to validate the content and structure
    serializer = CommentWriteSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    data = serializer.validated_data
    comment_uuid = uuid.uuid4()
    host = request.build_absolute_uri("/").rstrip("/")

    # Comment FQIDs are used for this convention (project spec)
    # http://node/api/authors/<viewer_uuid>/commented/<comment_uuid>
    comment_fqid = f"{host}/api/authors/{viewer.uuid}/commented/{comment_uuid}"

    comment = Comment.objects.create(
        uuid=comment_uuid,
        fqid=comment_fqid,
        entry_fqid=entry.fqid,
        entry=entry,
        author_fqid=viewer.fqid,
        author_data=viewer.to_json(),
        comment=data["comment"],
        content_type=data["contentType"],
    )
    node = find_node_for_fqid(entry.author_fqid)
    if node and entry.author_fqid.rstrip("/") != viewer.fqid.rstrip("/"):
        payload = CommentSerializer(comment).data
        payload["type"] = "comment"
        try:
            post_to_author_inbox(node, entry.author_fqid, payload)
        except Exception:
            pass

    return Response(CommentSerializer(comment).data, status=status.HTTP_201_CREATED)


@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def comment_likes(request, author_uuid, entry_uuid, comment_uuid):
    """
    GET: Return all Like objects for one comment
    Ex.
        /api/authors/<author_uuid>/entries/<entry_uuid>/comments/<comment_uuid>/likes/
      
    """
    _, entry = _get_entry(author_uuid, entry_uuid)

    viewer = get_logged_in_author(request)
    if not can_view_entry(viewer, entry):
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    comment = get_object_or_404(Comment, uuid=comment_uuid, entry_fqid=entry.fqid)
    likes = Like.objects.filter(object_fqid=comment.fqid).order_by("-published")

    return Response({
        "type": "likes",
        "likes": LikeSerializer(likes, many=True).data,
    })


@api_view(["POST", "DELETE"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def my_comment_like(request, author_uuid, entry_uuid, comment_uuid):
    """
    POST: Like the comment as the logged-in author.
    Ex.
        /api/authors/<author_uuid>/entries/<entry_uuid>/comments/<comment_uuid>/like/
      

    DELETE: Remove the logged-in author's like from the comment.
    Ex.
        /api/authors/<author_uuid>/entries/<entry_uuid>/comments/<comment_uuid>/like/
    
    """
    _, entry = _get_entry(author_uuid, entry_uuid)

    viewer = get_logged_in_author(request)
    if viewer is None:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)

    if not can_view_entry(viewer, entry):
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    comment = get_object_or_404(Comment, uuid=comment_uuid, entry_fqid=entry.fqid)

    existing = Like.objects.filter(
        object_fqid=comment.fqid,
        author_fqid=viewer.fqid,
    ).first()

    # DELETE is idempotent (can do multiple times and result stays the same)
    # If the like is already gone, return success anyway
    if request.method == "DELETE":
        if existing:
            existing.delete()

            comment_author_fqid = comment.author_fqid.rstrip("/")
            node = find_node_for_fqid(comment_author_fqid)
            if node and comment_author_fqid != viewer.fqid.rstrip("/"):
                payload = {
                    "type": "unlike",
                    "object": comment.fqid,
                    "author": viewer.to_json(),
                }
                try:
                    post_to_author_inbox(node, comment_author_fqid, payload)
                except Exception:
                    pass

        count = Like.objects.filter(object_fqid=comment.fqid).count()
        return Response({"liked": False, "count": count})

    # Idempotent implementation again
    # If the author already liked the comment, return the current state without duplicating.
    if existing:
        count = Like.objects.filter(object_fqid=comment.fqid).count()
        return Response({
            "liked": True,
            "count": count,
            "like": LikeSerializer(existing).data,
        })

    like_uuid = uuid.uuid4()
    host = request.build_absolute_uri("/").rstrip("/")

    # like FQID used to match the project api implementation
    # http://node/api/authors/<viewer_uuid>/liked/<like_uuid>
    like_fqid = f"{host}/api/authors/{viewer.uuid}/liked/{like_uuid}"

    like = Like.objects.create(
        uuid=like_uuid,
        fqid=like_fqid,
        author_fqid=viewer.fqid,
        author_data=viewer.to_json(),
        object_fqid=comment.fqid,
        comment=comment,
    )
    comment_author_fqid = comment.author_fqid.rstrip("/")
    node = find_node_for_fqid(comment_author_fqid)
    if node and comment_author_fqid != viewer.fqid.rstrip("/"):
        payload = LikeSerializer(like).data
        payload["type"] = "like"
        try:
            post_to_author_inbox(node, comment_author_fqid, payload)
        except Exception:
            pass

    count = Like.objects.filter(object_fqid=comment.fqid).count()
    return Response({
        "liked": True,
        "count": count,
        "like": LikeSerializer(like).data,
    }, status=status.HTTP_201_CREATED)
