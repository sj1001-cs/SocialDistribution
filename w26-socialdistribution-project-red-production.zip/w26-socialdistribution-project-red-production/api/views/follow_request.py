from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from authors.models import Author, FollowRequest
from entries.access import get_logged_in_author
from api.serializers import FollowRequestSerializer


# GET /api/authors/<serial>/follow_requests/
@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def follow_requests_list(request, author_uuid):
    """
    GET /api/authors/<serial>/follow_requests/
        Returns all pending follow requests for AUTHOR_SERIAL.
        Must be authenticated as AUTHOR_SERIAL.
        [local]

        Example response:
        {
            "type": "follow",      
            "summary":"actor wants to follow object",
            "actor":{
                "type":"author",
                // The rest of the author object for the author who wants to follow
            },
            "object":{
                "type":"author",
                // The rest of the author object for the author they want to follow
            }
        }
    """
    author = get_object_or_404(Author, uuid=author_uuid)

    viewer = get_logged_in_author(request)
    if viewer is None or viewer.uuid != author.uuid:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)


    pending = FollowRequest.objects.filter(
        target=author,
        status=FollowRequest.Status.PENDING,
    ).order_by("-created_at")

    return Response({
        "type": "follow_requests",
        "follow_requests": FollowRequestSerializer(pending, many=True).data,
    })

# Cancel Follow Request
@api_view(["POST"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def cancel_follow_request(request, author_uuid):
    """
    DELETE /api/authors/<serial>/follow_requests/
        Cancel a pending follow request to AUTHOR_SERIAL.
        Must be authenticated as the requester.
    """
    author = get_object_or_404(Author, uuid=author_uuid)

    viewer = get_logged_in_author(request)
    if viewer is None:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)

    try:
        follow_request = FollowRequest.objects.get(
            target=author,
            requester_fqid=viewer.fqid,
            status=FollowRequest.Status.PENDING,
        )
    except FollowRequest.DoesNotExist:
        return Response({"error": "No pending follow request found"}, status=status.HTTP_404_NOT_FOUND)

    follow_request.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)