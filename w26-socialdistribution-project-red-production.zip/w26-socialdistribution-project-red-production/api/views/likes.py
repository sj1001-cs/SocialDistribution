import uuid

from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from authors.models import Author
from entries.access import can_view_entry, get_logged_in_author
from entries.models import Entry, Like
from api.serializers import LikeSerializer
from nodes.services import find_node_for_fqid, post_to_author_inbox


@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def entry_likes(request, author_uuid, entry_uuid):
    """
    GET: Return a list of Like objects for a specific entry.

    Example request:
      GET /api/authors/111.../entries/222.../likes

    Example response (shape):
      {
        "type": "likes",
        "likes": [
          {
            "type": "like",
            "id": "https://ournode/api/authors/<viewer>/liked/<like_uuid>",
            "author": {...},
            "object": "https://ournode/api/authors/<author>/entries/<entry_uuid>",
            "published": "2026-03-02T..."
          },
          ...
        ]
      }
    """
    author = get_object_or_404(Author, uuid=author_uuid)
    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid)

    viewer = get_logged_in_author(request)
    if not can_view_entry(viewer, entry): # Only reveal likes if the requester is allowed to see it
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    # Likes point at the entry using the object_id
    likes = Like.objects.filter(object_fqid=entry.fqid).order_by("-published")
    return Response({
        "type": "likes",
        "likes": LikeSerializer(likes, many=True).data,
    })


@api_view(["POST", "DELETE"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def my_entry_like(request, author_uuid, entry_uuid):
    """
    POST: Like the entry as the logged-in author.
    Ex. 
      /api/authors/<author_uuid>/entries/<entry_uuid>/like/
    

    DELETE: Remove the logged-in author's like from the entry.
    Ex.
      /api/authors/<author_uuid>/entries/<entry_uuid>/like/

    The response always includes: 
      - liked: current like state for this user
      - count: total # of likes on the entry

    That shape makes the endpoint easy for the browser UI to consume.
    
    """
    author = get_object_or_404(Author, uuid=author_uuid)
    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid) # <-- ensure entry belongs to the author

    viewer = get_logged_in_author(request) # who's making the request?
    if viewer is None:
        #cannot like something anonymously
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN) 

    if not can_view_entry(viewer, entry):
        # if you cant see the entry, then you can't like the entry
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    existing = Like.objects.filter( #has the author already liked this?
        object_fqid=entry.fqid,
        author_fqid=viewer.fqid,
    ).first()

    # Idempotent implementation on DELETE. Return new count either way
    if request.method == "DELETE":
        if existing:
            existing.delete()

            node = find_node_for_fqid(entry.author_fqid)
            if node and entry.author_fqid.rstrip("/") != viewer.fqid.rstrip("/"):
                payload = {
                    "type": "unlike",
                    "object": entry.fqid,
                    "author": viewer.to_json(),
                }
                try:
                    post_to_author_inbox(node, entry.author_fqid, payload)
                except Exception:
                    pass

        count = Like.objects.filter(object_fqid=entry.fqid).count()
        return Response({"liked": False, "count": count})

    # If already liked, do not create a duplicate row
    if existing:
        count = Like.objects.filter(object_fqid=entry.fqid).count()
        return Response({
            "liked": True,
            "count": count,
            "like": LikeSerializer(existing).data,
        })

    # Create a new like:
    like_uuid = uuid.uuid4()
    host = request.build_absolute_uri("/").rstrip("/")
    fqid = f"{host}/api/authors/{viewer.uuid}/liked/{like_uuid}"

    like = Like.objects.create(
        uuid=like_uuid,
        fqid=fqid,
        author_fqid=viewer.fqid,
        author_data=viewer.to_json(),
        object_fqid=entry.fqid,
        entry=entry,
    )

    node = find_node_for_fqid(entry.author_fqid)
    if node and entry.author_fqid.rstrip("/") != viewer.fqid.rstrip("/"):
        payload = LikeSerializer(like).data
        payload["type"] = "like"
        try:
            post_to_author_inbox(node, entry.author_fqid, payload)
        except Exception:
            pass

    count = Like.objects.filter(object_fqid=entry.fqid).count()
    return Response({
        "liked": True,
        "count": count,
        "like": LikeSerializer(like).data,
    }, status=status.HTTP_201_CREATED)

