from urllib.parse import unquote

from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from authors.models import Author, Follower, FollowRequest
from entries.access import get_logged_in_author
from api.serializers import AuthorSerializer
from nodes.services import find_node_for_fqid, post_to_author_inbox

# local author is being followed

# GET /api/authors/<serial>/followers/
@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def followers_list(request, author_uuid):
    """
    GET /api/authors/<serial>/followers/
        Returns a list of all authors following AUTHOR_SERIAL.
        [local, remote]

        Example response:
        {
            "type": "followers",      
            "followers":[
                {
                    "type":"author",
                    "id":"http://nodebbbb/api/authors/222",
                    "host":"http://nodebbbb/api/",
                    "displayName":"Lara Croft",
                    "web":"http://nodebbbb/authors/222",
                    "github": "http://github.com/laracroft",
                    "profileImage": "http://nodebbbb/api/authors/222/entries/217/image"
                },
                {
                    // Second follower author object
                },
                {
                    // Third follower author object
                }
            ]
        }
    """
    author = get_object_or_404(Author, uuid=author_uuid)

    follower_records = Follower.objects.filter(author=author)

    followers = []
    for record in follower_records:
        # try to find them in our local db first
        local = Author.objects.filter(fqid=record.follower_fqid).first()
        if local:
            followers.append(AuthorSerializer(local).data)
        
        # PART 3 - 5
        # elif record.follower_data:
        #     # remote author — use cached data
        #     followers.append(record.follower_data)
        else:
            # minimal fallback
            followers.append({"type": "author", "id": record.follower_fqid})

    return Response({
        "type": "followers",
        "followers": followers,
    })


# GET /api/authors/<serial>/followers/<foreign_fqid>/
# PUT /api/authors/<serial>/followers/<foreign_fqid>/
# DELETE /api/authors/<serial>/followers/<foreign_fqid>/
@api_view(["GET", "PUT", "DELETE"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def follower_detail(request, author_uuid, foreign_fqid):
    """
    GET /api/authors/<serial>/followers/<foreign_fqid>/
        Check if FOREIGN_AUTHOR_FQID is a follower of AUTHOR_SERIAL.
        Returns the author object if they are else 404.
        [local, remote]

        foreign_fqid is percent-encoded in the URL, Django decodes it automatically.
        Example: /api/authors/111/followers/http%3A%2F%2Fnodebbbb%2Fapi%2Fauthors%2F222

    PUT /api/authors/<serial>/followers/<foreign_fqid>/
        Accept FOREIGN_AUTHOR_FQID as a follower of AUTHOR_SERIAL.
        Used by AUTHOR_SERIAL to accept a pending follow request.
        Must be authenticated as AUTHOR_SERIAL.
        Returns 404 if there is no matching follow request.
        [local]

    DELETE /api/authors/<serial>/followers/<foreign_fqid>/
        Remove FOREIGN_AUTHOR_FQID as a follower or deny their follow request.
        Must be authenticated as AUTHOR_SERIAL.
        Returns 404 if there is no matching follow request or follower.
        [local]
    """
    author = get_object_or_404(Author, uuid=author_uuid)
    foreign_fqid = unquote(foreign_fqid).rstrip("/")  # decode %3A -> : etc.

    # GET | check if following (no auth required)
    if request.method == "GET":
        follower = Follower.objects.filter(
            author=author,
            follower_fqid=foreign_fqid
        ).first()

        if not follower:
            return Response({"error": "Not a follower"}, status=status.HTTP_404_NOT_FOUND)

        # return the author object of the follower
        local = Author.objects.filter(fqid=foreign_fqid).first()
        if local:
            return Response(AuthorSerializer(local).data)
        # PART 3 - 5
        # elif follower.follower_data:
        #     return Response(follower.follower_data)
        return Response({"type": "author", "id": foreign_fqid})

    # we require auth as the target author for PUT AND DELETE
    viewer = get_logged_in_author(request)
    if viewer is None:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)
    if viewer.uuid != author.uuid:
        return Response({"error": "Forbidden"}, status=status.HTTP_403_FORBIDDEN)

    # PUT | accept follow request
    if request.method == "PUT":
        follow_request = FollowRequest.objects.filter(
            target=author,
            requester_fqid=foreign_fqid,
            status=FollowRequest.Status.PENDING,
        ).first()

        if not follow_request:
            return Response({"error": "No pending follow request found"}, status=status.HTTP_404_NOT_FOUND)

        follow_request.status = FollowRequest.Status.ACCEPTED
        follow_request.save(update_fields=["status"])

        Follower.objects.get_or_create(
            author=author,
            follower_fqid=foreign_fqid,
            defaults={"follower_data": follow_request.requester_data},
        )
        node = find_node_for_fqid(foreign_fqid)
        if node:
            payload = {
                "type": "follow_accepted",
                "summary": f"{author.display_name} accepted your follow request",
                "actor": AuthorSerializer(author).data,
                "object": {
                    "type": "author",
                    "id": foreign_fqid,
                    "url": foreign_fqid,
                },
            }
            try:
                post_to_author_inbox(node, foreign_fqid, payload)
            except Exception:
                pass

        return Response({"success": True, "message": "Follow request accepted"})

    # DELETE | deny follow request or remove follower
    if request.method == "DELETE":

        # 1) if they are a follower, remove them (highest priority)
        follower = Follower.objects.filter(
            author=author,
            follower_fqid=foreign_fqid,
        ).first()

        if follower:
            follower.delete()
            return Response({"success": True, "message": "Follower removed"})

        # 2) otherwise, reject only a PENDING follow request
        follow_request = FollowRequest.objects.filter(
            target=author,
            requester_fqid=foreign_fqid,
            status=FollowRequest.Status.PENDING,
        ).first()
        
        if follow_request:
            follow_request.status = FollowRequest.Status.REJECTED
            follow_request.save(update_fields=["status"])
            return Response({"success": True, "message": "Rejected follow request"})

        # 3) nothing to delete/reject
        return Response({"error": "No pending follow request or follower found"}, status=status.HTTP_404_NOT_FOUND)