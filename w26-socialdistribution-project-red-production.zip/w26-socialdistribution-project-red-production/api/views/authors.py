from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from authors.models import Author, FollowRequest
from entries.access import get_logged_in_author
from api.serializers import AuthorSerializer
from nodes.services import find_node_for_fqid, post_to_author_inbox


def _author_payload(author: Author) -> dict:
    return {
        "type": "author",
        "id": author.fqid,
        "host": author.host,
        "displayName": author.display_name,
        "description": author.description or "",
        "github": author.github or "",
        "profileImage": author.profile_image or "",
        "url": author.fqid,
        "web": author.web or "",
    }


def _broadcast_author_update(author: Author):
    remote_fqids = set()

    remote_fqids.update(fqid.rstrip("/") for fqid in author.follower_fqids())
    remote_fqids.update(fqid.rstrip("/") for fqid in author.following_fqids())

    remote_fqids.update(
        fqid.rstrip("/")
        for fqid in FollowRequest.objects.filter(requester_fqid=author.fqid)
        .values_list("target__fqid", flat=True)
    )

    payload = {
        "type": "author_update",
        "summary": f"{author.display_name} updated their profile",
        "author": _author_payload(author),
    }

    for remote_fqid in remote_fqids:
        node = find_node_for_fqid(remote_fqid)
        if not node:
            continue

        try:
            post_to_author_inbox(node, remote_fqid, payload)
        except Exception as e:
            print("AUTHOR UPDATE PUSH FAILED:", e)


# GET /api/authors/
@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def authors_list(request):
    """
    GET /api/authors/
        Returns paginated list of all approved local authors.

        Query params:
            page  - page number (1-based, default 1)
            size  - authors per page (default 10)

        Example response:
        {
            "type": "authors",      
            "authors":[
            {
                "type":"author",
                "id":"http://nodeaaaa/api/authors/111",
                "host":"http://nodeaaaa/api/",
                "displayName":"Greg Johnson",
                "github": "http://github.com/gjohnson",
                "profileImage": "https://i.imgur.com/k7XVwpB.jpeg",
                "web": "http://nodeaaaa/authors/greg"
            },
            {
                // A second author object...
            },
            {
                // A third author object...
            }
    ]
}
    """
    try:
        page = max(1, int(request.GET.get('page', 1)))
        size = max(1, int(request.GET.get('size', 10)))
    except ValueError:
        page, size = 1, 10

    all_authors = Author.objects.filter(is_approved=True, user__isnull=False).order_by("created_at")
    total = all_authors .count()
    start = (page - 1) * size
    authors = all_authors [start:start + size]

    return Response({
        "type":    "authors",
        "authors": AuthorSerializer(authors, many=True).data,
    })



# GET /api/authors/<author_uuid>/
# PUT /api/authors/<author_uuid>/
@api_view(["GET", "PUT"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def author_detail(request, author_uuid):
    author = get_object_or_404(Author, uuid=author_uuid, is_approved=True)

    if request.method == "GET":
        return Response(AuthorSerializer(author).data)

    viewer = get_logged_in_author(request)
    if viewer is None:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)

    if viewer.uuid != author.uuid:
        return Response({"error": "Forbidden - not your profile"}, status=status.HTTP_403_FORBIDDEN)

    data = request.data
    if "displayName" in data:
        author.display_name = data["displayName"]
    if "description" in data:
        author.description = data["description"] or ""
    if "github" in data:
        author.github = data["github"] or ""
    if "profileImage" in data:
        author.profile_image = data["profileImage"] or None

    author.save()
    _broadcast_author_update(author)

    return Response(AuthorSerializer(author).data)