from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from authors.models import Author, FollowRequest, Follower
from entries.models import Entry, Comment, Like
from inbox.models import InboxItem
from nodes.models import Node
from api.serializers import InboxItemSerializer


def _is_owner(request, author):
    """
    Helper function: return True if the requester is the same author whose inbox this is
    
    Since inbox GET/DELETE is private, only the owner should be able to read or clear 
    their inbox. Inbox POST is different --> remote servers need to POST into the inbox,
    so we do not require "owner" for POST.

    Ex. 
    - Kaylem is logged in, kaylem requests /author/<KaylemUUID>/inbox --> True
    - Kaylem requests /authors/<Tj'sUUID>/inbox --> False
    - Anonymous tries requesting /author/<KaylemUUID>/inbox ... nice try Anonymous --> False
    """
    return (
        # is this requests from a logged in user?
        request.user.is_authenticated 
        and hasattr(request.user, "author") #request.user has an author object
        and request.user.author.uuid == author.uuid # the author's uuid matches the URL uuid
    )

def _normalize_url(url: str) -> str:
    return (url or "").rstrip("/")


def _find_node_for_payload(payload: dict):
    """
    Extract the sender's host from the payload actor/author and return the
    matching Node record, or None if no registered node matches.
    """
    actor = payload.get("actor") or payload.get("author") or {}
    actor_id = _normalize_url(actor.get("id") or actor.get("url") or "")
    if not actor_id:
        return None

    for node in Node.objects.filter(is_active=True):
        host = _normalize_url(node.host)
        api_base = _normalize_url(node.api_base)
        if (host and actor_id.startswith(host)) or (api_base and actor_id.startswith(api_base)):
            return node

    return None


def _upsert_remote_author(author_data: dict):
    """
    Create or update a remote author locally from inbound actor JSON.
    Never touches local authors (those with a real user account).
    """
    fqid = _normalize_url(author_data.get("id"))
    if not fqid:
        return None

    existing = Author.objects.filter(fqid=fqid).first()
    if existing and existing.user_id is not None:
        return existing

    host = _normalize_url(author_data.get("host"))
    if not host:
        fqid_clean = fqid.rstrip("/")
        host = "/".join(fqid_clean.split("/")[:3])

    author, _ = Author.objects.update_or_create(
        fqid=fqid,
        defaults={
            "user": None,
            "host": host,
            "display_name": author_data.get("displayName") or fqid,
            "description": author_data.get("description") or "",
            "github": author_data.get("github") or "",
            "profile_image": author_data.get("profileImage") or "",
            "web": author_data.get("web") or author_data.get("url") or fqid,
        },
    )
    return author

def _process_author_update_item(owner: Author, payload: dict):
    author_data = payload.get("author") or {}
    fqid = _normalize_url(author_data.get("id"))

    if not fqid:
        return False, "Missing author.id"

    remote_author = _upsert_remote_author(author_data)
    if remote_author is None:
        return False, "Could not upsert remote author"

    FollowRequest.objects.filter(requester_fqid=fqid).update(requester_data=author_data)
    Follower.objects.filter(follower_fqid=fqid).update(follower_data=author_data)

    return True, "Processed author update"


def _process_follow_item(owner: Author, payload: dict):
    actor = payload.get("actor") or {}
    requester_fqid = _normalize_url(actor.get("id"))
    if not requester_fqid:
        return False, "Missing actor.id"

    _upsert_remote_author(actor)

    follow_request, created = FollowRequest.objects.get_or_create(
        requester_fqid=requester_fqid,
        target=owner,
        defaults={
            "requester_data": actor,
            "status": FollowRequest.Status.PENDING,
        },
    )

    if not created:
        follow_request.requester_data = actor
        follow_request.status = FollowRequest.Status.PENDING
        follow_request.save(update_fields=["requester_data", "status"])

    return True, "Processed follow"


def _process_follow_accepted_item(owner: Author, payload: dict):
    actor = payload.get("actor") or {}
    remote_author_fqid = _normalize_url(actor.get("id"))
    if not remote_author_fqid:
        return False, "Missing actor.id"

    remote_author = _upsert_remote_author(actor)
    if remote_author is None:
        return False, "Could not upsert remote author"

    Follower.objects.get_or_create(
        author=remote_author,
        follower_fqid=owner.fqid,
        defaults={"follower_data": owner.to_json()},
    )

    follow_request = FollowRequest.objects.filter(
        requester_fqid=owner.fqid,
        target=remote_author,
    ).first()

    if follow_request:
        follow_request.status = FollowRequest.Status.ACCEPTED
        follow_request.save(update_fields=["status"])

    return True, "Processed follow acceptance"


def _process_post_item(owner: Author, payload: dict):
    """
    Store a remote entry locally so it can appear in streams.
    """
    entry_fqid = _normalize_url(payload.get("id"))
    author_data = payload.get("author") or {}
    author_fqid = _normalize_url(author_data.get("id"))

    if not entry_fqid:
        return False, "Missing entry id"

    if not author_fqid:
        return False, "Missing author.id"

    _upsert_remote_author(author_data)

    visibility = (payload.get("visibility") or "PUBLIC").upper()
    if visibility not in {"PUBLIC", "FRIENDS", "UNLISTED", "DELETED"}:
        visibility = "PUBLIC"

    existing = Entry.objects.filter(fqid=entry_fqid).first()
    if existing and (existing.is_deleted or existing.visibility == Entry.Visibility.DELETED):
        return True, f"Ignored repost of deleted entry {entry_fqid}"

    entry, created = Entry.objects.update_or_create(
        fqid=entry_fqid,
        defaults={
            "author_fqid": author_fqid,
            "title": payload.get("title", ""),
            "description": payload.get("description", ""),
            "content": payload.get("content", ""),
            "content_type": payload.get("contentType", "text/plain"),
            "visibility": visibility,
            "is_deleted": visibility == Entry.Visibility.DELETED,
        },
    )
    if created:
        entry.is_deleted = False
        entry.save(update_fields=["is_deleted"])

    return True, "Processed post"

def _process_comment_item(owner: Author, payload: dict):
    """
    Store a remote comment locally so entry detail pages can show it.
    """
    comment_fqid = _normalize_url(payload.get("id") or payload.get("fqid"))
    author_data = payload.get("author") or payload.get("author_data") or {}
    author_fqid = _normalize_url(author_data.get("id") or payload.get("author_fqid"))
    entry_fqid = _normalize_url(
        payload.get("entry")
        or payload.get("entry_fqid")
        or payload.get("object")
    )

    if not comment_fqid:
        return False, "Missing comment id"

    if not author_fqid:
        return False, "Missing author.id"

    if not entry_fqid:
        return False, "Missing entry reference"

    _upsert_remote_author(author_data)

    entry = Entry.objects.filter(fqid=entry_fqid).first()
    if entry is None:
        return False, "Target entry not found"

    Comment.objects.update_or_create(
        fqid=comment_fqid,
        defaults={
            "entry_fqid": entry_fqid,
            "entry": entry,
            "author_fqid": author_fqid,
            "author_data": author_data,
            "comment": payload.get("comment") or payload.get("content") or "",
            "content_type": payload.get("contentType") or payload.get("content_type") or "text/plain",
        },
    )

    return True, "Processed comment"


def _process_like_item(owner: Author, payload: dict):
    """
    Store a remote like locally so counts/liked-by-me work.
    """
    like_fqid = _normalize_url(payload.get("id") or payload.get("fqid"))
    author_data = payload.get("author") or payload.get("author_data") or {}
    author_fqid = _normalize_url(author_data.get("id") or payload.get("author_fqid"))
    object_fqid = _normalize_url(payload.get("object") or payload.get("object_fqid"))

    if not author_fqid:
        return False, "Missing author.id"

    if not object_fqid:
        return False, "Missing object"

    _upsert_remote_author(author_data)

    comment = Comment.objects.filter(fqid=object_fqid).first()
    entry = None if comment else Entry.objects.filter(fqid=object_fqid).first()

    if comment is None and entry is None:
        return False, "Target object not found"

    lookup = {"fqid": like_fqid} if like_fqid else {
        "object_fqid": object_fqid,
        "author_fqid": author_fqid,
    }

    Like.objects.update_or_create(
        **lookup,
        defaults={
            "author_fqid": author_fqid,
            "author_data": author_data,
            "object_fqid": object_fqid,
            "entry": entry,
            "comment": comment,
        },
    )

    return True, "Processed like"


def _process_unlike_item(owner: Author, payload: dict):
    """
    Remove a remote like locally.
    """
    author_data = payload.get("author") or {}
    author_fqid = _normalize_url(author_data.get("id") or payload.get("author_fqid"))
    object_fqid = _normalize_url(payload.get("object") or payload.get("object_fqid"))

    if not author_fqid:
        return False, "Missing author.id"

    if not object_fqid:
        return False, "Missing object"

    Like.objects.filter(
        object_fqid=object_fqid,
        author_fqid=author_fqid,
    ).delete()

    return True, "Processed unlike"


def _process_delete_item(owner: Author, payload: dict):
    raw_object = payload.get("object")
    
    if isinstance(raw_object, dict):
        entry_fqid = _normalize_url(
            raw_object.get("id")
            or raw_object.get("url")
            or payload.get("id")
            or payload.get("object_fqid")
        )
    else:
        entry_fqid = _normalize_url(
            payload.get("id")
            or raw_object
            or payload.get("object_fqid")
        )

    if not entry_fqid:
        return False, "Missing deleted entry id"

    entry = Entry.objects.filter(fqid=entry_fqid).first()
    if entry is None:
        alt = entry_fqid.rstrip("/")
        entry = Entry.objects.filter(fqid__iexact=alt).first()

    if entry is None:
        return False, f"Entry not found for delete: {entry_fqid}"

    entry.soft_delete()
    return True, f"Processed delete for {entry_fqid}"


def _process_inbox_payload(owner: Author, payload: dict):
    item_type = (payload.get("type") or "").lower()
    print(f"INBOX PAYLOAD type={item_type} keys={list(payload.keys())} visibility={payload.get('visibility')}")

    if item_type == "author_update":
        return _process_author_update_item(owner, payload)

    if item_type == "follow":
        return _process_follow_item(owner, payload)

    if item_type == "follow_accepted":
        return _process_follow_accepted_item(owner, payload)

    if item_type in {"entry", "post"}:
        return _process_post_item(owner, payload)

    if item_type == "comment":
        return _process_comment_item(owner, payload)

    if item_type == "like":
        return _process_like_item(owner, payload)

    if item_type == "unlike":
        return _process_unlike_item(owner, payload)

    if item_type in {"delete", "tombstone"}:
        return _process_delete_item(owner, payload)

    return False, f"Unsupported inbox object type: {item_type}"


@api_view(["GET", "POST", "DELETE"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def author_inbox(request, author_uuid):
    """
    Inbox endpoint for a given author.
    Typical route: /api/authors/<author_uuid>/inbox

    Supported methods:

    POST: Used by *remote nodes* or potentially local actions, to deliever an activity into
    this author's inbox. We store the payload as raw_json, and set processed=False. Returns the
    created InboxItem with a 201.

    GET: Returns a list of InboxItems, with the newest-first. This is an owner-only request.
      Example response:
        {
          "type": "inbox",
          "items": [ ...serialized InboxItem... ]
        }

    DELETE: Clears the inbox (bulk delete). This is an owner-only request. 
      Example response:
        {
          "type": "inbox",
          "items": [ ...serialized InboxItem... ]
        }
    """
    author = get_object_or_404(Author, uuid=author_uuid)

    # GET: Read inbox (owner-onnly)
    if request.method == "GET":
        # If kaylem's logged in, only kaylem should be able to see his inbox
        if not _is_owner(request, author): 
            return Response({"error": "Forbidden"}, status=status.HTTP_403_FORBIDDEN)

        # query all InboxItems addressed to this author by recipient_author_fqid
        items = InboxItem.objects.filter(recipient_author_fqid=author.fqid).order_by("-received_at")
        return Response({
            "type": "inbox",
            "items": InboxItemSerializer(items, many=True).data, # .data produces plain python structures
        }) # and response converts to actual json

    # DELETE: Delete a post made by the author of the inbox item.
    if request.method == "DELETE":
        # If the client is not the author of the inbox
        if not _is_owner(request, author): 
            return Response({"error": "Forbidden"}, status=status.HTTP_403_FORBIDDEN)

        InboxItem.objects.filter(recipient_author_fqid=author.fqid).delete()
        return Response({"success": True})

    # POST: check allow_incoming for known nodes
    source_node = _find_node_for_payload(request.data)
    if source_node is not None and not source_node.allow_incoming:
        return Response(
            {"error": "This node is not permitted to send to this inbox."},
            status=status.HTTP_403_FORBIDDEN,
        )

    # POST: Extract
    item_type = request.data.get("type", "").lower() or InboxItem.ItemType.ENTRY

    raw_object = request.data.get("object")
    if isinstance(raw_object, dict):
        object_fqid = raw_object.get("id") or raw_object.get("url")
    else:
        object_fqid = request.data.get("id") or raw_object

    item = InboxItem.objects.create(
        recipient_author_fqid=author.fqid,
        item_type=item_type,
        object_fqid=object_fqid,
        raw_json=request.data,
        processed=False,
    )

    ok, message = _process_inbox_payload(author, request.data)

    if ok:
        item.processed = True
        item.save(update_fields=["processed"])

    return Response(
        {
            "detail": message,
            "processed": ok,
            "item": InboxItemSerializer(item).data,
        },
        status=status.HTTP_201_CREATED,
    )
