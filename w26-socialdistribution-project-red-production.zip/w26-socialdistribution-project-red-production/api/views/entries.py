import uuid

from django.shortcuts import get_object_or_404

from rest_framework import status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from authors.models import Author, Follower
from entries.models import Entry
from entries.access import get_logged_in_author, can_view_entry
from api.serializers import EntrySerializer, EntryWriteSerializer
from nodes.services import find_node_for_fqid, post_to_author_inbox


# HELPERS

def paginate(items, request, default_size=10):
    """Reads ?page=N&size=N, slices queryset. 1-based page index."""
    try:
        page = max(1, int(request.GET.get('page', 1)))
        size = max(1, int(request.GET.get('size', default_size)))
    except ValueError:
        page, size = 1, default_size

    total = items.count()
    start = (page - 1) * size
    return items[start:start + size], page, size, total


def viewer_relation(viewer, author):
    """
    Returns how the viewer relates to the author.
    Used to decide which entries they are allowed to see.
    Returns: 'author' | 'friend' | 'follower' | 'public'
    """
    if viewer is None:
        return 'public'
    if viewer.fqid == author.fqid:
        return 'author'

    i_follow    = Follower.objects.filter(author=author, follower_fqid=viewer.fqid).exists()
    they_follow = Follower.objects.filter(author=viewer, follower_fqid=author.fqid).exists()

    if i_follow and they_follow:
        return 'friend'
    if i_follow:
        return 'follower'
    return 'public'


# GET /api/authors/<serial>/entries/
# POST /api/authors/<serial>/entries/
@api_view(["GET", "POST"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def entries_list(request, author_uuid):
    """
    GET /api/authors/<serial>/entries/
        Returns paginated entries from this author.
        Visibility rules based on who is asking:
            - Not authenticated         -> PUBLIC only
            - Authenticated as author   -> all entries
            - Authenticated as friend   -> PUBLIC + UNLISTED + FRIENDS
            - Authenticated as follower -> PUBLIC + UNLISTED

        Query params:
            page  - page number (1-based, default 1)
            size  - entries per page (default 10)

    POST /api/authors/<serial>/entries/
        Creates a new entry. Must be authenticated as this author.

        Request body:
            title       (optional, default "")
            description (optional, default "")
            contentType (text/plain | text/markdown | image/png;base64 | image/jpeg;base64)
            content     (required)
            visibility  (PUBLIC | UNLISTED | FRIENDS, default PUBLIC)
    """
    author = get_object_or_404(Author, uuid=author_uuid)

    # GET
    if request.method == "GET":
        viewer   = get_logged_in_author(request)
        relation = viewer_relation(viewer, author)

        vis_map = {
            'author':   ['PUBLIC', 'UNLISTED', 'FRIENDS'],
            'friend':   ['PUBLIC', 'UNLISTED', 'FRIENDS'],
            'follower': ['PUBLIC', 'UNLISTED'],
            'public':   ['PUBLIC'],
        }

        entries = Entry.objects.filter(
            author_fqid=author.fqid,
            is_deleted=False,
            visibility__in=vis_map[relation],
        ).order_by('-published')

        filtered_entries, page_number, size, total = paginate(entries, request)

        return Response({
            "type":        "entries",
            "page_number": page_number,
            "size":        size,
            "count":       total,
            "src":         EntrySerializer(filtered_entries, many=True).data,
        })



    # POST
    viewer = get_logged_in_author(request)
    if viewer is None:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)

    if viewer.fqid != author.fqid:
        return Response({"error": "Forbidden - not your author"}, status=status.HTTP_403_FORBIDDEN)

    serializer = EntryWriteSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    # might need to change the following:
    data = serializer.validated_data
    entry_uuid = uuid.uuid4()
    host = request.build_absolute_uri('/').rstrip('/')
    fqid = f"{host}/api/authors/{author.uuid}/entries/{entry_uuid}"

    entry = Entry.objects.create(
        uuid         = entry_uuid,
        fqid         = fqid,
        author_fqid  = author.fqid,
        title        = data.get('title', ''),
        description  = data.get('description', ''),
        content      = data['content'],
        content_type = data['contentType'],
        visibility   = data.get('visibility', 'PUBLIC'),
    )


    fanout_entry_to_remote_recipients(entry, author)
    
    return Response(EntrySerializer(entry).data, status=status.HTTP_201_CREATED)


# GET /api/authors/<serial>/entries/<entry_serial>/
# PUT /api/authors/<serial>/entries/<entry_serial>/
# DELETE /api/authors/<serial>/entries/<entry_serial>/
@api_view(["GET", "PUT", "DELETE"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def entry_detail(request, author_uuid, entry_uuid):
    """
    GET /api/authors/<serial>/entries/<entry_serial>/
        Get one entry. Visibility enforced via can_view_entry() via entries/access.py.

    PUT /api/authors/<serial>/entries/<entry_serial>/
        Update an entry. Must be authenticated as this author.
        All fields optional - only sent fields are updated.

        Request body (all optional):
            title, description, content, contentType, visibility

    DELETE /api/authors/<serial>/entries/<entry_serial>/
        Soft delete an entry. Must be authenticated as this author.
        Entry stays in the database but is hidden from UI and API.
    """
    author = get_object_or_404(Author, uuid=author_uuid)
    entry  = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid, is_deleted=False)

    viewer = get_logged_in_author(request)

    # GET
    if request.method == "GET":
        if not can_view_entry(viewer, entry):
            return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)
        return Response(EntrySerializer(entry).data)

    # PUT
    if request.method == "PUT":
        if viewer is None:
            return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)
        if viewer.fqid != author.fqid:
            return Response({"error": "Forbidden - not your entry"}, status=status.HTTP_403_FORBIDDEN)

        serializer = EntryWriteSerializer(data=request.data, partial=True)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        if 'title'       in data: entry.title        = data['title']
        if 'description' in data: entry.description  = data['description']
        if 'content'     in data: entry.content      = data['content']
        if 'contentType' in data: entry.content_type = data['contentType']
        if 'visibility'  in data: entry.visibility   = data['visibility']
        entry.save()

        fanout_entry_to_remote_recipients(entry, author)

        return Response(EntrySerializer(entry).data)

    # DELETE
    if viewer is None:
        return Response({"error": "Authentication required"}, status=status.HTTP_403_FORBIDDEN)
    if viewer.fqid != author.fqid:
        return Response({"error": "Forbidden - not your entry"}, status=status.HTTP_403_FORBIDDEN)

    fanout_entry_deletion_to_remote_recipients(entry, author)
    entry.soft_delete()
    return Response({"success": True}, status=status.HTTP_200_OK)


# GET /api/entries/<path:entry_fqid>/
@api_view(["GET"])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([AllowAny])
def entry_by_fqid(request, entry_fqid):
    """
    GET /api/entries/<path:entry_fqid>/
        Get an entry by its full URL (FQID).
        Uses <path:> URL converter because FQIDs contain slashes.
        FRIENDS ONLY
        
        Example:
        GET /api/entries/http%3A%2F%2Flocalhost%3A8000%2Fapi%2Fauthors%2Fabc%2Fentries%2F123
    """
    entry = Entry.objects.filter(fqid=entry_fqid, is_deleted=False).first()
    if not entry:
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    viewer = get_logged_in_author(request)
    if not can_view_entry(viewer, entry):
        return Response({"error": "Not found"}, status=status.HTTP_404_NOT_FOUND)

    return Response(EntrySerializer(entry).data)

def fanout_entry_deletion_to_remote_recipients(entry, author):
    """Push a delete notification to all remote recipients who received this entry."""
    followers = Follower.objects.filter(author=author)

    for rel in followers:
        recipient_fqid = rel.follower_fqid.rstrip("/")

        if entry.visibility == "FRIENDS":
            if not Follower.objects.filter(
                author__fqid=recipient_fqid,
                follower_fqid=author.fqid,
            ).exists():
                continue

        if Author.objects.filter(fqid=recipient_fqid, user__isnull=False).exists():
            continue

        node = find_node_for_fqid(recipient_fqid)
        if not node:
            continue

        payload = EntrySerializer(entry).data
        payload["type"] = "entry"
        payload["visibility"] = "DELETED"
        if not payload.get("description"):
            payload["description"] = payload.get("title") or "."

        try:
            resp = post_to_author_inbox(node, recipient_fqid, payload)
            if resp.status_code == 404:
                print(f"DELETE FANOUT 404 {recipient_fqid}: removing stale follower")
                Follower.objects.filter(author=author, follower_fqid=recipient_fqid).delete()
            elif resp.status_code >= 400:
                print(f"DELETE FANOUT FAILED {recipient_fqid}: {resp.status_code} {resp.text[:500]}")
        except Exception as e:
            print(f"DELETE FANOUT EXCEPTION {recipient_fqid}: {e}")


def fanout_entry_to_remote_recipients(entry, author):
    followers = Follower.objects.filter(author=author)

    for rel in followers:
        recipient_fqid = rel.follower_fqid.rstrip("/")

        if entry.visibility == "FRIENDS":
            if not Follower.objects.filter(
                author__fqid=recipient_fqid,
                follower_fqid=author.fqid,
            ).exists():
                continue

        if Author.objects.filter(fqid=recipient_fqid, user__isnull=False).exists():
            continue

        node = find_node_for_fqid(recipient_fqid)
        if not node:
            continue

        payload = EntrySerializer(entry).data
        payload["type"] = "entry"
        if not payload.get("description"):
            payload["description"] = payload.get("title") or "."

        try:
            resp = post_to_author_inbox(node, recipient_fqid, payload)
            if resp.status_code == 404:
                print(f"FANOUT 404 {recipient_fqid}: removing stale follower")
                Follower.objects.filter(author=author, follower_fqid=recipient_fqid).delete()
            elif resp.status_code >= 400:
                print(f"FANOUT FAILED {recipient_fqid}: {resp.status_code} {resp.text[:300]}")
        except Exception as e:
            print(f"FANOUT EXCEPTION {recipient_fqid}: {e}")
        