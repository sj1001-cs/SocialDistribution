from urllib.parse import quote

from django.test import TestCase
from django.contrib.auth.models import User

from authors.models import Author, Follower, FollowRequest


class ApiFollowersTests(TestCase):
    """Tests for the Followers API endpoints.

    Covers:
    - Listing followers for an author (public read)
    - Checking whether a specific foreign author is a follower (public read)
    - Accepting a pending follow request (requires auth as the target author)
    - Rejecting a pending follow request or removing an existing follower (requires auth)

    Endpoints under test:
    - GET    /api/authors/<author_uuid>/followers/
    - GET    /api/authors/<author_uuid>/followers/<foreign_fqid>/
    - PUT    /api/authors/<author_uuid>/followers/<foreign_fqid>/
    - DELETE /api/authors/<author_uuid>/followers/<foreign_fqid>/
    """

    def make_user_author(self, username: str):
        """Create a Django User and a linked local Author row for API tests.

        Uses defaults consistent with our app:
        - user is_active=True so login works
        - author is_approved=True so the author is treated as enabled
        """
        u = User.objects.create_user(username=username, password="pass12345", is_active=True)
        a = Author.objects.create(
            user=u,
            display_name=username,
            host="http://testserver/api/",
            fqid=f"http://testserver/api/authors/{username}",
            is_approved=True,
        )
        return u, a

    def login(self, username: str):
        """
        Login helper for Django test client.
        
        """
        ok = self.client.login(username=username, password="pass12345")
        self.assertTrue(ok)

    def setUp(self):
        """
        
        Create two authors: Alice and Bob..
        
        """
        self.alice_u, self.alice_a = self.make_user_author("alice")
        self.bob_u, self.bob_a = self.make_user_author("bob")

    def test_followers_list_no_auth_required(self):
        """
        GET followers list is public and returns follower author objects (or minimal fallbacks).
        
        """
        Follower.objects.create(author=self.alice_a, follower_fqid=self.bob_a.fqid)

        url = f"/api/authors/{self.alice_a.uuid}/followers/"
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)

        data = resp.json()
        self.assertEqual(data["type"], "followers")
        self.assertTrue(
            any(
                (item.get("id") == self.bob_a.fqid) or (item.get("displayName") == self.bob_a.display_name)
                for item in data["followers"]
            )
        )

    def test_follower_detail_get_no_auth_required(self):
        """
        
        GET follower detail is public: returns 200 when foreign author is a follower.
        
        """
        Follower.objects.create(author=self.alice_a, follower_fqid=self.bob_a.fqid)

        foreign_encoded = quote(self.bob_a.fqid, safe="")
        url = f"/api/authors/{self.alice_a.uuid}/followers/{foreign_encoded}/"

        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)

    def test_follower_detail_put_accept_requires_auth_and_creates_follower(self):
        """PUT follower detail accepts a pending follow request (must be auth as target author).

        Expected:
        - Unauthenticated -> 403
        - Authenticated as wrong user -> 403
        - Authenticated as target author -> 200 + follower relation created
        """
        FollowRequest.objects.create(
            requester_fqid=self.bob_a.fqid,
            target=self.alice_a,
            requester_data={"id": self.bob_a.fqid, "displayName": self.bob_a.display_name},
            status=FollowRequest.Status.PENDING,
        )

        foreign_encoded = quote(self.bob_a.fqid, safe="")
        url = f"/api/authors/{self.alice_a.uuid}/followers/{foreign_encoded}/"

        resp = self.client.put(url)
        self.assertEqual(resp.status_code, 403)

        self.login("bob")
        resp2 = self.client.put(url)
        self.assertEqual(resp2.status_code, 403)

        self.client.logout()
        self.login("alice")
        resp3 = self.client.put(url)
        self.assertEqual(resp3.status_code, 200)

        self.assertTrue(Follower.objects.filter(author=self.alice_a, follower_fqid=self.bob_a.fqid).exists())

    def test_follower_detail_delete_rejects_pending_request_or_removes_follower(self):
        """DELETE follower detail either rejects a pending request or removes an existing follower.

        Case 1:
        - If a pending FollowRequest exists, DELETE should mark it REJECTED.

        Case 2:
        - If a follower relationship exists, DELETE should remove the Follower row.
        """
        foreign_encoded = quote(self.bob_a.fqid, safe="")
        url = f"/api/authors/{self.alice_a.uuid}/followers/{foreign_encoded}/"

        # --- Case 1: pending follow request -> rejected ---
        fr = FollowRequest.objects.create(
            requester_fqid=self.bob_a.fqid,
            target=self.alice_a,
            requester_data={"id": self.bob_a.fqid, "displayName": self.bob_a.display_name},
            status=FollowRequest.Status.PENDING,
        )

        self.login("alice")
        resp = self.client.delete(url)
        self.assertEqual(resp.status_code, 200)

        fr.refresh_from_db()
        self.assertEqual(fr.status, FollowRequest.Status.REJECTED)

        # --- Case 2: follower exists -> removed ---
        # Ensure follow requests do not block the follower removal check
        FollowRequest.objects.filter(target=self.alice_a, requester_fqid=self.bob_a.fqid).delete()

        Follower.objects.create(author=self.alice_a, follower_fqid=self.bob_a.fqid)
        resp2 = self.client.delete(url)
        self.assertEqual(resp2.status_code, 200)
        self.assertFalse(Follower.objects.filter(author=self.alice_a, follower_fqid=self.bob_a.fqid).exists())