"""
Shared helpers for API tests. Used to allow tests to focus on behaviour rather
than repeated enviornment settup in every file.
"""

import uuid

from django.contrib.auth.models import User

from authors.models import Author, Follower
from entries.models import Comment, Entry


class ApiTestHelpers:
    """
    Factory helpers used across api testing. These help create local authors and
    local objects using the same FQID conventations as the API views.
    """

    password = "pass12345"

    def make_user_author(self, username: str, approved: bool = True):
        """
        Use when trying to quickly make a author object. Author is linked to a 
        user and both objects ref's are returned.
        """
        user = User.objects.create_user(
            username=username,
            password=self.password,
            is_active=True,
        )
        author = Author.objects.create(
            user=user,
            display_name=username,
            host="http://testserver/api/",
            fqid=f"http://testserver/api/authors/{username}",
            is_approved=approved,
        )
        return user, author

    def login(self, username: str):
        """
        Use when trying to login under username. Make sure to call make_user_author beforehand
        """
        ok = self.client.login(username=username, password=self.password)
        self.assertTrue(ok)

    def make_entry(
        self,
        author: Author,
        *,
        visibility: str = Entry.Visibility.PUBLIC,
        title: str = "",
        description: str = "",
        content: str = "hello world",
        content_type: str = "text/plain",
        is_deleted: bool = False,
    ):
        """
        Make an entry under an author object. Returns an entry object.
        """
        entry_uuid = uuid.uuid4()
        return Entry.objects.create(
            uuid=entry_uuid,
            fqid=f"http://testserver/api/authors/{author.uuid}/entries/{entry_uuid}",
            author_fqid=author.fqid,
            title=title,
            description=description,
            content=content,
            content_type=content_type,
            visibility=visibility,
            is_deleted=is_deleted,
        )

    def make_comment(
        self,
        author: Author,
        entry: Entry,
        *,
        text: str = "nice post",
        content_type: str = "text/plain",
    ):
        comment_uuid = uuid.uuid4()
        return Comment.objects.create(
            uuid=comment_uuid,
            fqid=f"http://testserver/api/authors/{author.uuid}/commented/{comment_uuid}",
            entry_fqid=entry.fqid,
            entry=entry,
            author_fqid=author.fqid,
            author_data=author.to_json(),
            comment=text,
            content_type=content_type,
        )

    def make_follow(self, followed: Author, follower: Author):
        """
        Create the accepted-follow row that means `follower` follows `followed`.
        """
        return Follower.objects.create(author=followed, follower_fqid=follower.fqid)
