import base64
import uuid

from django.test import TestCase
from django.contrib.auth.models import User

from authors.models import Author
from entries.models import Entry


class ApiImageTests(TestCase):
    """Tests for the Entry Image API endpoint.

    These tests verify that image entries can be served as real image bytes
    from the API.

    Endpoint under test:
    - GET /api/authors/<author_uuid>/entries/<entry_uuid>/image
    """

    def make_user_author(self, username: str):
        """
        Create a Django User and linked Author row for image endpoint tests.
        
        """
        u = User.objects.create_user(username=username, password="pass12345", is_active=True)
        a = Author.objects.create(
            user=u,
            display_name=username,
            host="http://testserver/api/",
            fqid=f"http://testserver/api/authors/{username}",
            is_approved=True,
        )
        return u, a

    def test_entry_image_returns_binary_for_public_image(self):
        """
        GET image returns image bytes and the correct Content-Type for PUBLIC image entries.
        
        """
        _, alice_a = self.make_user_author("alice")

        # Minimal PNG header + bytes so we can validate binary response content
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"fakepngdata"
        b64 = base64.b64encode(png_bytes).decode("ascii")

        entry = Entry.objects.create(
            uuid=uuid.uuid4(),
            fqid=f"http://testserver/api/authors/{alice_a.uuid}/entries/1",
            author_fqid=alice_a.fqid,
            title="img",
            content=b64,
            content_type="image/png;base64",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )

        url = f"/api/authors/{alice_a.uuid}/entries/{entry.uuid}/image"
        resp = self.client.get(url)

        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp["Content-Type"], "image/png")
        self.assertEqual(resp.content, png_bytes)

    def test_entry_image_404_if_not_image(self):
        """
        GET image returns 404 when the entry is not an image content type.
        
        """
        _, alice_a = self.make_user_author("alice2")

        entry = Entry.objects.create(
            uuid=uuid.uuid4(),
            fqid=f"http://testserver/api/authors/{alice_a.uuid}/entries/2",
            author_fqid=alice_a.fqid,
            content="hello",
            content_type="text/plain",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )

        url = f"/api/authors/{alice_a.uuid}/entries/{entry.uuid}/image"
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 404)