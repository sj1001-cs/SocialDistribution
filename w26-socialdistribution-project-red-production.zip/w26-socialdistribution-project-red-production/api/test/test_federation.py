"""
Part 3 federation tests

Covers node-to-node communication requirements -->
- NODE_MANAGEMENT-NODE_ADMIN.6  Add nodes to connect with
- NODE_MANAGEMENT-NODE_ADMIN.7  Remove / disable nodes
- NODE_MANAGEMENT-NODE_ADMIN.9  HTTP Basic Auth for node-to-node
- NODE_MANAGEMENT-NODE_ADMIN.10 Prevent unauthorized nodes from connecting
- POSTING-AUTHOR.2              Fanout entries to remote followers on create
- POSTING-AUTHOR.3              Fanout updated entries to remote followers on edit
- POSTING-AUTHOR.4              Fanout deleted entries to remote followers on delete
- FOLLOWING-AUTHOR.2            Follow a remote author (POST follow to remote inbox)
"""

import json
from unittest.mock import MagicMock, patch
from urllib.parse import quote

from django.test import TestCase

from authors.models import Author, Follower, FollowRequest
from entries.models import Entry
from nodes.models import Node

from api.test.helpers import ApiTestHelpers

# Helpers

def make_node(host="http://remote.example", api_base="http://remote.example/api",
              username="remoteuser", password="remotepass",
              is_active=True, allow_incoming=True, allow_outgoing=True):
    """
    Creates a node. User is automatically set to active. Default is set to:
        host="http://remote.example"
        api_base="http://remote.example/api"
        username="remoteuser"
        password="remotepass"

    """
    return Node.objects.create(
        host=host,
        api_base=api_base,
        username=username,
        password=password,
        is_active=is_active,
        allow_incoming=allow_incoming,
        allow_outgoing=allow_outgoing,
    )


def make_remote_author(fqid="http://remote.example/api/authors/remote-bob"):
    """ stub author record representing a user on a remote node (no local User)."""
    return Author.objects.create(
        display_name="remote-bob",
        host="http://remote.example/api/",
        fqid=fqid,
        is_approved=True,
    )



# NODE_MANAGEMENT-NODE_ADMIN.6 / .7
# Add, disable, and remove nodes

class NodeManagementTests(TestCase):
    """
    NODE_MANAGEMENT-NODE_ADMIN.6  As a node admin, I want to be able to add nodes to share with.
    NODE_MANAGEMENT-NODE_ADMIN.7  As a node admin, I want to be able to remove nodes and stop sharing.
    NODE_MANAGEMENT-NODE_ADMIN.11 As a node admin, I can disable node-to-node interfaces.
    """

    def test_add_node_persists_to_database(self):
        node = make_node()
        self.assertTrue(Node.objects.filter(host="http://remote.example").exists())
        self.assertEqual(node.username, "remoteuser")
        self.assertTrue(node.is_active)
        self.assertTrue(node.allow_outgoing)
        self.assertTrue(node.allow_incoming)

    def test_remove_node_stops_outgoing_discovery(self):
        from nodes.services import find_node_for_fqid
        node = make_node()
        fqid = "http://remote.example/api/authors/someone"
        # check fqid exist
        self.assertIsNotNone(find_node_for_fqid(fqid))
        # delete node, check for fqid again
        node.delete()
        self.assertIsNone(find_node_for_fqid(fqid))

    def test_disable_node_stops_outgoing_requests(self):
        from nodes.services import find_node_for_fqid
        node = make_node()
        fqid = "http://remote.example/api/authors/someone"

        self.assertIsNotNone(find_node_for_fqid(fqid))
        # disable node, make sure you can't lookup the fqid on disabled node
        node.is_active = False
        node.save()
        self.assertIsNone(find_node_for_fqid(fqid))

    def test_allow_outgoing_false_stops_outgoing_requests(self):
        from nodes.services import find_node_for_fqid
        make_node(allow_outgoing=False)
        fqid = "http://remote.example/api/authors/someone"
        self.assertIsNone(find_node_for_fqid(fqid))



# NODE_MANAGEMENT-NODE_ADMIN.9 / .10
# HTTP Basic Auth — node-to-node

class NodeBasicAuthTests(TestCase, ApiTestHelpers):
    """
    NODE_MANAGEMENT-NODE_ADMIN.9  Node-to-node connections authenticated with HTTP Basic Auth.
    NODE_MANAGEMENT-NODE_ADMIN.10 Prevent nodes without valid credentials from connecting.
    """

    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")

    def test_inbox_post_accepted_with_valid_basic_auth(self):
        """ remote node can POST to inbox using valid HTTP Basic Auth credentials """
        payload = {
            "type": "follow",
            "actor": {"type": "author", "id": "http://remote.example/api/authors/bob"},
            "object": {"type": "author", "id": self.alice.fqid},
            "summary": "bob wants to follow alice",
        }
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/inbox/",
            data=json.dumps(payload),
            content_type="application/json",
            HTTP_AUTHORIZATION="Basic YWxpY2U6cGFzczEyMzQ1",  # alice:pass12345 -> base64
        )
        self.assertEqual(resp.status_code, 201)

    def test_inbox_post_accepted_without_auth_for_open_delivery(self):
        """
        inbox POST is intentionally open so remote nodes can deliver without
        pre-registering — Basic Auth is used when we call OUT, not enforced on in
        """
        payload = {
            "type": "follow",
            "actor": {"type": "author", "id": "http://remote.example/api/authors/bob"},
            "object": {"type": "author", "id": self.alice.fqid},
        }
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/inbox/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)

    def test_inbox_get_rejected_without_auth(self):
        """GET inbox requires owner auth — unauthenticated requests get 403."""
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/inbox/")
        self.assertEqual(resp.status_code, 403)

    def test_inbox_get_rejected_for_wrong_user(self):
        """GET inbox is owner-only — another user cannot read it"""
        self.make_user_author("eve")
        self.login("eve")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/inbox/")
        self.assertEqual(resp.status_code, 403)

    def test_outgoing_requests_use_basic_auth(self):
        """post_to_author_inbox sends HTTP Basic Auth credentials with every request"""
        node = make_node(username="nodeuser", password="nodepass")
        with patch("nodes.services.requests.post") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            from nodes.services import post_to_author_inbox
            post_to_author_inbox(node, "http://remote.example/api/authors/bob", {"type": "test"})
            call_kwargs = mock_post.call_args
            auth = call_kwargs[1]["auth"]
            self.assertEqual(auth.username, "nodeuser")
            self.assertEqual(auth.password, "nodepass")


# POSTING-AUTHOR.2
# Fanout new entry to remote followers

class EntryFanoutCreateTests(TestCase, ApiTestHelpers):
    """
    POSTING-AUTHOR.2  As an author, I want my node to send my entries to my
                      remote followers so that remote authors following me can see them.
    """

    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")
        self.node = make_node()
        # remote-bob is a follower of alice on a remote node
        self.remote_bob_fqid = "http://remote.example/api/authors/remote-bob"
        Follower.objects.create(author=self.alice, follower_fqid=self.remote_bob_fqid)

    def test_create_public_entry_via_api_fans_out_to_remote_follower(self):
        with patch("api.views.entries.post_to_author_inbox") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            self.login("alice")
            resp = self.client.post(
                f"/api/authors/{self.alice.uuid}/entries/",
                data=json.dumps({
                    "title": "Hello remote",
                    "contentType": "text/plain",
                    "content": "hi remote bob",
                    "visibility": "PUBLIC",
                }),
                content_type="application/json",
            )
            self.assertEqual(resp.status_code, 201)
            mock_post.assert_called_once()
            node_arg, fqid_arg, payload_arg = mock_post.call_args[0]
            self.assertEqual(fqid_arg, self.remote_bob_fqid)
            self.assertEqual(payload_arg["content"], "hi remote bob")

    def test_create_unlisted_entry_does_not_fan_out(self):
        """ UNLISTED entries are not pushed to remote followers """
        with patch("api.views.entries.post_to_author_inbox") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            self.login("alice")
            self.client.post(
                f"/api/authors/{self.alice.uuid}/entries/",
                data=json.dumps({
                    "contentType": "text/plain",
                    "content": "secret",
                    "visibility": "UNLISTED",
                }),
                content_type="application/json",
            )
            mock_post.assert_not_called()

    def test_create_friends_entry_only_fans_out_to_mutual_followers(self):
        """FRIENDS entries are only pushed to remote followers who also follow back."""
        mutual_fqid = "http://remote.example/api/authors/mutual-friend"
        mutual_author = Author.objects.create(
            display_name="mutual",
            host="http://remote.example/api/",
            fqid=mutual_fqid,
            is_approved=True,
        )
        # mutual follows alice back
        Follower.objects.create(author=mutual_author, follower_fqid=self.alice.fqid)
        Follower.objects.create(author=self.alice, follower_fqid=mutual_fqid)

        with patch("api.views.entries.post_to_author_inbox") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            self.login("alice")
            self.client.post(
                f"/api/authors/{self.alice.uuid}/entries/",
                data=json.dumps({
                    "contentType": "text/plain",
                    "content": "friends only",
                    "visibility": "FRIENDS",
                }),
                content_type="application/json",
            )
            # only mutual friend should receive it, not remote-bob (one-way follower)
            called_fqids = [call[0][1] for call in mock_post.call_args_list]
            self.assertIn(mutual_fqid, called_fqids)
            self.assertNotIn(self.remote_bob_fqid, called_fqids)

    def test_local_followers_are_not_fanned_out_to(self):
        """Local followers fetch entries themselves — they must not receive a remote push."""
        local_user, local_author = self.make_user_author("charlie")
        Follower.objects.create(author=self.alice, follower_fqid=local_author.fqid)

        with patch("api.views.entries.post_to_author_inbox") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            self.login("alice")
            self.client.post(
                f"/api/authors/{self.alice.uuid}/entries/",
                data=json.dumps({
                    "contentType": "text/plain",
                    "content": "hi",
                    "visibility": "PUBLIC",
                }),
                content_type="application/json",
            )
            called_fqids = [call[0][1] for call in mock_post.call_args_list]
            self.assertNotIn(local_author.fqid, called_fqids)


# POSTING-AUTHOR.3
# Fanout edited entry to remote followers

class EntryFanoutEditTests(TestCase, ApiTestHelpers):
    """
    POSTING-AUTHOR.3  As an author, I want my node to re-send entries I've edited
                      to everywhere they were already sent.
    """

    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")
        self.node = make_node()
        self.remote_bob_fqid = "http://remote.example/api/authors/remote-bob"
        Follower.objects.create(author=self.alice, follower_fqid=self.remote_bob_fqid)
        self.entry = self.make_entry(self.alice, content="original", visibility=Entry.Visibility.PUBLIC)

    def test_edit_entry_via_api_fans_out_updated_entry(self):
        with patch("api.views.entries.post_to_author_inbox") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            self.login("alice")
            resp = self.client.put(
                f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/",
                data=json.dumps({"content": "updated content"}),
                content_type="application/json",
            )
            self.assertEqual(resp.status_code, 200)
            mock_post.assert_called_once()
            node_arg, fqid_arg, payload_arg = mock_post.call_args[0]
            self.assertEqual(fqid_arg, self.remote_bob_fqid)
            self.assertEqual(payload_arg["content"], "updated content")


# POSTING-AUTHOR.4
# Fanout deleted entry to remote followers

class EntryFanoutDeleteTests(TestCase, ApiTestHelpers):
    """
    POSTING-AUTHOR.4  As an author, I want my node to re-send entries I've deleted
                      so remote users don't keep seeing them.
    """

    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")
        self.node = make_node()
        self.remote_bob_fqid = "http://remote.example/api/authors/remote-bob"
        Follower.objects.create(author=self.alice, follower_fqid=self.remote_bob_fqid)
        self.entry = self.make_entry(self.alice, content="to be deleted", visibility=Entry.Visibility.PUBLIC)

    def test_delete_entry_via_api_sends_deletion_notification(self):
        with patch("api.views.entries.post_to_author_inbox") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            self.login("alice")
            resp = self.client.delete(
                f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/",
            )
            self.assertEqual(resp.status_code, 200)
            mock_post.assert_called_once()
            node_arg, fqid_arg, payload_arg = mock_post.call_args[0]
            self.assertEqual(fqid_arg, self.remote_bob_fqid)
            self.assertEqual(payload_arg["type"], "delete")
            self.assertEqual(payload_arg["id"], self.entry.fqid)

    def test_delete_entry_is_soft_deleted_locally(self):
        """Entry must remain in DB after deletion (for admin audit trail)."""
        with patch("api.views.entries.post_to_author_inbox"):
            self.login("alice")
            self.client.delete(
                f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/",
            )
            self.entry.refresh_from_db()
            self.assertTrue(self.entry.is_deleted)


# FOLLOWING-AUTHOR.2
# Follow a remote author

class RemoteFollowTests(TestCase, ApiTestHelpers):
    """
    FOLLOWING-AUTHOR.2  As an author, I want to follow remote authors so I can
                        see their entries.
    """

    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")
        self.node = make_node()
        self.remote_bob_fqid = "http://remote.example/api/authors/remote-bob"

    def test_follow_remote_author_posts_to_remote_inbox(self):
        """PUT /following/<remote_fqid>/ must POST a Follow object to the remote inbox."""
        encoded = quote(self.remote_bob_fqid, safe="")
        with patch("api.views.following.post_to_author_inbox") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            self.login("alice")
            resp = self.client.put(f"/api/authors/{self.alice.uuid}/following/{encoded}/")
            self.assertIn(resp.status_code, (200, 201))
            mock_post.assert_called_once()
            _, fqid_arg, payload_arg = mock_post.call_args[0]
            self.assertEqual(fqid_arg, self.remote_bob_fqid)
            self.assertEqual(payload_arg["type"], "Follow")

    def test_follow_remote_author_creates_follow_request_locally(self):
        """A local FollowRequest record must be created when following a remote author."""
        encoded = quote(self.remote_bob_fqid, safe="")
        with patch("api.views.following.post_to_author_inbox") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            self.login("alice")
            self.client.put(f"/api/authors/{self.alice.uuid}/following/{encoded}/")
            self.assertTrue(
                FollowRequest.objects.filter(
                    requester_fqid=self.alice.fqid,
                ).exists()
            )


# Inbox receives remote entry and stores it locally

class InboxReceiveEntryTests(TestCase, ApiTestHelpers):
    """
    Verifies that when a remote node POSTs an entry to our inbox, it is saved
    locally so it can appear in the recipient's stream
    """

    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")

    def test_inbox_post_entry_saves_to_local_db(self):
        remote_entry_fqid = "http://remote.example/api/authors/bob/entries/entry-1"
        payload = {
            "type": "entry",
            "id": remote_entry_fqid,
            "title": "Remote post",
            "contentType": "text/plain",
            "content": "hello from remote",
            "visibility": "PUBLIC",
            "author": {
                "type": "author",
                "id": "http://remote.example/api/authors/bob",
                "displayName": "bob",
                "host": "http://remote.example/api/",
            },
        }
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/inbox/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)
        self.assertTrue(Entry.objects.filter(fqid=remote_entry_fqid).exists())

    def test_inbox_post_delete_removes_entry_locally(self):
        """ a delete notification sent to the inbox soft-deletes the local copy."""
        remote_entry_fqid = "http://remote.example/api/authors/bob/entries/entry-2"
        Entry.objects.create(
            fqid=remote_entry_fqid,
            author_fqid="http://remote.example/api/authors/bob",
            content="will be deleted",
            content_type="text/plain",
            visibility="PUBLIC",
        )
        payload = {"type": "delete", "id": remote_entry_fqid}
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/inbox/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)
        entry = Entry.objects.get(fqid=remote_entry_fqid)
        self.assertTrue(entry.is_deleted)

# NODE_MANAGEMENT-NODE_ADMIN.12
# API objects identified by full URL (FQID)

class FQIDTests(TestCase, ApiTestHelpers):
    """
    NODE_MANAGEMENT-NODE_ADMIN.12  API objects must be identified by their full URL
                                   to prevent collisions with other nodes.
    """

    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")

    def test_author_id_is_full_url(self):
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data["id"].startswith("http"))
        self.assertIn("/api/authors/", data["id"])

    def test_entry_id_is_full_url(self):
        entry = self.make_entry(self.alice)
        self.login("alice")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data["id"].startswith("http"))
        self.assertIn("/entries/", data["id"])
