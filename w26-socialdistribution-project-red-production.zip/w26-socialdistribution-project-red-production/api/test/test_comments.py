import json

from django.test import TestCase

from entries.models import Comment, Like

from api.test.helpers import ApiTestHelpers


class ApiCommentsTests(TestCase, ApiTestHelpers):
    """
    Tests for comment and comment-like API endpoints

    These tests cover:
    - GET/POST /api/authors/<author_uuid>/entries/<entry_uuid>/comments/
    - GET /api/authors/<author_uuid>/entries/<entry_uuid>/comments/<comment_uuid>/likes/
    - POST/DELETE /api/authors/<author_uuid>/entries/<entry_uuid>/comments/<comment_uuid>/like/
    """
    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")
        self.bob_user, self.bob = self.make_user_author("bob")
        self.entry = self.make_entry(self.alice, content="commentable entry")

    def test_entry_comments_get_and_post(self):
        existing = self.make_comment(self.alice, self.entry, text="first comment")

        # GET returns existing comments for the entry.
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/comments/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data["type"], "comments")
        self.assertEqual(len(data["comments"]), 1)
        self.assertEqual(data["comments"][0]["id"], existing.fqid)

        # POST creates a new comment for the logged-in author.
        self.login("bob")
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/comments/",
            data=json.dumps({
                "comment": "second comment",
                "contentType": "text/plain",
            }),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)

        created = resp.json()
        self.assertEqual(created["type"], "comment")
        self.assertEqual(created["author"]["id"], self.bob.fqid)
        self.assertTrue(Comment.objects.filter(entry_fqid=self.entry.fqid, comment="second comment").exists())

    def test_entry_comments_post_requires_authenticated_author(self):
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/comments/",
            data=json.dumps({
                "comment": "anonymous comment",
                "contentType": "text/plain",
            }),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 403)

    def test_comment_like_endpoints_return_and_toggle_state(self):
        comment = self.make_comment(self.alice, self.entry, text="please like this")

        # Bob likes the comment through the dedicated API endpoint.
        self.login("bob")
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/comments/{comment.uuid}/like/"
        )
        self.assertEqual(resp.status_code, 201)
        self.assertTrue(resp.json()["liked"])
        self.assertEqual(resp.json()["count"], 1)

        # The comment-likes collection should include Bob's like.
        resp = self.client.get(
            f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/comments/{comment.uuid}/likes/"
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data["type"], "likes")
        self.assertEqual(len(data["likes"]), 1)
        self.assertEqual(data["likes"][0]["author"]["id"], self.bob.fqid)

        # DELETE removes the like and updates the returned count.
        resp = self.client.delete(
            f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/comments/{comment.uuid}/like/"
        )
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(resp.json()["liked"])
        self.assertEqual(resp.json()["count"], 0)

        self.assertFalse(Like.objects.filter(object_fqid=comment.fqid, author_fqid=self.bob.fqid).exists())
