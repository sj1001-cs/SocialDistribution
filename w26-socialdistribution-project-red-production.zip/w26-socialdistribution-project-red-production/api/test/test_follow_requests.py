from django.test import TestCase
from django.contrib.auth.models import User

from authors.models import Author, FollowRequest


class ApiFollowRequestsTests(TestCase):
    """Tests for the Follow Requests API endpoint.

    Covers:
    - Authentication/authorization rules (must be logged in as the author)
    - Response shape for listing pending follow requests

    Endpoint under test:
    GET /api/authors/<author_uuid>/follow_requests/
    """

    def make_user_author(self, username: str):
        """Create a Django User and a linked local Author row for API tests.

        Uses simple defaults consistent with our app:
        - user is_active=True so login works
        - author is_approved=True so the author behaves like an enabled account
        """
        u = User.objects.create_user(username=username, password="pass12345", is_active=True)
        a = Author.objects.create(
            user=u,
            display_name=username,
            host="http://testserver/api/",
            fqid=f"http://testserver/api/authors/{username}",
            is_approved=True,
        )
        return u, a

    def login(self, username: str):
        """
        Login helper for Django test client.
        
        """
        ok = self.client.login(username=username, password="pass12345")
        self.assertTrue(ok)

    def setUp(self):
        """
        Create two authors: Alice and Bob.
        
        """
        self.alice_u, self.alice_a = self.make_user_author("alice")
        self.bob_u, self.bob_a = self.make_user_author("bob")

    def test_follow_requests_list_requires_auth_as_author(self):
        """GET follow_requests must be authenticated as the author being queried.

        Expected:
        - Unauthenticated users receive 403
        - Authenticated users who are NOT that author also receive 403
        """
        url = f"/api/authors/{self.alice_a.uuid}/follow_requests/"

        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 403)

        self.login("bob")
        resp2 = self.client.get(url)
        self.assertEqual(resp2.status_code, 403)

    def test_follow_requests_list_returns_pending(self):
        """GET follow_requests returns pending follow requests for the author.

        Setup:
        - Bob has a pending FollowRequest targeting Alice

        Expected:
        - 200 OK
        - JSON has type="follow_requests"
        - follow_requests list contains the pending request
        """
        FollowRequest.objects.create(
            requester_fqid=self.bob_a.fqid,
            target=self.alice_a,
            requester_data={"id": self.bob_a.fqid, "displayName": self.bob_a.display_name},
            status=FollowRequest.Status.PENDING,
        )

        self.login("alice")
        url = f"/api/authors/{self.alice_a.uuid}/follow_requests/"
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)

        data = resp.json()
        self.assertEqual(data["type"], "follow_requests")
        self.assertEqual(len(data["follow_requests"]), 1)