from django.test import TestCase
from api.test.helpers import ApiTestHelpers


class FQIDTests(TestCase, ApiTestHelpers):

    def setUp(self):
        self.user, self.author = self.make_user_author("alice")

    def test_author_api_id_is_full_url(self):
        """Author id in API response is a full URL, not just a serial."""
        resp = self.client.get(f"/api/authors/{self.author.uuid}/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data["id"].startswith("http"))
        self.assertIn("authors", data["id"])

    def test_entry_api_id_is_full_url(self):
        """Entry id in API response is a full URL, not just a serial."""
        entry = self.make_entry(self.author, content="test")
        resp = self.client.get(f"/api/authors/{self.author.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data["id"].startswith("http"))
        self.assertIn(str(entry.uuid), data["id"])

    def test_comment_api_id_is_full_url(self):
        """Comment id in API response is a full URL, not just a serial."""
        entry = self.make_entry(self.author, content="test")
        self.make_comment(self.author, entry)
        resp = self.client.get(f"/api/authors/{self.author.uuid}/entries/{entry.uuid}/comments/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        comments = data.get("src") or data.get("comments") or data
        if isinstance(comments, list):
            self.assertTrue(comments[0]["id"].startswith("http"))
        else:
            self.assertTrue(comments["src"][0]["id"].startswith("http"))