from django.test import TestCase

from entries.models import Like

from api.test.helpers import ApiTestHelpers


class ApiLikesTests(TestCase, ApiTestHelpers):
    """
    Tests for entry-like API endpoints.

    These tests cover:
    - GET /api/authors/<author_uuid>/entries/<entry_uuid>/likes/
    - POST/DELETE /api/authors/<author_uuid>/entries/<entry_uuid>/like/
    """
    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")
        self.bob_user, self.bob = self.make_user_author("bob")
        self.entry = self.make_entry(self.alice, content="liked entry")

    def test_entry_likes_returns_visible_like_objects(self):
        Like.objects.create(
            fqid=f"http://testserver/api/authors/{self.bob.uuid}/liked/1",
            author_fqid=self.bob.fqid,
            author_data=self.bob.to_json(),
            object_fqid=self.entry.fqid,
            entry=self.entry,
        )

        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/likes/")
        self.assertEqual(resp.status_code, 200)

        data = resp.json()
        self.assertEqual(data["type"], "likes")
        self.assertEqual(len(data["likes"]), 1)
        self.assertEqual(data["likes"][0]["author"]["id"], self.bob.fqid)

    def test_my_entry_like_requires_auth_and_toggles_state(self):
        # Anonymous users cannot like entries.
        resp = self.client.post(f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/like/")
        self.assertEqual(resp.status_code, 403)

        self.login("bob")

        # POST creates the like and returns the new aggregate state.
        resp = self.client.post(f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/like/")
        self.assertEqual(resp.status_code, 201)
        data = resp.json()
        self.assertTrue(data["liked"])
        self.assertEqual(data["count"], 1)

        # Repeating POST should not duplicate the like.
        resp = self.client.post(f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/like/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["count"], 1)

        # DELETE removes the like and reports the updated count.
        resp = self.client.delete(f"/api/authors/{self.alice.uuid}/entries/{self.entry.uuid}/like/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertFalse(data["liked"])
        self.assertEqual(data["count"], 0)
