"""
Tests for IDENTITY-AUTHOR.3
GitHub activity is automatically turned into public entries.
"""
from unittest.mock import patch

from django.test import TestCase

from authors.github import sync_github_activity, _extract_username
from entries.models import Entry
from api.test.helpers import ApiTestHelpers


class GitHubSyncTests(TestCase, ApiTestHelpers):

    def setUp(self):
        self.user, self.author = self.make_user_author("alice")
        self.author.github = "https://github.com/alice"
        self.author.save()

    def test_extract_username_from_github_url(self):
        """Pulls the username out of a GitHub profile URL."""
        self.assertEqual(_extract_username("https://github.com/torvalds"), "torvalds")
        self.assertEqual(_extract_username("https://github.com/alice"), "alice")
        self.assertEqual(_extract_username(""), None)
        self.assertEqual(_extract_username(None), None)

    @patch("authors.github.requests.get")
    def test_github_events_become_public_entries(self, mock_get):
        """
        IDENTITY-AUTHOR.3
        New GitHub events are turned into PUBLIC entries.
        """
        mock_get.return_value.status_code = 200
        mock_get.return_value.raise_for_status = lambda: None
        mock_get.return_value.json.return_value = [
            {
                "id": "abc123",
                "type": "PushEvent",
                "repo": {"name": "alice/myrepo"},
                "payload": {
                    "commits": [{"message": "fix bug"}]
                },
            }
        ]

        created = sync_github_activity(self.author)
        self.assertEqual(created, 1)

        entry = Entry.objects.get(author_fqid=self.author.fqid)
        self.assertEqual(entry.visibility, Entry.Visibility.PUBLIC)
        self.assertIn("alice/myrepo", entry.title)
        self.assertEqual(entry.content_type, "text/plain")

    @patch("authors.github.requests.get")
    def test_duplicate_events_not_imported_twice(self, mock_get):
        """
        IDENTITY-AUTHOR.3
        The same GitHub event is not imported more than once.
        """
        event = {
            "id": "abc123",
            "type": "WatchEvent",
            "repo": {"name": "alice/myrepo"},
            "payload": {},
        }
        mock_get.return_value.raise_for_status = lambda: None
        mock_get.return_value.json.return_value = [event]

        sync_github_activity(self.author)
        sync_github_activity(self.author)

        self.assertEqual(Entry.objects.filter(author_fqid=self.author.fqid).count(), 1)

    @patch("authors.github.requests.get")
    def test_github_unreachable_does_not_crash(self, mock_get):
        """
        IDENTITY-AUTHOR.3
        If GitHub is down, the stream still loads fine.
        """
        mock_get.side_effect = Exception("network error")

        created = sync_github_activity(self.author)
        self.assertEqual(created, 0)

    def test_no_github_url_skips_sync(self):
        """
        IDENTITY-AUTHOR.3
        Authors without a GitHub URL are skipped gracefully.
        """
        self.author.github = ""
        self.author.save()

        created = sync_github_activity(self.author)
        self.assertEqual(created, 0)
        self.assertEqual(Entry.objects.filter(author_fqid=self.author.fqid).count(), 0)

#adding more after meeting with Kiran

    @patch("authors.github.requests.get")
    def test_create_event_becomes_entry(self, mock_get):
        """
        IDENTITY-AUTHOR.3
        A CreateEvent (new repo/branch) becomes a public entry.
        """
        mock_get.return_value.raise_for_status = lambda: None
        mock_get.return_value.json.return_value = [
            {
                "id": "create001",
                "type": "CreateEvent",
                "repo": {"name": "alice/newrepo"},
                "payload": {
                    "ref_type": "repository",
                    "ref": "newrepo",
                    "description": "My new repo",
                },
            }
        ]

        created = sync_github_activity(self.author)
        self.assertEqual(created, 1)
        entry = Entry.objects.get(author_fqid=self.author.fqid)
        self.assertIn("newrepo", entry.title)
        self.assertEqual(entry.visibility, Entry.Visibility.PUBLIC)


    @patch("authors.github.requests.get")
    def test_issues_event_becomes_entry(self, mock_get):
        """
        IDENTITY-AUTHOR.3
        An IssuesEvent (opened/closed issue) becomes a public entry.
        """
        mock_get.return_value.raise_for_status = lambda: None
        mock_get.return_value.json.return_value = [
            {
                "id": "issue001",
                "type": "IssuesEvent",
                "repo": {"name": "alice/myrepo"},
                "payload": {
                    "action": "opened",
                    "issue": {"title": "Bug in login flow"},
                },
            }
        ]

        created = sync_github_activity(self.author)
        self.assertEqual(created, 1)
        entry = Entry.objects.get(author_fqid=self.author.fqid)
        self.assertIn("Bug in login flow", entry.title)


    @patch("authors.github.requests.get")
    def test_pull_request_event_becomes_entry(self, mock_get):
        """
        IDENTITY-AUTHOR.3
        A PullRequestEvent becomes a public entry.
        """
        mock_get.return_value.raise_for_status = lambda: None
        mock_get.return_value.json.return_value = [
            {
                "id": "pr001",
                "type": "PullRequestEvent",
                "repo": {"name": "alice/myrepo"},
                "payload": {
                    "action": "opened",
                    "pull_request": {"title": "Add dark mode"},
                },
            }
        ]

        created = sync_github_activity(self.author)
        self.assertEqual(created, 1)
        entry = Entry.objects.get(author_fqid=self.author.fqid)
        self.assertIn("Add dark mode", entry.title)


    @patch("authors.github.requests.get")
    def test_fork_event_becomes_entry(self, mock_get):
        """
        IDENTITY-AUTHOR.3
        A ForkEvent becomes a public entry.
        """
        mock_get.return_value.raise_for_status = lambda: None
        mock_get.return_value.json.return_value = [
            {
                "id": "fork001",
                "type": "ForkEvent",
                "repo": {"name": "torvalds/linux"},
                "payload": {
                    "forkee": {"full_name": "alice/linux"},
                },
            }
        ]

        created = sync_github_activity(self.author)
        self.assertEqual(created, 1)
        entry = Entry.objects.get(author_fqid=self.author.fqid)
        self.assertIn("torvalds/linux", entry.title)


    @patch("authors.github.requests.get")
    def test_multiple_events_all_imported(self, mock_get):
        """
        IDENTITY-AUTHOR.3
        Multiple different events in one sync all become entries.
        """
        mock_get.return_value.raise_for_status = lambda: None
        mock_get.return_value.json.return_value = [
            {
                "id": "push999",
                "type": "PushEvent",
                "repo": {"name": "alice/myrepo"},
                "payload": {"commits": [{"message": "initial commit"}]},
            },
            {
                "id": "star999",
                "type": "WatchEvent",
                "repo": {"name": "django/django"},
                "payload": {},
            },
            {
                "id": "issue999",
                "type": "IssuesEvent",
                "repo": {"name": "alice/myrepo"},
                "payload": {
                    "action": "closed",
                    "issue": {"title": "Fix navbar"},
                },
            },
        ]

        created = sync_github_activity(self.author)
        self.assertEqual(created, 3)
        self.assertEqual(Entry.objects.filter(author_fqid=self.author.fqid).count(), 3)


