

import json

from django.test import TestCase

from authors.models import Author

from api.test.helpers import ApiTestHelpers


class ApiAuthorsTests(TestCase, ApiTestHelpers):
    """
    Tests for the author list/detail API endpoints.

    These tests cover the DRF author views:
    - GET /api/authors/
    - GET /api/authors/<author_uuid>/
    - PUT /api/authors/<author_uuid>/
    """
    def test_authors_list_returns_only_approved_local_authors(self):
        # Approved local authors should appear in the collection
        _, alice = self.make_user_author("alice")
        _, bob = self.make_user_author("bob")

        # Unapproved local authors should not appear
        self.make_user_author("pending", approved=False)

        # Remote authors also should not appear because the view filters user__isnull=False
        Author.objects.create(
            display_name="remote",
            host="http://remote.example/api/",
            fqid="http://remote.example/api/authors/remote",
            is_approved=True,
        )

        resp = self.client.get("/api/authors/")
        self.assertEqual(resp.status_code, 200)

        data = resp.json()
        self.assertEqual(data["type"], "authors")
        returned_ids = {item["id"] for item in data["authors"]}
        self.assertEqual(returned_ids, {alice.fqid, bob.fqid})

    def test_author_detail_get_returns_serialized_author(self):
        _, alice = self.make_user_author("alice")

        resp = self.client.get(f"/api/authors/{alice.uuid}/")
        self.assertEqual(resp.status_code, 200)

        data = resp.json()
        self.assertEqual(data["type"], "author")
        self.assertEqual(data["id"], alice.fqid)
        self.assertEqual(data["displayName"], alice.display_name)

    def test_author_detail_put_requires_owner_and_updates_profile(self):
        _, alice = self.make_user_author("alice")
        _, bob = self.make_user_author("bob")

        payload = {
            "displayName": "Alice Updated",
            "description": "new desc",
            "github": "https://github.com/alice",
            "profileImage": "https://example.com/alice.png",
        }

        # Anonymous callers cannot update a profile
        resp = self.client.put(
            f"/api/authors/{alice.uuid}/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 403)

        # A different author also cannot update Alice's profile
        self.login("bob")
        resp = self.client.put(
            f"/api/authors/{alice.uuid}/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 403)

        # The owner can update their own profile
        self.client.logout()
        self.login("alice")
        resp = self.client.put(
            f"/api/authors/{alice.uuid}/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 200)

        alice.refresh_from_db()
        self.assertEqual(alice.display_name, "Alice Updated")
        self.assertEqual(alice.description, "new desc")
        self.assertEqual(alice.github, "https://github.com/alice")
        self.assertEqual(alice.profile_image, "https://example.com/alice.png")
