import json

from django.test import TestCase

from inbox.models import InboxItem

from api.test.helpers import ApiTestHelpers


class ApiInboxTests(TestCase, ApiTestHelpers):
    """
    Tests for the inbox API endpoint.

    Inbox tested for node-to-node delievery, and it's permissions for each method:
    - POST is open & can accept into the inbox
    - GET & DELETE should be owner only
    """
    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")
        self.bob_user, self.bob = self.make_user_author("bob")

    def test_inbox_post_creates_item_without_owner_auth(self):
        payload = {
            "type": "follow",
            "object": "http://remote.example/api/authors/remote",
            "summary": "remote wants to follow alice",
        }

        # POST is intentionally open so other nodes can deliver objects.
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/inbox/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)

        data = resp.json()
        self.assertEqual(data["itemType"], "follow")
        self.assertEqual(data["recipient_author_fqid"], self.alice.fqid)
        self.assertEqual(data["object_fqid"], payload["object"])
        self.assertFalse(data["processed"])

        self.assertTrue(InboxItem.objects.filter(recipient_author_fqid=self.alice.fqid, object_fqid=payload["object"]).exists())

    def test_inbox_get_and_delete_require_owner(self):
        InboxItem.objects.create(
            recipient_author_fqid=self.alice.fqid,
            item_type=InboxItem.ItemType.ENTRY,
            object_fqid="http://testserver/api/authors/alice/entries/1",
            raw_json={"type": "entry", "id": "http://testserver/api/authors/alice/entries/1"},
            processed=False,
        )

        # Anonymous callers cannot read the inbox.
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/inbox/")
        self.assertEqual(resp.status_code, 403)

        # A different logged-in author also cannot read or clear it
        self.login("bob")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/inbox/")
        self.assertEqual(resp.status_code, 403)
        resp = self.client.delete(f"/api/authors/{self.alice.uuid}/inbox/")
        self.assertEqual(resp.status_code, 403)

        # The owner can read and clear their inbox
        self.client.logout()
        self.login("alice")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/inbox/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data["type"], "inbox")
        self.assertEqual(len(data["items"]), 1)

        resp = self.client.delete(f"/api/authors/{self.alice.uuid}/inbox/")
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(InboxItem.objects.filter(recipient_author_fqid=self.alice.fqid).exists())
