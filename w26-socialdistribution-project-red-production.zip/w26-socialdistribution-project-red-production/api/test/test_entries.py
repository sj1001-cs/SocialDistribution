import json
from urllib.parse import quote

from django.test import TestCase

from entries.models import Entry

from api.test.helpers import ApiTestHelpers


class ApiEntriesTests(TestCase, ApiTestHelpers):
    """
    Tests for the entry collection/detail API endpoints.

    These tests cover the remaining DRF entry views that were previously untested:
    - GET/POST /api/authors/<author_uuid>/entries/
    - GET/PUT/DELETE /api/authors/<author_uuid>/entries/<entry_uuid>/
    - GET /api/entries/<entry_fqid>/
    """
    def setUp(self):
        self.alice_user, self.alice = self.make_user_author("alice")
        self.bob_user, self.bob = self.make_user_author("bob")

    def test_entries_list_get_respects_visibility_for_anonymous_and_owner(self):
        public_entry = self.make_entry(self.alice, content="public", visibility=Entry.Visibility.PUBLIC)
        self.make_entry(self.alice, content="friends", visibility=Entry.Visibility.FRIENDS)
        self.make_entry(self.alice, content="unlisted", visibility=Entry.Visibility.UNLISTED)

        # Anonymous callers should only get Alice's public entries.
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/")
        self.assertEqual(resp.status_code, 200)

        data = resp.json()
        self.assertEqual(data["type"], "entries")
        self.assertEqual(data["count"], 1)
        self.assertEqual(data["src"][0]["id"], public_entry.fqid)

        # The entry owner should be able to see all non-deleted entries.
        self.login("alice")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["count"], 3)

    def test_entries_list_post_creates_entry_for_owner(self):
        self.login("alice")

        payload = {
            "title": "Hello",
            "description": "API-created entry",
            "contentType": "text/plain",
            "content": "hello world",
            "visibility": "PUBLIC",
        }
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/entries/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)

        data = resp.json()
        self.assertEqual(data["type"], "entry")
        self.assertEqual(data["content"], "hello world")
        self.assertTrue(Entry.objects.filter(author_fqid=self.alice.fqid, content="hello world").exists())

    def test_entry_detail_put_and_delete_require_owner(self):
        entry = self.make_entry(self.alice, title="before", content="before")

        update_payload = {
            "title": "after",
            "content": "updated content",
        }

        # Non-owners cannot update or delete the entry.
        self.login("bob")
        resp = self.client.put(
            f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/",
            data=json.dumps(update_payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 403)

        resp = self.client.delete(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 403)

        # The owner can update and soft-delete it.
        self.client.logout()
        self.login("alice")
        resp = self.client.put(
            f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/",
            data=json.dumps(update_payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 200)

        entry.refresh_from_db()
        self.assertEqual(entry.title, "after")
        self.assertEqual(entry.content, "updated content")

        resp = self.client.delete(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 200)

        entry.refresh_from_db()
        self.assertTrue(entry.is_deleted)
        self.assertEqual(entry.visibility, Entry.Visibility.DELETED)

    def test_entry_by_fqid_returns_entry_when_visible(self):
        entry = self.make_entry(self.alice, content="reachable by fqid")

        # Quote the full URL so the path converter receives the full FQID.
        encoded_fqid = quote(entry.fqid, safe="")
        resp = self.client.get(f"/api/entries/{encoded_fqid}/")
        self.assertEqual(resp.status_code, 200)

        data = resp.json()
        self.assertEqual(data["id"], entry.fqid)
        self.assertEqual(data["content"], "reachable by fqid")

    def test_deleted_entry_stays_in_database(self):
        """
        NODE_MANAGEMENT-NODE_ADMIN.14
        Deleted entries must remain in the DB so the admin can see what was deleted.
        """
        entry = self.make_entry(self.alice, content="will be deleted")
        entry_uuid = entry.uuid

        self.login("alice")
        resp = self.client.delete(f"/api/authors/{self.alice.uuid}/entries/{entry_uuid}/")
        self.assertEqual(resp.status_code, 200)

        # Row still exists in the database
        entry_in_db = Entry.objects.get(uuid=entry_uuid)
        self.assertTrue(entry_in_db.is_deleted)
        self.assertEqual(entry_in_db.visibility, Entry.Visibility.DELETED)


    def test_deleted_entry_hidden_from_api(self):
        """
        NODE_MANAGEMENT-NODE_ADMIN.14
        Deleted entries must not appear in the API (GET list or GET detail).
        """
        entry = self.make_entry(self.alice, content="deleted entry")

        self.login("alice")
        self.client.delete(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")

        # Must not appear in the entry list (even for the owner)
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/")
        self.assertEqual(resp.status_code, 200)
        fqids_in_list = [e["id"] for e in resp.json()["src"]]
        self.assertNotIn(entry.fqid, fqids_in_list)

        # Must return 404 on direct GET
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 404)


    def test_deleted_entry_hidden_from_all_viewers(self):
        """
        Deleted entries are hidden from everyone — owner, other users, and anonymous.
        """
        entry = self.make_entry(self.alice, content="secret deleted")

        self.login("alice")
        self.client.delete(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.client.logout()

        # Anonymous
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 404)

        # Another logged-in user
        self.login("bob")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 404)
    
    def test_unlisted_entry_visible_to_anyone_with_link(self):
        """
        VISIBILITY-AUTHOR.2
        An unlisted entry is accessible by URL to anyone, including
        anonymous users and users who don't follow the author.
        """
        entry = self.make_entry(self.alice, content="secret link", visibility=Entry.Visibility.UNLISTED)

        # Anonymous can access it directly by URL
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["visibility"], "UNLISTED")

        # A non-follower logged-in user can also access it by URL
        self.login("bob")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/{entry.uuid}/")
        self.assertEqual(resp.status_code, 200)

    def test_unlisted_entry_visible_to_follower_in_list(self):
        """
        VISIBILITY-AUTHOR.2
        Followers see unlisted entries when listing an author's entries.
        Non-followers and anonymous do not see unlisted in the list.
        """
        self.make_entry(self.alice, content="unlisted post", visibility=Entry.Visibility.UNLISTED)

        # Anonymous should NOT see unlisted in the entry list
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["count"], 0)

        # Bob is not yet following Alice — should not see it
        self.login("bob")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["count"], 0)

        # Bob follows Alice — now he should see it
        self.client.logout()
        self.make_follow(followed=self.alice, follower=self.bob)
        self.login("bob")
        resp = self.client.get(f"/api/authors/{self.alice.uuid}/entries/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["count"], 1)
        self.assertEqual(resp.json()["src"][0]["visibility"], "UNLISTED")

    def test_unlisted_entry_accessible_by_fqid_anonymously(self):
        """
        VISIBILITY-AUTHOR.2
        Anyone who has the FQID of an unlisted entry can access it without logging in.
        """
        entry = self.make_entry(
            self.alice,
            content="only if you have the link",
            visibility=Entry.Visibility.UNLISTED,
        )

        encoded_fqid = quote(entry.fqid, safe="")
        resp = self.client.get(f"/api/entries/{encoded_fqid}/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["content"], "only if you have the link")

    def test_author_can_create_unlisted_entry(self):
        """
        VISIBILITY-AUTHOR.2
        Authors can create entries with visibility UNLISTED via the API.
        """
        self.login("alice")
        payload = {
            "title": "Unlisted post",
            "contentType": "text/plain",
            "content": "not on the public feed",
            "visibility": "UNLISTED",
        }
        resp = self.client.post(
            f"/api/authors/{self.alice.uuid}/entries/",
            data=json.dumps(payload),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)
        self.assertEqual(resp.json()["visibility"], "UNLISTED")
        self.assertTrue(
            Entry.objects.filter(
                author_fqid=self.alice.fqid,
                visibility=Entry.Visibility.UNLISTED,
            ).exists()
        )