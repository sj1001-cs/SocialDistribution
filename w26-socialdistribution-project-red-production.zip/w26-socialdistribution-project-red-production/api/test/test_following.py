import uuid
from urllib.parse import quote

from django.test import TestCase
from django.contrib.auth.models import User

from authors.models import Author, Follower, FollowRequest


class ApiFollowingTests(TestCase):
    """Tests for the Following API endpoints.

    “Following” is the set of authors that a given author follows.

    Covers:
    - Listing who an author is following (requires auth as that author)
    - Checking if a given foreign author is being followed (requires auth as that author)
    - Creating a follow request via PUT (local behavior)
    - Unfollowing via DELETE (removes follower relationship on the target author)

    Endpoints under test:
    - GET    /api/authors/<author_uuid>/following/
    - GET    /api/authors/<author_uuid>/following/<foreign_fqid>/
    - PUT    /api/authors/<author_uuid>/following/<foreign_fqid>/
    - DELETE /api/authors/<author_uuid>/following/<foreign_fqid>/
    """

    def make_user_author(self, username: str):
        """Create a Django User and linked local Author row for API tests.

        Uses defaults consistent with our app:
        - user is_active=True so login works
        - author is_approved=True so the author behaves like an enabled account
        """
        u = User.objects.create_user(username=username, password="pass12345", is_active=True)
        a = Author.objects.create(
            user=u,
            display_name=username,
            host="http://testserver/api/",
            fqid=f"http://testserver/api/authors/{username}",
            is_approved=True,
        )
        return u, a

    def login(self, username: str):
        """
        Login helper for Django test client.
        
        """
        ok = self.client.login(username=username, password="pass12345")
        self.assertTrue(ok)

    def setUp(self):
        """
        
        Create two authors: Alice and Bob.
        
        """
        self.alice_u, self.alice_a = self.make_user_author("alice")
        self.bob_u, self.bob_a = self.make_user_author("bob")

    def test_following_list_requires_auth_as_author(self):
        """GET following list requires authentication as the author being queried.

        Expected:
        - Unauthenticated users get 403
        - Authenticated users who are NOT that author also get 403
        """
        url = f"/api/authors/{self.alice_a.uuid}/following/"
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 403)

        self.login("bob")
        resp2 = self.client.get(url)
        self.assertEqual(resp2.status_code, 403)

    def test_following_list_returns_following(self):
        """GET following list returns authors that the viewer is following.

        Setup:
        - Alice follows Bob, stored as: Follower(author=bob, follower_fqid=alice.fqid)

        Expected:
        - 200 OK
        - JSON contains type="following"
        - Returned list includes Bob (either full Author object or fallback)
        """
        # alice follows bob => Follower(author=bob, follower_fqid=alice.fqid)
        Follower.objects.create(author=self.bob_a, follower_fqid=self.alice_a.fqid)

        self.login("alice")
        url = f"/api/authors/{self.alice_a.uuid}/following/"
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)

        data = resp.json()
        self.assertEqual(data["type"], "following")
        self.assertTrue(
            any(
                (item.get("id") == self.bob_a.fqid) or (item.get("displayName") == self.bob_a.display_name)
                for item in data["following"]
            )
        )

    def test_following_detail_get_put_delete(self):
        """GET/PUT/DELETE following detail.

        Flow:
        - GET before following exists -> 404
        - PUT -> creates a FollowRequest (local behavior)
        - Simulate accepted follow by creating a Follower row
        - GET -> now 200
        - DELETE -> unfollow (removes follower relationship)
        """
        foreign_encoded = quote(self.bob_a.fqid, safe="")
        url = f"/api/authors/{self.alice_a.uuid}/following/{foreign_encoded}/"

        # GET requires auth as alice
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 403)

        self.login("alice")

        # not following => 404
        resp2 = self.client.get(url)
        self.assertEqual(resp2.status_code, 404)

        # PUT creates follow request
        resp3 = self.client.put(url)
        self.assertIn(resp3.status_code, (200, 201))
        self.assertTrue(
            FollowRequest.objects.filter(
                requester_fqid=self.alice_a.fqid,
                target=self.bob_a,
            ).exists()
        )

        # simulate accepted follow
        Follower.objects.get_or_create(author=self.bob_a, follower_fqid=self.alice_a.fqid)

        # GET now succeeds
        resp4 = self.client.get(url)
        self.assertEqual(resp4.status_code, 200)

        # DELETE unfollows (removes follower row on target bob)
        resp5 = self.client.delete(url)
        self.assertEqual(resp5.status_code, 200)
        self.assertFalse(Follower.objects.filter(author=self.bob_a, follower_fqid=self.alice_a.fqid).exists()) 