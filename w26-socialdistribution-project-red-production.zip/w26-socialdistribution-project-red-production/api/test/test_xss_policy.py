import os
import re

from django.test import TestCase


class XSSPolicyTests(TestCase):
    """
    NODE_MANAGEMENT-NODE_ADMIN.15
    The UI must only communicate with its own node's web server to prevent XSS.
    All fetch() calls in templates use relative URLs (/api/...) not external URLs.
    """

    def test_no_external_fetch_calls_in_templates(self):
        """
        Scans all template files to confirm no fetch() calls target
        external URLs. All calls must use relative paths starting with /.
        """
        external_fetch = re.compile(r'fetch\([`"\']https?://')

        violations = []
        for template_dir in ["entries/templates", "authors/templates", "socialdistribution/templates"]:
            for root, _, files in os.walk(template_dir):
                for fname in files:
                    if not fname.endswith(".html"):
                        continue
                    fpath = os.path.join(root, fname)
                    with open(fpath) as f:
                        for lineno, line in enumerate(f, 1):
                            if external_fetch.search(line):
                                violations.append(f"{fpath}:{lineno}: {line.strip()}")

        self.assertEqual(
            violations, [],
            "Found fetch() calls to external URLs (XSS violation):\n" + "\n".join(violations)
        )