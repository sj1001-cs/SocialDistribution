from django.db import models
import uuid

# Create your models here.
class Entry(models.Model):
    """
    Represents any post made by an author

    Any entry may be:
        - PUBLIC --> everyone can see it
        - FRIENDS --> only mutuals
        - UNLISTED  --> friends, followers, and anyone with the link
        - DELETED --> hidden from UI, but still in DB
    
   Deleted entries are not removed from the db (required in our spec), 
   instead they're marked as deleted and hidden from UI. 
    """
    class Visibility(models.TextChoices):
        PUBLIC = "PUBLIC"
        FRIENDS = "FRIENDS"
        UNLISTED = "UNLISTED"
        DELETED  = "DELETED"

    # Internal uuid for local db for tracking
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique = True)
    # must match the original URL where the entry was created
    fqid = models.URLField(unique=True) #distributed identity
    # Store author FQID instead of foreign key for now
    author_fqid = models.URLField() # url of author who made this

    title = models.CharField(max_length=255, blank=True, default="")
    description = models.CharField(max_length=255, blank=True, default="")
    # content_type --> determines how the content is rendered
    # e.g text/plain , text/markdown , image/png or jpeg (base64) ...
    content_type = models.CharField(max_length=100,default="text/plain")    
    # Main body of entry --> for images, the should contain base64 data
    content = models.TextField(blank=True,default="")

    # Who can see this entry
    visibility = models.CharField(
        max_length=20,
        choices=Visibility.choices,
        default=Visibility.PUBLIC
    )

    published = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    is_deleted = models.BooleanField(default = False)
    

    # useful for query --> sort by newest 
    class Meta:
        ordering = ["-published"]

    def __str__(self) -> str:
        return f"{self.title or '(no title)'} [{self.visibility}]"
    
    def soft_delete(self):
        self.is_deleted = True
        self.visibility = self.Visibility.DELETED
        self.save(update_fields=["is_deleted", "visibility", "updated"])


class Comment(models.Model):
    """
    A comment made by an author on an entry.
    Lets assume that a comment is not an entry and it cascades once the entry gets deleted

    The comment is OWNED by the commenter (stored on their node).
    The entry may be on a DIFFERENT node (remote).

    FQID pattern: http://nodeA/api/authors/<serial>/commented/<serial>

    When someone comments on a remote entry:
        --> Comment is saved here locally
        --> Comment object is POSTed to the entry author's inbox
    """

    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    # Full URL of this comment
    # ex)"http://node1/api/authors/111/commented/130" or "http://node1/authors/111/commented/130" idk remove this comment if someone understands it
    fqid = models.URLField(unique=True)

    # Full URL of the entry being commented on (local or remote)
    entry_fqid = models.URLField()

    # If the entry is LOCAL, this FK links directly to it
    # Null if entry is on a remote node (maybe we change it later on idk)
    entry = models.ForeignKey(
        Entry,
        on_delete=models.CASCADE,
        related_name="comments",
        null=True,
        blank=True
    )
    # Full URL of the author who wrote this comment
    author_fqid = models.URLField()
    # commenter's author JSON
    author_data = models.JSONField(null=True, blank=True)
    # comment text
    comment = models.TextField()
    # text/plain or text/markdown --> idk if image/png is a thing we want to do, but lets not for now cuz tired
    content_type = models.CharField(max_length=50, default="text/plain")
    published = models.DateTimeField(auto_now_add=True)

    # query for newest
    class Meta:
        ordering = ["-published"]

    def __str__(self):
        return f"Comment by {self.author_fqid} on {self.entry_fqid}"


class Like(models.Model):
    """
    A like by an author on either an Entry or a Comment.

    object_fqid = full URL of whatever was liked (entry or comment)

    FQID pattern: http://nodeA/api/authors/<serial>/liked/<serial>

    When someone likes a remote entry:
        --> Like is saved here locally
        --> Like object is POSTed to the entry author's inbox
    """

    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    # Full URL of this like object
    # "http://node1/api/authors/111/liked/166" or "http://node1/authors/111/liked/166" idk
    fqid = models.URLField(unique=True)

    # Full URL of whoever gave the like
    author_fqid = models.URLField()

    # liker's author JSON
    author_data = models.JSONField(null=True, blank=True)

    # Full URL of the thing that was liked (entry or comment)
    object_fqid = models.URLField()

    # If liked object is a LOCAL ENTRY, FK links directly to it
    entry = models.ForeignKey(
        Entry,
        on_delete=models.CASCADE,
        related_name="likes",
        null=True,
        blank=True
    )

    # If liked object is a LOCAL COMMENT, FK links directly to it
    comment = models.ForeignKey(
        Comment,
        on_delete=models.CASCADE,
        related_name="likes",
        null=True,
        blank=True
    )

    published = models.DateTimeField(auto_now_add=True)

    # query the latest
    class Meta:
        ordering = ["-published"]
        # One like per author per object --> no double likes
        unique_together = ("author_fqid", "object_fqid")

    def __str__(self):
        return f"Like by {self.author_fqid} on {self.object_fqid}"
