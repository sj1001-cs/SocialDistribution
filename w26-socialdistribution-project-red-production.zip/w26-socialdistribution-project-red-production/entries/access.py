from authors.models import Author, Follower
from .models import Entry

"""
Helper functions used for verifying access, seeing who's logged in
quickly finding friends, follwers, and entry visibility for the api
when dealing with requests.
"""
def get_logged_in_author(request):
    if not request.user.is_authenticated:
        return None

    try:
        return request.user.author
    except Author.DoesNotExist:
        return None


def friend_fqids(author):
    if author is None:
        return set()
    return author.friend_fqids()


def following_fqids(author):
    if author is None:
        return set()

    return set(
        Follower.objects.filter(follower_fqid=author.fqid).values_list(
            "author__fqid",
            flat=True,
        )
    )


def can_view_entry(viewer, entry):
    if entry.is_deleted or entry.visibility == Entry.Visibility.DELETED:
        return False

    if entry.visibility == Entry.Visibility.PUBLIC:
        return True

    if entry.visibility == Entry.Visibility.UNLISTED:
        return True

    if viewer is None:
        return False

    if entry.author_fqid == viewer.fqid:
        return True

    if entry.visibility == Entry.Visibility.FRIENDS:
        return entry.author_fqid in friend_fqids(viewer)

    return False