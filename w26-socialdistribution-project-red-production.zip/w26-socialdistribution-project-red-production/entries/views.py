# Create your views here.
import json
import uuid
import base64

from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import Http404, HttpResponseForbidden, JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.views.decorators.http import require_POST, require_http_methods

from authors.github import sync_github_activity

from .models import Entry, Like, Comment
from authors.models import Follower, Author
from api.views.entries import fanout_entry_deletion_to_remote_recipients, fanout_entry_to_remote_recipients
from api.serializers import CommentSerializer, LikeSerializer
from nodes.services import find_node_for_fqid, post_to_author_inbox
from inbox.models import InboxItem

def _entry_author_data(entry):
    cached_author_data = getattr(entry, "author_data", None)
    if cached_author_data:
        return cached_author_data

    author = Author.objects.filter(fqid=entry.author_fqid).first()
    if author:
        return author.to_json()

    return {
        "type": "author",
        "id": entry.author_fqid,
        "host": "",
        "displayName": "Unknown",
        "github": "",
        "profileImage": "",
        "web": "",
    }


def _get_logged_in_author(request):
    if not request.user.is_authenticated:
        return None

    try:
        return request.user.author
    except Author.DoesNotExist:
        return None


def _friend_fqids(author):
    if author is None:
        return set()
    return author.friend_fqids()


def _following_fqids(author):
    if author is None:
        return set()

    return set(
        Follower.objects.filter(follower_fqid=author.fqid).values_list(
            "author__fqid",
            flat=True,
        )
    )


def _can_view_entry(viewer, entry):
    if entry.is_deleted or entry.visibility == Entry.Visibility.DELETED:
        return False

    if entry.visibility == Entry.Visibility.PUBLIC:
        return True

    if entry.visibility == Entry.Visibility.UNLISTED:
        return True

    if viewer is None:
        return False

    if entry.author_fqid == viewer.fqid:
        return True

    if entry.visibility == Entry.Visibility.FRIENDS:
        return entry.author_fqid in _friend_fqids(viewer)

    return False


def _attach_stream_metadata(entry, viewer):
    local_author = Author.objects.filter(fqid=entry.author_fqid).first()
    entry.author_data = _entry_author_data(entry)
    entry.author_uuid = local_author.uuid if local_author else None
    entry.author_profile_url = ""
    entry.detail_url = ""
    entry.can_edit = viewer is not None and entry.author_fqid == viewer.fqid
    entry.edit_url = ""
    entry.delete_url = ""

    if local_author:
        entry.author_profile_url = reverse("profile", args=[local_author.uuid])
        entry.detail_url = reverse("entry_detail", args=[local_author.uuid, entry.uuid])

    elif entry.author_data.get("web"):
        entry.author_profile_url = entry.author_data["web"]

    if entry.can_edit and viewer is not None:
        entry.edit_url = reverse("edit_entry", args=[viewer.uuid, entry.uuid])
        entry.delete_url = reverse("delete_entry", args=[viewer.uuid, entry.uuid])
    
    #likes
    entry.like_count = Like.objects.filter(object_fqid=entry.fqid).count()
    entry.liked_by_me = (
        viewer is not None
        and Like.objects.filter(object_fqid=entry.fqid, author_fqid=viewer.fqid).exists()
    )
    #comments
    entry.comment_count = Comment.objects.filter(entry_fqid=entry.fqid).count()

@login_required
def stream_view(request):
    """
    GET /stream/

    Renders the stream page.

    Public tab  --> all PUBLIC entries on this node (not deleted)
    Friends tab --> FRIENDS entries where logged-in author is friends
                  with the author + their own entries
    """
    me = _get_logged_in_author(request)
    if me is None:
        messages.error(request, "Your account is missing an author profile.")
        return redirect("login")
    
    if me.github:
        new_entries = sync_github_activity(me)
        for entry in new_entries:
            fanout_entry_to_remote_recipients(entry, me)

    tab = request.GET.get("tab", "public")
    following = _following_fqids(me)
    friends = _friend_fqids(me)

    # Entry fqids that were delivered directly to my inbox — these should always
    # be visible to me regardless of whether a Follower record exists yet.
    inbox_entry_fqids = set(
        InboxItem.objects.filter(
            recipient_author_fqid=me.fqid,
            item_type__in=["entry", "post"],
        ).values_list("object_fqid", flat=True)
    )

    if tab == "friends":
        entries = Entry.objects.filter(
            Q(author_fqid=me.fqid)
            | Q(author_fqid__in=friends, visibility=Entry.Visibility.FRIENDS)
            | Q(author_fqid__in=friends, visibility=Entry.Visibility.UNLISTED)
            | Q(author_fqid__in=friends, visibility=Entry.Visibility.PUBLIC)
            | Q(fqid__in=inbox_entry_fqids, visibility=Entry.Visibility.FRIENDS)
        )
    elif tab == "home":
        entries = Entry.objects.filter(
            Q(author_fqid=me.fqid)
            | Q(author_fqid__in=following, visibility=Entry.Visibility.PUBLIC)
            | Q(author_fqid__in=following, visibility=Entry.Visibility.UNLISTED)
            | Q(author_fqid__in=friends, visibility=Entry.Visibility.FRIENDS)
            | Q(fqid__in=inbox_entry_fqids, visibility__in=[
                Entry.Visibility.UNLISTED, Entry.Visibility.FRIENDS
            ])
        )
    else:
        entries = Entry.objects.filter(
            Q(visibility=Entry.Visibility.PUBLIC)
            | Q(author_fqid=me.fqid)
            | Q(author_fqid__in=following, visibility=Entry.Visibility.UNLISTED)
            | Q(fqid__in=inbox_entry_fqids, visibility=Entry.Visibility.UNLISTED)
        )

    
    entries = entries.filter(is_deleted=False).exclude(
        visibility=Entry.Visibility.DELETED
    ).order_by("-published")

    entries = list(entries)
    for entry in entries:
        _attach_stream_metadata(entry, me)

    return render(
        request,
        "stream.html",
        {
            "entries": entries,
            "tab": tab,
            "me": me,
        },
    )


@login_required
@require_POST
def create_entry(request):
    """
    POST /entries/create/

    Creates a new Entry for the logged-in author.
    Called by the compose box in stream.html via fetch().

    WE can probs remove title idk im sleepy
    Expects JSON body:
    {
        "title":       "",
        "content":     "hello world",
        "contentType": "text/plain",
        "visibility":  "PUBLIC"
    }

    Returns JSON:
    {
        "success": true,
        "fqid": "http://yournode/api/authors/<uuid>/entries/<uuid>"
    }
    """
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'invalid JSON'}, status=400)

    me = _get_logged_in_author(request)
    if me is None:
        return JsonResponse({"error": "missing author profile"}, status=400)

    # pull fields out of the request, with safe defaults
    title = data.get("title", "").strip()
    description = data.get("description", "").strip()
    content = data.get("content", "").strip()
    content_type = data.get("contentType", "text/plain")
    visibility = data.get("visibility", "PUBLIC").upper()

    # validate content type against allowed values
    allowed_types = [
        'text/plain',
        'text/markdown',
        'image/png;base64',
        'image/jpeg;base64',
    ]

    if content_type not in allowed_types:
        return JsonResponse({'error': f'invalid contentType: {content_type}'}, status=400)

    # validate visibility
    allowed_vis = [v.value for v in Entry.Visibility]
    if visibility not in allowed_vis:
        return JsonResponse({'error': f'invalid visibility: {visibility}'}, status=400)

    # for image posts the content must not be empty
    if not content:
        return JsonResponse({'error': 'content cannot be empty'}, status=400)

    # generate a new UUID for this entry
    entry_uuid = uuid.uuid4()

    # build the FQID — full URL of this entry
    # e.g. http://yournode/api/authors/abc123/entries/def456
    host = request.build_absolute_uri('/').rstrip('/')
    fqid = f"{host}/api/authors/{me.uuid}/entries/{entry_uuid}"

    entry = Entry.objects.create(
        uuid         = entry_uuid,
        fqid         = fqid,
        author_fqid  = me.fqid,
        title        = title,
        description  = description,
        content      = content,
        content_type = content_type,
        visibility   = visibility,
    )

    fanout_entry_to_remote_recipients(entry, me)

    return JsonResponse({'success': True, 'fqid': entry.fqid}, status=201)

# def entry_detail(request, author_uuid, entry_uuid):
#     author = get_object_or_404(Author, uuid=author_uuid)
#     entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid)

#     viewer = _get_logged_in_author(request)
#     if not _can_view_entry(viewer, entry):
#         raise Http404("Entry not found.")

#     entry.author_data = _entry_author_data(entry)

#     #comments
#     comments = Comment.objects.filter(entry_fqid=entry.fqid).order_by("-published")
#     return render(request, "entry_detail.html", {"entry": entry, "comments": comments})

#     #likes for detail page
#     entry.like_count = Like.objects.filter(object_fqid=entry.fqid).count()
#     entry.liked_by_me = (viewer is not None and Like.objects.filter(object_fqid=entry.fqid, author_fqid=viewer.fqid).exists())
#     return render(request, "entry_detail.html", {"entry": entry "comments":comments} )

@login_required
@require_http_methods(["GET", "POST"])
def edit_entry(request, author_uuid, entry_uuid):
    me = _get_logged_in_author(request)
    if me is None:
        messages.error(request, "Your account is missing an author profile.")
        return redirect("login")

    if str(me.uuid) != str(author_uuid):
        return HttpResponseForbidden("You can only edit your own entries.")

    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=me.fqid,is_deleted=False)

    if request.method == "POST":
        entry.title = request.POST.get("title", entry.title).strip()
        entry.description = request.POST.get("description", entry.description).strip()
        entry.content = request.POST.get("content", entry.content).strip()
        entry.content_type = request.POST.get("content_type", entry.content_type)
        entry.visibility = request.POST.get("visibility", entry.visibility)

        if not entry.content:
            messages.error(request, "Content cannot be empty.")
            return render(request, "edit_entry.html", {"entry": entry})

        entry.save()
        fanout_entry_to_remote_recipients(entry, me)
        messages.success(request, "Entry updated.")
        return redirect("entry_detail", author_uuid=author_uuid, entry_uuid=entry_uuid)

    return render(request, "edit_entry.html", {"entry": entry})


@login_required
@require_POST
def delete_entry(request, author_uuid, entry_uuid):
    me = _get_logged_in_author(request)
    if me is None:
        messages.error(request, "Your account is missing an author profile.")
        return redirect("login")

    if str(me.uuid) != str(author_uuid):
        return HttpResponseForbidden("You can only delete your own entries.")

    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=me.fqid,is_deleted=False)
    fanout_entry_deletion_to_remote_recipients(entry, me)
    entry.soft_delete()

    messages.success(request, "Entry deleted.")
    return redirect("stream")


@login_required
@require_POST
def toggle_comment_like(request, author_uuid, entry_uuid, comment_uuid):
    viewer = _get_logged_in_author(request)
    if viewer is None:
        return JsonResponse({"error": "missing author profile"}, status=400)

    entry_author = get_object_or_404(Author, uuid=author_uuid)
    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=entry_author.fqid,is_deleted=False)

    if not _can_view_entry(viewer, entry):
        return JsonResponse({"error": "forbidden"}, status=403)

    # Only allow liking a comment that belongs to this entry
    comment = get_object_or_404(Comment, uuid=comment_uuid, entry_fqid=entry.fqid)

    existing = Like.objects.filter(object_fqid=comment.fqid, author_fqid=viewer.fqid).first()
    if existing:
        existing.delete()
        liked = False

        node = find_node_for_fqid(entry.author_fqid)
        if node and entry.author_fqid.rstrip("/") != viewer.fqid.rstrip("/"):
            payload = {
                "type": "unlike",
                "object": comment.fqid,
                "author": viewer.to_json(),
            }
            try:
                post_to_author_inbox(node, entry.author_fqid, payload)
            except Exception as e:
                print("REMOTE COMMENT LIKE/UNLIKE FAILED:", e)
    else:
        like_uuid = uuid.uuid4()
        host = request.build_absolute_uri('/').rstrip('/')
        like_fqid = f"{host}/api/authors/{viewer.uuid}/liked/{like_uuid}"

        like = Like.objects.create(
            uuid=like_uuid,
            fqid=like_fqid,
            author_fqid=viewer.fqid,
            author_data=viewer.to_json(),
            object_fqid=comment.fqid,
            entry=None,
            comment=comment,
        )
        liked = True

        node = find_node_for_fqid(entry.author_fqid)
        if node and entry.author_fqid.rstrip("/") != viewer.fqid.rstrip("/"):
            payload = LikeSerializer(like).data
            payload["type"] = "like"
            try:
                post_to_author_inbox(node, entry.author_fqid, payload)
            except Exception as e:
                print("REMOTE COMMENT LIKE FAILED:", e)

    count = Like.objects.filter(object_fqid=comment.fqid).count()
    return JsonResponse({"liked": liked, "count": count})

@login_required
@require_POST
def toggle_entry_like(request, author_uuid, entry_uuid):
    viewer = _get_logged_in_author(request)
    if viewer is None:
        return JsonResponse({"error": "missing author profile"}, status=400)

    author = get_object_or_404(Author, uuid=author_uuid)
    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid,is_deleted=False)

    # you shouldn't be able to like something you can't view
    if not _can_view_entry(viewer, entry):
        return JsonResponse({"error": "forbidden"}, status=403)

    # toggle like by (viewer, object_fqid)
    existing = Like.objects.filter(object_fqid=entry.fqid, author_fqid=viewer.fqid).first()
    if existing:
        existing.delete()
        liked = False

        node = find_node_for_fqid(entry.author_fqid)
        if node and entry.author_fqid.rstrip("/") != viewer.fqid.rstrip("/"):
            payload = {
                "type": "unlike",
                "object": entry.fqid,
                "author": viewer.to_json(),
            }
            try:
                post_to_author_inbox(node, entry.author_fqid, payload)
            except Exception as e:
                print("REMOTE ENTRY LIKE/UNLIKE FAILED:", e)
    else:
        like_uuid = uuid.uuid4()
        host = request.build_absolute_uri('/').rstrip('/')
        like_fqid = f"{host}/api/authors/{viewer.uuid}/liked/{like_uuid}"

        like = Like.objects.create(
            uuid=like_uuid,
            fqid=like_fqid,
            author_fqid=viewer.fqid,
            author_data=viewer.to_json(),
            object_fqid=entry.fqid,
            entry=entry,
            comment=None
        )
        liked = True

        node = find_node_for_fqid(entry.author_fqid)
        if node and entry.author_fqid.rstrip("/") != viewer.fqid.rstrip("/"):
            payload = LikeSerializer(like).data
            payload["type"] = "like"
            try:
                post_to_author_inbox(node, entry.author_fqid, payload)
            except Exception as e:
                print("REMOTE ENTRY LIKE FAILED:", e)

    count = Like.objects.filter(object_fqid=entry.fqid).count()
    return JsonResponse({"liked": liked, "count": count})


@login_required
@require_POST
def create_comment(request, author_uuid, entry_uuid):
    viewer = _get_logged_in_author(request)
    if viewer is None:
        return JsonResponse({"error": "missing author profile"}, status=400)

    entry_author = get_object_or_404(Author, uuid=author_uuid)
    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=entry_author.fqid,is_deleted=False)

    if not _can_view_entry(viewer, entry):
        return JsonResponse({"error": "forbidden"}, status=403)

    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"error": "invalid JSON"}, status=400)

    text = (data.get("comment") or "").strip()
    content_type = data.get("contentType", "text/plain")

    if not text:
        return JsonResponse({"error": "comment cannot be empty"}, status=400)

    allowed_types = ["text/plain", "text/markdown"]
    if content_type not in allowed_types:
        return JsonResponse({"error": "invalid contentType"}, status=400)

    comment_uuid = uuid.uuid4()
    host = request.build_absolute_uri('/').rstrip('/')
    comment_fqid = f"{host}/api/authors/{viewer.uuid}/commented/{comment_uuid}"

    c = Comment.objects.create(
        uuid=comment_uuid,
        fqid=comment_fqid,
        entry_fqid=entry.fqid,
        entry=entry,
        author_fqid=viewer.fqid,
        author_data=viewer.to_json(),
        comment=text,
        content_type=content_type,
    )

    node = find_node_for_fqid(entry.author_fqid)
    if node and entry.author_fqid.rstrip("/") != viewer.fqid.rstrip("/"):
        payload = CommentSerializer(c).data
        payload["type"] = "comment"
        try:
            post_to_author_inbox(node, entry.author_fqid, payload)
        except Exception as e:
            print("REMOTE COMMENT POST FAILED:", e)

    return JsonResponse({
        "success": True,
        "uuid": str(c.uuid),
        "author": c.author_data,
        "comment": c.comment,
        "published": c.published.isoformat(),
    }, status=201)


def entry_detail(request, author_uuid, entry_uuid):
    author = get_object_or_404(Author, uuid=author_uuid)
    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid,is_deleted=False)

    local_author = Author.objects.filter(fqid=entry.author_fqid).first()
    entry.author_uuid = local_author.uuid if local_author else None

    viewer = _get_logged_in_author(request)
    if not _can_view_entry(viewer, entry):
        raise Http404("Entry not found.")

    entry.author_data = _entry_author_data(entry)

    # likes lists
    likes_qs = Like.objects.filter(object_fqid=entry.fqid).order_by("-published")

    entry.like_count = likes_qs.count()
    entry.liked_by_me = (
        viewer is not None and likes_qs.filter(author_fqid=viewer.fqid).exists()
    )

    comments = Comment.objects.filter(entry_fqid=entry.fqid).order_by("-published")

    for c in comments:
        comment_likes_qs = Like.objects.filter(object_fqid=c.fqid).order_by("-published")
        c.like_count = comment_likes_qs.count()
        c.liked_by_me = (
            viewer is not None
            and comment_likes_qs.filter(author_fqid=viewer.fqid).exists()
        )
        c.likers = []
        for like in comment_likes_qs:
            if like.author_data:
                c.likers.append(like.author_data)
            else:
                a = Author.objects.filter(fqid=like.author_fqid).first()
                c.likers.append(
                    a.to_json() if a else {"displayName": like.author_fqid, "id": like.author_fqid}
                )


    entry.likers = []
    for like in likes_qs:
        if like.author_data:
            entry.likers.append(like.author_data)
        else:
            a = Author.objects.filter(fqid=like.author_fqid).first()
            entry.likers.append(
                a.to_json() if a else {"displayName": like.author_fqid, "id": like.author_fqid}
            )

    # shareable link 
    share_url = request.build_absolute_uri()

    return render(request, "entry_detail.html", {"entry": entry, "comments": comments,"share_url": share_url })


def entry_image(request, author_uuid, entry_uuid):
    #I create can be images, so that I can share pictures and drawings
    """
    GET /api/authors/<uuid>/entries/<uuid>/image
    Returns the image entry as raw binary.
    Returns 404 if entry is not an image.
    """
    author = get_object_or_404(Author, uuid=author_uuid)
    entry = get_object_or_404(Entry, uuid=entry_uuid, author_fqid=author.fqid,is_deleted=False)

    viewer = _get_logged_in_author(request)
    if not _can_view_entry(viewer, entry):
        raise Http404("Entry not found.")

    if "image" not in entry.content_type:
        raise Http404("Not an image entry.")

    # content_type is like "image/png;base64" 
    mime_type = entry.content_type.replace(";base64", "")

    try:
        image_data = base64.b64decode(entry.content)
    except Exception:
        raise Http404("Invalid image data.")

    return HttpResponse(image_data, content_type=mime_type)
