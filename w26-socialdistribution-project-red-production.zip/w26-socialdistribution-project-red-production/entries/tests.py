import json
import uuid
import base64


from django.test import TestCase
from django.contrib.auth.models import User
from django.utils import timezone

from entries.models import Entry
from authors.models import Author, Follower

# Create your tests here.

def _field_names(model):
   return {f.name for f in model._meta.get_fields()}

class EntriesTestHelpers:
   
   """
   Helper methods that try to create Author/Follower rows without hardcoding
   every field name
   """

   def make_user(self, username: str, password: str = "pass12345", is_superuser=False):
       if is_superuser:
           u = User.objects.create_superuser(username=username, password=password, email="x@example.com")
       else:
           u = User.objects.create_user(username=username, password=password)
       return u

   def make_author_for_user(self, user: User) -> Author:
       fn = _field_names(Author)

       # have OneToOne to User called "user"
       kwargs = {}
       if "user" in fn:
           kwargs["user"] = user


       # Required identity fields your Entry views rely on:
       # - uuid (used in create_entry fqid)
       # - fqid (used in stream/follow queries)
       # - host
       if "uuid" in fn:
           kwargs["uuid"] = uuid.uuid4()


       if "host" in fn:
           kwargs["host"] = "http://testserver/"


       # fqid must be URL-like and stable
       if "fqid" in fn:
           kwargs["fqid"] = f"http://testserver/authors/{user.id}/"

       # Display name could be snake_case or camelCase 
       if "display_name" in fn:
           kwargs["display_name"] = user.username
       if "displayName" in fn:
           kwargs["displayName"] = user.username

       # Approval flag (your admin shows "Is approved" in screenshot)
       if "is_approved" in fn:
           kwargs["is_approved"] = True
       if "isApproved" in fn:
           kwargs["isApproved"] = True


       # Fill any other required fields (non-null, no default) with safe values
       # so tests don't break if someone adds required fields.
       for f in Author._meta.fields:
           if f.name in kwargs:
               continue
           # Skip auto fields
           if getattr(f, "auto_created", False):
               continue
           # Skip primary key
           if getattr(f, "primary_key", False):
               continue
           # Required fields: null=False, blank=False, no default
           has_default = f.default is not None and f.default is not uuid.uuid4
           if (not f.null) and (not getattr(f, "blank", False)) and (f.default is TestCase):
               # not used
               pass


       # More reliable: just attempt create; if it errors, you’ll see which field is missing.
       return Author.objects.create(**kwargs)


   def make_follower(self, author_being_followed: Author, follower_author: Author):
       """
       Creates: follower_author follows author_being_followed
       Matches your stream_view queries:
         Follower.objects.filter(follower_fqid=me.fqid).values_list('author__fqid', ...)
         Follower.objects.filter(author=me).values_list('follower_fqid', ...)
       """
       fn = _field_names(Follower)
       kwargs = {}


       # the followed person is stored as FK named "author" in your query
       if "author" in fn:
           kwargs["author"] = author_being_followed
       else:
           raise AssertionError("Follower model must have FK field named 'author' for your stream_view query to work.")


       if "follower_fqid" in fn:
           kwargs["follower_fqid"] = follower_author.fqid
       else:
           raise AssertionError("Follower model must have field named 'follower_fqid' for your stream_view query to work.")


       return Follower.objects.create(**kwargs)



class StreamViewTests(TestCase, EntriesTestHelpers):
   def test_stream_requires_login(self):
       resp = self.client.get("/stream/")
       self.assertEqual(resp.status_code, 302)  # redirect to login


   def test_stream_public_shows_public_and_own_entries_excludes_deleted(self):
       alice_u = self.make_user("alice")
       bob_u = self.make_user("bob")
       alice_a = self.make_author_for_user(alice_u)
       bob_a = self.make_author_for_user(bob_u)


       # Alice makes a PUBLIC entry
       Entry.objects.create(
           uuid=uuid.uuid4(),
           fqid="http://testserver/api/authors/x/entries/1",
           author_fqid=alice_a.fqid,
           content="alice public",
           content_type="text/plain",
           visibility=Entry.Visibility.PUBLIC,
           is_deleted=False,
       )

       # Alice makes a DELETED entry (should be excluded via is_deleted)
       Entry.objects.create(
           uuid=uuid.uuid4(),
           fqid="http://testserver/api/authors/x/entries/2",
           author_fqid=alice_a.fqid,
           content="alice deleted",
           content_type="text/plain",
           visibility=Entry.Visibility.PUBLIC,
           is_deleted=True,
       )

       # Bob makes an UNLISTED entry (should NOT appear on public tab unless it's Bob viewing and it's his own)
       Entry.objects.create(
           uuid=uuid.uuid4(),
           fqid="http://testserver/api/authors/x/entries/3",
           author_fqid=bob_a.fqid,
           content="bob unlisted",
           content_type="text/plain",
           visibility=Entry.Visibility.UNLISTED,
           is_deleted=False,
       )


       self.client.login(username="bob", password="pass12345")
       resp = self.client.get("/stream/?tab=public")
       self.assertEqual(resp.status_code, 200)


       html = resp.content.decode()
       self.assertIn("alice public", html)
       self.assertNotIn("alice deleted", html)
       # On public tab, your code only shows PUBLIC + my own entries
       self.assertIn("bob unlisted", html)


   def test_stream_friends_tab_shows_friends_only_for_mutuals(self):
       alice_u = self.make_user("alice")
       bob_u = self.make_user("bob")
       charlie_u = self.make_user("charlie")


       alice_a = self.make_author_for_user(alice_u)
       bob_a = self.make_author_for_user(bob_u)
       charlie_a = self.make_author_for_user(charlie_u)


       # FRIENDS entry by Alice
       Entry.objects.create(
           uuid=uuid.uuid4(),
           fqid="http://testserver/api/authors/a/entries/f1",
           author_fqid=alice_a.fqid,
           content="alice friends-only",
           content_type="text/plain",
           visibility=Entry.Visibility.FRIENDS,
           is_deleted=False,
       )


       # PUBLIC entry by Alice (should not necessarily appear on friends tab unless your query includes it; it doesn't)
       Entry.objects.create(
           uuid=uuid.uuid4(),
           fqid="http://testserver/api/authors/a/entries/p1",
           author_fqid=alice_a.fqid,
           content="alice public",
           content_type="text/plain",
           visibility=Entry.Visibility.PUBLIC,
           is_deleted=False,
       )


       # Bob follows Alice and Alice follows Bob -> mutual friends
       self.make_follower(author_being_followed=alice_a, follower_author=bob_a)   # bob -> alice
       self.make_follower(author_being_followed=bob_a, follower_author=alice_a)  # alice -> bob


       # Charlie follows Alice but not mutual
       self.make_follower(author_being_followed=alice_a, follower_author=charlie_a)


       # Bob should see Alice friends-only on friends tab
       self.client.login(username="bob", password="pass12345")
       resp = self.client.get("/stream/?tab=friends")
       self.assertEqual(resp.status_code, 200)
       html = resp.content.decode()
       self.assertIn("alice friends-only", html)
       self.assertIn("alice public", html)  # friends tab includes PUBLIC entries from friends

       # Charlie should NOT see Alice friends-only on friends tab
       self.client.logout()
       self.client.login(username="charlie", password="pass12345")
       resp2 = self.client.get("/stream/?tab=friends")
       self.assertEqual(resp2.status_code, 200)
       html2 = resp2.content.decode()
       self.assertNotIn("alice friends-only", html2)


class CreateEntryTests(TestCase, EntriesTestHelpers):
   def setUp(self):
       self.u = self.make_user("alice")
       self.a = self.make_author_for_user(self.u)
       self.client.login(username="alice", password="pass12345")


   def post_json(self, url: str, payload: dict):
       return self.client.post(url, data=json.dumps(payload), content_type="application/json")


   def test_create_entry_success(self):
       # Create entries through the DRF endpoint, not the legacy /entries/create/ view.
       resp = self.post_json(f"/api/authors/{self.a.uuid}/entries/", {
           "title": "hi",
           "content": "hello world",
           "contentType": "text/plain",
           "visibility": "PUBLIC",
       })
       self.assertEqual(resp.status_code, 201)


       data = resp.json()
       # DRF returns the full entry object, so check the serialized id field.
       self.assertIn("/api/authors/", data["id"])
       self.assertIn("/entries/", data["id"])
       self.assertEqual(data["content"], "hello world")


       self.assertTrue(Entry.objects.filter(author_fqid=self.a.fqid, content="hello world").exists())


   def test_create_entry_rejects_invalid_json(self):
       resp = self.client.post("/entries/create/", data="{not json", content_type="application/json")
       self.assertEqual(resp.status_code, 400)
       self.assertIn("error", resp.json())


   def test_create_entry_rejects_invalid_content_type(self):
       resp = self.post_json("/entries/create/", {
           "content": "x",
           "contentType": "application/pdf",
           "visibility": "PUBLIC",
       })
       self.assertEqual(resp.status_code, 400)


   def test_create_entry_rejects_invalid_visibility(self):
       resp = self.post_json("/entries/create/", {
           "content": "x",
           "contentType": "text/plain",
           "visibility": "PRIVATE",  # not in Entry.Visibility
       })
       self.assertEqual(resp.status_code, 400)


   def test_create_entry_rejects_empty_content(self):
       resp = self.post_json("/entries/create/", {
           "content": "",
           "contentType": "text/plain",
           "visibility": "PUBLIC",
       })
       self.assertEqual(resp.status_code, 400)



#  entry detail page visibility rules
class EntryDetailVisibilityTests(TestCase, EntriesTestHelpers):
    """
    GET /authors/<uuid>/entries/<uuid>/

    Tests that public entries are accessible to everyone,
    friends-only entries are blocked, and deleted entries return 404.
    """

    def setUp(self):
        # Create the author who owns the entries
        self.author_u = self.make_user("author")
        self.author_a = self.make_author_for_user(self.author_u)

        # Create a stranger who has no relationship with the author
        self.stranger_u = self.make_user("stranger")
        self.stranger_a = self.make_author_for_user(self.stranger_u)

        # Create a friend who has a mutual follow with the author
        self.friend_u = self.make_user("friend")
        self.friend_a = self.make_author_for_user(self.friend_u)

        # friend follows author
        self.make_follower(author_being_followed=self.author_a, follower_author=self.friend_a)
        # author follows friend back -> they are now mutual friends
        self.make_follower(author_being_followed=self.friend_a, follower_author=self.author_a)

    def _make_entry(self, visibility):
        # Helper: create an entry with the given visibility owned by self.author_a
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.author_a.uuid}/entries/{entry_uuid}"
        return Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.author_a.fqid,
            content="some content",
            content_type="text/plain",
            visibility=visibility,
            is_deleted=False,
        )

    def _url(self, entry):
        # Helper: build the detail URL using the author uuid and entry uuid
        return f"/authors/{self.author_a.uuid}/entries/{entry.uuid}/"

    # --- PUBLIC entry ---

    def test_public_entry_visible_to_unauthenticated(self):
        # Anyone on the internet (not logged in) should be able to see a public entry
        e = self._make_entry(Entry.Visibility.PUBLIC)
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 200)

    def test_public_entry_visible_to_stranger(self):
        # A logged-in user with no relationship to the author should still see a public entry
        e = self._make_entry(Entry.Visibility.PUBLIC)
        self.client.login(username="stranger", password="pass12345")
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 200)

    def test_public_entry_visible_to_friend(self):
        # A mutual friend should also be able to see a public entry
        e = self._make_entry(Entry.Visibility.PUBLIC)
        self.client.login(username="friend", password="pass12345")
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 200)

    def test_public_entry_visible_to_author(self):
        # The author should always be able to see their own public entry
        e = self._make_entry(Entry.Visibility.PUBLIC)
        self.client.login(username="author", password="pass12345")
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 200)

    def test_public_entry_contains_content(self):
        # The rendered page should include the entry's actual content text
        e = self._make_entry(Entry.Visibility.PUBLIC)
        resp = self.client.get(self._url(e))
        self.assertContains(resp, "some content")

    # --- FRIENDS-ONLY entry ---

    def test_friends_entry_visible_to_friend(self):
        # A mutual friend should be able to see a friends-only entry
        e = self._make_entry(Entry.Visibility.FRIENDS)
        self.client.login(username="friend", password="pass12345")
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 200)

    def test_friends_entry_hidden_from_stranger(self):
        # A stranger (no follow relationship) must NOT see a friends-only entry
        e = self._make_entry(Entry.Visibility.FRIENDS)
        self.client.login(username="stranger", password="pass12345")
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 404)

    def test_friends_entry_hidden_from_unauthenticated(self):
        # An unauthenticated visitor must NOT see a friends-only entry
        e = self._make_entry(Entry.Visibility.FRIENDS)
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 404)

    def test_friends_entry_visible_to_own_author(self):
        # The author should always be able to see their own friends-only entry
        e = self._make_entry(Entry.Visibility.FRIENDS)
        self.client.login(username="author", password="pass12345")
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 200)

    # --- UNLISTED entry ---

    def test_unlisted_entry_visible_to_unauthenticated_with_link(self):
        # Unlisted entries don't appear in streams but anyone with the link can view them
        e = self._make_entry(Entry.Visibility.UNLISTED)
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 200)

    def test_unlisted_entry_visible_to_stranger_with_link(self):
        # A logged-in stranger who has the link should also be able to see an unlisted entry
        e = self._make_entry(Entry.Visibility.UNLISTED)
        self.client.login(username="stranger", password="pass12345")
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 200)

    # --- DELETED entry ---

    def test_deleted_entry_returns_404_to_unauthenticated(self):
        # Deleted entries must not be accessible at their URL to anyone
        e = self._make_entry(Entry.Visibility.PUBLIC)
        e.soft_delete()  # marks is_deleted=True and visibility=DELETED in the DB
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 404)

    def test_deleted_entry_returns_404_to_author(self):
        # Even the author cannot access their own deleted entry via its URL
        e = self._make_entry(Entry.Visibility.PUBLIC)
        e.soft_delete()
        self.client.login(username="author", password="pass12345")
        resp = self.client.get(self._url(e))
        self.assertEqual(resp.status_code, 404)


# Entry model unit tests

class EntryModelVisibilityTests(TestCase, EntriesTestHelpers):
    """
    Direct model tests, no HTTP involved.
    Covers Entry.Visibility choices, soft_delete, ordering, and fqid uniqueness.
    """

    def setUp(self):
        # Create a single author to own all entries in these tests
        u = self.make_user("grace")
        self.author = self.make_author_for_user(u)

    def _make_entry(self, visibility="PUBLIC", title="Test"):
        # Helper: create an entry in the DB with the given visibility and title
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.author.uuid}/entries/{entry_uuid}"
        return Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.author.fqid,
            title=title,
            content="content",
            content_type="text/plain",
            visibility=visibility,
            is_deleted=False,
        )

    def test_default_visibility_is_public(self):
        # When no visibility is specified the entry should default to PUBLIC
        e = self._make_entry()
        self.assertEqual(e.visibility, Entry.Visibility.PUBLIC)

    def test_can_set_friends_visibility(self):
        # The FRIENDS visibility choice should be saveable and readable from the DB
        e = self._make_entry(visibility="FRIENDS")
        self.assertEqual(e.visibility, Entry.Visibility.FRIENDS)

    def test_can_set_unlisted_visibility(self):
        # The UNLISTED visibility choice should be saveable and readable from the DB
        e = self._make_entry(visibility="UNLISTED")
        self.assertEqual(e.visibility, Entry.Visibility.UNLISTED)

    def test_soft_delete_sets_is_deleted(self):
        # soft_delete() should flip is_deleted to True so the entry is hidden from UI/API
        e = self._make_entry()
        e.soft_delete()
        e.refresh_from_db()
        self.assertTrue(e.is_deleted)

    def test_soft_delete_sets_visibility_deleted(self):
        # soft_delete() should also set visibility=DELETED so ORM queries
        # that filter by visibility also exclude deleted entries
        e = self._make_entry()
        e.soft_delete()
        e.refresh_from_db()
        self.assertEqual(e.visibility, Entry.Visibility.DELETED)

    def test_soft_delete_keeps_row_in_db(self):
        # Per the spec, deleted entries must NOT be removed from the database.
        # They are only hidden from the UI. The admin can still query them.
        e = self._make_entry()
        pk = e.pk
        e.soft_delete()
        self.assertTrue(Entry.objects.filter(pk=pk).exists())

    def test_fqids_are_unique_across_entries(self):
        # Every entry must have a globally unique FQID (full URL) so remote
        # nodes can identify entries without collision
        e1 = self._make_entry(title="First")
        e2 = self._make_entry(title="Second")
        self.assertNotEqual(e1.fqid, e2.fqid)

    def test_entries_ordered_newest_first(self):
        # The stream relies on entries being ordered by -published (newest first)
        # so the most recent entry should be first in a queryset
        e1 = self._make_entry(title="Older")
        e2 = self._make_entry(title="Newer")
        entries = list(Entry.objects.filter(author_fqid=self.author.fqid))
        self.assertEqual(entries[0].pk, e2.pk)

    def test_str_contains_title_and_visibility(self):
        # __str__ should include both title and visibility so entries are
        # easy to identify in the Django admin panel
        e = self._make_entry(title="Hello", visibility="PUBLIC")
        self.assertIn("Hello", str(e))
        self.assertIn("PUBLIC", str(e))


# public entries in stream (extra cases)

class StreamPublicVisibilityTests(TestCase, EntriesTestHelpers):
    """
    specifically for the PUBLIC visibility story.
    """

    def setUp(self):
        # Two completely unrelated authors with no follows between them
        self.alice_u = self.make_user("alice2")
        self.alice_a = self.make_author_for_user(self.alice_u)
        self.bob_u = self.make_user("bob2")
        self.bob_a = self.make_author_for_user(self.bob_u)

    def _public_entry(self, author, content):
        # Helper: create a PUBLIC entry for the given author with the given content
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{author.uuid}/entries/{entry_uuid}"
        return Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=author.fqid,
            content=content,
            content_type="text/plain",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )

    def test_public_entry_visible_to_non_follower(self):
        # Bob doesn't follow Alice, but her public entry should still appear
        # in his stream because PUBLIC means everyone can see it
        self._public_entry(self.alice_a, "alice public content")
        self.client.login(username="bob2", password="pass12345")
        resp = self.client.get("/stream/")
        self.assertContains(resp, "alice public content")

    def test_soft_deleted_public_entry_not_in_stream(self):
        # Once an entry is soft-deleted it should disappear from the stream
        # even though the row still exists in the database
        e = self._public_entry(self.alice_a, "will be deleted")
        e.soft_delete()
        self.client.login(username="bob2", password="pass12345")
        resp = self.client.get("/stream/")
        self.assertNotContains(resp, "will be deleted")

    def test_multiple_authors_public_entries_all_appear(self):
        # The stream should aggregate public entries from all authors on the node,
        # not just people you follow
        self._public_entry(self.alice_a, "alice says hi")
        self._public_entry(self.bob_a, "bob says hi")
        self.client.login(username="alice2", password="pass12345")
        resp = self.client.get("/stream/")
        self.assertContains(resp, "alice says hi")
        self.assertContains(resp, "bob says hi")


class ImageEntryTests(TestCase, EntriesTestHelpers):
    """
    As an author, entries I create can be images,
    so that I can share pictures and drawings.
    """

    def setUp(self):
        self.u = self.make_user("alice")
        self.a = self.make_author_for_user(self.u)
        self.client.login(username="alice", password="pass12345")

        # minimal 1x1 red PNG in base64
        self.png_b64 = (
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8"
            "z8BQDwADhQGAWjR9awAAAABJRU5ErkJggg=="
        )

    def _url(self, path):
        return path

    def test_create_png_image_entry(self):
        """Author can create a PNG image entry via the API."""
        resp = self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "title": "my pic",
                "content": self.png_b64,
                "contentType": "image/png;base64",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)
        self.assertTrue(
            Entry.objects.filter(
                author_fqid=self.a.fqid,
                content_type="image/png;base64"
            ).exists()
        )

    def test_create_jpeg_image_entry(self):
        """Author can create a JPEG image entry via the API."""
        resp = self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "title": "my jpeg",
                "content": self.png_b64,
                "contentType": "image/jpeg;base64",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)

    def test_image_entry_stored_as_base64(self):
        """Image content is stored as base64 string in the database."""
        self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "content": self.png_b64,
                "contentType": "image/png;base64",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        entry = Entry.objects.get(author_fqid=self.a.fqid, content_type="image/png;base64")
        self.assertEqual(entry.content, self.png_b64)

    def test_image_endpoint_returns_binary(self):
        """GET /api/authors/<uuid>/entries/<uuid>/image returns raw binary image."""
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.a.uuid}/entries/{entry_uuid}"
        Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.a.fqid,
            content=self.png_b64,
            content_type="image/png;base64",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )
        resp = self.client.get(f"/api/authors/{self.a.uuid}/entries/{entry_uuid}/image")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp["Content-Type"], "image/png")
        self.assertEqual(resp.content, base64.b64decode(self.png_b64))

    def test_image_endpoint_returns_404_for_text_entry(self):
        """GET /api/.../image returns 404 if entry is not an image."""
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.a.uuid}/entries/{entry_uuid}"
        Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.a.fqid,
            content="hello",
            content_type="text/plain",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )
        resp = self.client.get(f"/api/authors/{self.a.uuid}/entries/{entry_uuid}/image")
        self.assertEqual(resp.status_code, 404)

    def test_non_image_content_type_rejected(self):
        """API rejects content types that are not allowed."""
        resp = self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "content": "hello",
                "contentType": "application/pdf",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 400)

class CommonMarkImageLinkTests(TestCase, EntriesTestHelpers):
    """
    As an author, entries I create that are in CommonMark can link to images,
    so that I can illustrate my entries.
    """

    def setUp(self):
        # create an author and log them in
        self.u = self.make_user("alice")
        self.a = self.make_author_for_user(self.u)
        self.client.login(username="alice", password="pass12345")

        # amarkdown entry whose content contains an image link
        self.md_with_image = "Check out this image!\n\n![cool cat](https://example.com/cat.png)"
        self.md_no_image   = "Just some **bold** text with no image."

    def _make_md_entry(self, content):
        # helper: create a text/markdown entry directly in the DB
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.a.uuid}/entries/{entry_uuid}"
        return Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.a.fqid,
            title="MD Entry",
            content=content,
            content_type="text/markdown",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )


    def test_can_create_markdown_entry_via_api(self):
        # Aauthor should be able to POST an entry with contentType=text/markdown
        resp = self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "title": "My illustrated post",
                "content": self.md_with_image,
                "contentType": "text/markdown",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)

    def test_markdown_entry_saved_with_correct_content_type(self):
        # the DB record should store content_type as "text/markdown"
        self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "content": self.md_with_image,
                "contentType": "text/markdown",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        entry = Entry.objects.get(author_fqid=self.a.fqid, content_type="text/markdown")
        self.assertEqual(entry.content_type, "text/markdown")

    def test_markdown_image_link_saved_in_content(self):
        # the raw markdown including the image link should be stored as-is in the DB
        self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "content": self.md_with_image,
                "contentType": "text/markdown",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        entry = Entry.objects.get(author_fqid=self.a.fqid, content_type="text/markdown")
        # raw markdown image syntax should be preserved exactly
        self.assertIn("![cool cat](https://example.com/cat.png)", entry.content)

    def test_markdown_entry_content_type_in_api_response(self):
        # the API response should echo back contentType as text/markdown
        resp = self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "content": self.md_with_image,
                "contentType": "text/markdown",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        data = resp.json()
        self.assertEqual(data.get("contentType"), "text/markdown")

    # Detail page renders markdown 
    def test_detail_page_includes_marked_js_for_markdown_entry(self):
        # the detail page must load marked.js so the browser can render markdown
        e = self._make_md_entry(self.md_with_image)
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "marked")

    def test_detail_page_has_markdown_content_element(self):
        # page must have a container that holds the raw markdown for marked.js to parse
        e = self._make_md_entry(self.md_with_image)
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        self.assertContains(resp, "markdown-content")

    def test_detail_page_contains_raw_image_url(self):
        # raw image URL must appear somewhere on the page so marked.js can render it
        e = self._make_md_entry(self.md_with_image)
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        self.assertContains(resp, "https://example.com/cat.png")

    def test_detail_page_contains_raw_markdown_content(self):
        #  raw markdown text should be embedded in the page for marked.js to process
        e = self._make_md_entry(self.md_with_image)
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        self.assertContains(resp, "cool cat")

    def test_plain_text_entry_does_not_use_marked_js(self):
        #  no need to render markdown
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.a.uuid}/entries/{entry_uuid}"
        Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.a.fqid,
            content="just plain text",
            content_type="text/plain",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{entry_uuid}/")
        # plain text entries are rendered directly, 
        self.assertNotContains(resp, "markdown-content")

    # Markdown with multiple image links 

    def test_markdown_entry_with_multiple_image_links(self):
        # An entry can contain multiple image links in its markdown content
        content = (
            "First image: ![img1](https://example.com/one.png)\n\n"
            "Second image: ![img2](https://example.com/two.jpg)"
        )
        e = self._make_md_entry(content)
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        # both image URLs must be present in the page source
        self.assertContains(resp, "https://example.com/one.png")
        self.assertContains(resp, "https://example.com/two.jpg")

    # visibility rules still apply to markdown entries 

    def test_markdown_entry_public_visible_to_unauthenticated(self):
        # Public markdown entries should be accessible to anyone, same as plain text
        e = self._make_md_entry(self.md_with_image)
        self.client.logout()
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        self.assertEqual(resp.status_code, 200)

    def test_markdown_entry_friends_only_hidden_from_stranger(self):
        # friends-only visibility applies to markdown entries too
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.a.uuid}/entries/{entry_uuid}"
        Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.a.fqid,
            content=self.md_with_image,
            content_type="text/markdown",
            visibility=Entry.Visibility.FRIENDS,
            is_deleted=False,
        )
        # Log in as a stranger
        stranger_u = self.make_user("stranger")
        self.make_author_for_user(stranger_u)
        self.client.login(username="stranger", password="pass12345")
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{entry_uuid}/")
        self.assertEqual(resp.status_code, 404)


class EditedEntryStreamTests(TestCase, EntriesTestHelpers):
    """
    I want my stream page to show me the most recent version
    of an entry if it has been edited.
    """

    def setUp(self):
        # create the author who will write and edit entries
        self.author_u = self.make_user("alice")
        self.author_a = self.make_author_for_user(self.author_u)

        # create a reader who will view the stream
        self.reader_u = self.make_user("bob")
        self.reader_a = self.make_author_for_user(self.reader_u)

        self.client.login(username="alice", password="pass12345")

    def _make_entry(self, content="original content", visibility="PUBLIC"):
        # helper: create an entry directly in the DB
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.author_a.uuid}/entries/{entry_uuid}"
        return Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.author_a.fqid,
            title="Test Entry",
            content=content,
            content_type="text/plain",
            visibility=visibility,
            is_deleted=False,
        )

    # editing updates the DB record 

    def test_edit_entry_updates_content_in_db(self):
        # after editing, the DB row should contain the new content, not the old
        e = self._make_entry("original content")
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "edited content",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        e.refresh_from_db()
        self.assertEqual(e.content, "edited content")

    def test_edit_entry_old_content_no_longer_in_db(self):
        # the original content must be gone after editing — no versioning
        e = self._make_entry("original content")
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "edited content",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        e.refresh_from_db()
        self.assertNotEqual(e.content, "original content")

    def test_edit_entry_updates_updated_timestamp(self):
        # the 'updated' field should be more recent after editing
        e = self._make_entry()
        before = e.updated
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "new content",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        e.refresh_from_db()
        self.assertGreaterEqual(e.updated, before)

    def test_edit_does_not_create_a_new_entry_row(self):
        # editing must update the existing row, not insert a new one
        e = self._make_entry()
        count_before = Entry.objects.filter(author_fqid=self.author_a.fqid).count()
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "new content",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        count_after = Entry.objects.filter(author_fqid=self.author_a.fqid).count()
        # row count must stay the same — no duplicate created
        self.assertEqual(count_before, count_after)

    def test_fqid_unchanged_after_edit(self):
        # the entry's FQID (its URL identity) must not change after editing
        e = self._make_entry()
        original_fqid = e.fqid
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "new content",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        e.refresh_from_db()
        self.assertEqual(e.fqid, original_fqid)

    # stream shows the edited content 

    def test_stream_shows_edited_content_not_original(self):
        # after editing, the stream must show the new content, not the old
        e = self._make_entry("original content")
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "edited content",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        # awitch to reader's view of the stream
        self.client.login(username="bob", password="pass12345")
        resp = self.client.get("/stream/")
        self.assertContains(resp, "edited content")
        self.assertNotContains(resp, "original content")

    def test_stream_does_not_show_old_content_after_edit(self):
        e = self._make_entry("before edit")
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "after edit",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        self.client.login(username="bob", password="pass12345")
        resp = self.client.get("/stream/")
        self.assertNotContains(resp, "before edit")

    def test_only_one_copy_of_entry_in_stream_after_edit(self):
        e = self._make_entry("version one")
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "version two",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        self.client.login(username="bob", password="pass12345")
        resp = self.client.get("/stream/")
        self.assertEqual(resp.content.decode().count("version two"), 1)


    def test_detail_page_shows_edited_content(self):
        # he entry detail page must also show the new content after editing
        e = self._make_entry("original content")
        self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "edited content",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        resp = self.client.get(f"/authors/{self.author_a.uuid}/entries/{e.uuid}/")
        self.assertContains(resp, "edited content")
        self.assertNotContains(resp, "original content")


    def test_other_author_cannot_edit_entry(self):
        #  different author must not be able to edit someone else's entry
        e = self._make_entry("alice's content")
        self.client.login(username="bob", password="pass12345")
        resp = self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "bob's edit",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        # hould be forbidden
        self.assertIn(resp.status_code, [403, 404])
        e.refresh_from_db()
        # cntent must be unchanged
        self.assertEqual(e.content, "alice's content")

    def test_unauthenticated_cannot_edit_entry(self):
        # uauthenticated users must not be able to edit entries
        e = self._make_entry("alice's content")
        self.client.logout()
        resp = self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "hacked",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        # Ssould redirect to login
        self.assertIn(resp.status_code, [302, 403])
        e.refresh_from_db()
        self.assertEqual(e.content, "alice's content")

    def test_edit_with_empty_content_rejected(self):
        # sbmitting an empty content field should not update the entry
        e = self._make_entry("original content")
        resp = self.client.post(
            f"/authors/{self.author_a.uuid}/entries/{e.uuid}/edit/",
            {"title": "Test Entry", "content": "",
             "content_type": "text/plain", "visibility": "PUBLIC"},
        )
        e.refresh_from_db()
        # content must remain unchanged
        self.assertEqual(e.content, "original content")

class PlainTextEntryTests(TestCase, EntriesTestHelpers):
    """
    author, entries I make can be in simple plain text,
    because I don't always want all the formatting features of CommonMark.
    """

    def setUp(self):
        # an author and log them in
        self.u = self.make_user("alice")
        self.a = self.make_author_for_user(self.u)
        self.client.login(username="alice", password="pass12345")

    def _make_plain_entry(self, content="hello world"):
        # create a text/plain entry directly in the DB
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.a.uuid}/entries/{entry_uuid}"
        return Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.a.fqid,
            title="Plain Entry",
            content=content,
            content_type="text/plain",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )


    def test_can_create_plain_text_entry_via_api(self):
        # uthor should be able to POST an entry with contentType=text/plain
        resp = self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "title": "My plain post",
                "content": "just some plain text",
                "contentType": "text/plain",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)

    def test_plain_text_entry_saved_with_correct_content_type(self):
        # te DB record should store content_type as "text/plain"
        self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "content": "just some plain text",
                "contentType": "text/plain",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        entry = Entry.objects.get(author_fqid=self.a.fqid, content="just some plain text")
        self.assertEqual(entry.content_type, "text/plain")

    def test_plain_text_content_stored_exactly_as_written(self):
        # plain text content must be stored exactly as the author wrote it
        # with no modification, escaping, or markdown processing
        raw = "Hello! This is plain text with *asterisks* and [brackets]."
        self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "content": raw,
                "contentType": "text/plain",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        entry = Entry.objects.get(author_fqid=self.a.fqid, content=raw)
        self.assertEqual(entry.content, raw)

    def test_plain_text_api_response_has_correct_content_type(self):
        # the API response should echo back contentType as text/plain
        resp = self.client.post(
            f"/api/authors/{self.a.uuid}/entries/",
            data=json.dumps({
                "content": "plain text post",
                "contentType": "text/plain",
                "visibility": "PUBLIC",
            }),
            content_type="application/json",
        )
        data = resp.json()
        self.assertEqual(data.get("contentType"), "text/plain")

    def test_default_content_type_is_plain_text(self):
        # if no contentType is specified, the entry should default to text/plain
        entry = self._make_plain_entry()
        self.assertEqual(entry.content_type, "text/plain")


    def test_detail_page_shows_plain_text_content(self):
        # yhe detail page must display the plain text content directly
        e = self._make_plain_entry("just some plain text")
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "just some plain text")

    def test_detail_page_does_not_use_markdown_renderer_for_plain_text(self):
        # plain text entries must NOT use the markdown-content div
        # that triggers marked.js — plain text should render as-is
        e = self._make_plain_entry("just plain text")
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        self.assertNotContains(resp, "markdown-content")

    def test_plain_text_with_markdown_symbols_not_rendered_as_html(self):
        # asterisks, brackets etc. in plain text must appear as literal characters,
        # not be converted to <strong>, <a> tags etc.
        e = self._make_plain_entry("**not bold** and [not a link](http://example.com)")
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        # the raw symbols should be present in the page
        self.assertContains(resp, "**not bold**")


    def test_plain_text_entry_appears_in_stream(self):
        # plain text entries should show up in the public stream like any other entry
        self._make_plain_entry("stream plain text content")
        resp = self.client.get("/stream/")
        self.assertContains(resp, "stream plain text content")

    def test_plain_text_entry_content_visible_in_stream(self):
        # the actual text content should be visible in the stream, not just the title
        self._make_plain_entry("readable plain content")
        resp = self.client.get("/stream/")
        self.assertContains(resp, "readable plain content")


    def test_plain_text_and_markdown_entries_can_coexist(self):
        # an author can have both plain text and markdown entries at the same time
        self._make_plain_entry("plain text entry")
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.a.uuid}/entries/{entry_uuid}"
        Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.a.fqid,
            content="**markdown entry**",
            content_type="text/markdown",
            visibility=Entry.Visibility.PUBLIC,
            is_deleted=False,
        )
        # both should exist in the DB with their respective content types
        self.assertTrue(Entry.objects.filter(
            author_fqid=self.a.fqid, content_type="text/plain").exists())
        self.assertTrue(Entry.objects.filter(
            author_fqid=self.a.fqid, content_type="text/markdown").exists())


    def test_plain_text_public_entry_visible_to_unauthenticated(self):
        # public plain text entries should be accessible to anyone
        e = self._make_plain_entry("public plain text")
        self.client.logout()
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{e.uuid}/")
        self.assertEqual(resp.status_code, 200)

    def test_plain_text_friends_only_hidden_from_stranger(self):
        # friends-only visibility applies to plain text entries too
        entry_uuid = uuid.uuid4()
        fqid = f"http://testserver/api/authors/{self.a.uuid}/entries/{entry_uuid}"
        Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=self.a.fqid,
            content="secret plain text",
            content_type="text/plain",
            visibility=Entry.Visibility.FRIENDS,
            is_deleted=False,
        )
        stranger_u = self.make_user("stranger")
        self.make_author_for_user(stranger_u)
        self.client.login(username="stranger", password="pass12345")
        resp = self.client.get(f"/authors/{self.a.uuid}/entries/{entry_uuid}/")
        self.assertEqual(resp.status_code, 404)