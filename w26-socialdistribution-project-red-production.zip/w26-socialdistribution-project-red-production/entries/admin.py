from django.contrib import admin
from .models import Entry, Like, Comment


@admin.register(Entry)
class EntryAdmin(admin.ModelAdmin):
    """
    Admin panel for managing entries (posts + hosted images)

    NODE_ADMIN.1 requirement: node admins need to be able to browse and
    manage image entries so their users can host images for CommonMark posts.

    Key admin capabilities here:
      - Filter by content_type to find image entries quickly
      - Filter by visibility and is_deleted
      - Search by title, author fqid, or entry fqid
      - Soft-delete entries via a custom bulk action (sets is_deleted=True,
        visibility=DELETED) instead of removing from the database, since the
        spec says deleted entries stay in the db
      - Read-only fqid/uuid so admins can't accidentally break stable URLs
        (IDENTITY-AUTHOR.1: URLs must stay stable)
    """

    # columns shown in the list view
    list_display = (
        "title",
        "author_fqid",
        "visibility",
        "content_type",
        "published",
        "is_deleted",
    )

    # sidebar filters
    list_filter = ("visibility", "content_type", "is_deleted")

    # text search across these fields
    search_fields = ("title", "author_fqid", "fqid")

    # these fields are identity fields — should never be edited by admin
    # (changing them would break IDENTITY-AUTHOR.1 stable URL guarantee)
    readonly_fields = ("uuid", "fqid", "published", "updated")

    # default sort: newest first
    ordering = ("-published",)

    # custom bulk action: soft delete instead of hard delete
    actions = ["soft_delete_selected"]

    def soft_delete_selected(self, request, queryset):
        """
        Bulk soft-delete: marks entries as deleted (hides from UI/API)
        without removing them from the database.

        The spec requires deleted entries stay in the DB so the node admin
        can review them. This is safer than Django's default hard delete.
        """
        count = 0
        for entry in queryset:
            if not entry.is_deleted:
                entry.soft_delete()
                count += 1
        self.message_user(request, f"Soft-deleted {count} entr{'y' if count == 1 else 'ies'}.")

    soft_delete_selected.short_description = "Soft-delete selected entries (keeps in DB)"


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    """
    Admin panel for comments. Node admins can inspect and remove comments
    on entries hosted on this node.
    """
    list_display = ("author_fqid", "entry_fqid", "content_type", "published")
    list_filter = ("content_type",)
    search_fields = ("author_fqid", "entry_fqid", "comment")
    readonly_fields = ("uuid", "fqid", "published")
    ordering = ("-published",)


@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    """
    Admin panel for likes. Useful to audit who liked what on this node.
    """
    list_display = ("author_fqid", "object_fqid", "published")
    search_fields = ("author_fqid", "object_fqid", "fqid")
    readonly_fields = ("uuid", "fqid", "published")
    ordering = ("-published",)
