from django.urls import path
from . import views

# paths
urlpatterns = [
    path("stream/", views.stream_view, name="stream"),
    path("entries/create/", views.create_entry, name="create_entry"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/", views.entry_detail, name="entry_detail"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/edit/", views.edit_entry, name="edit_entry"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/delete/", views.delete_entry, name="delete_entry"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/like/", views.toggle_entry_like, name="toggle_entry_like"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/comments/create/", views.create_comment, name ="create_comment"),
    path("authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/comments/<uuid:comment_uuid>/like/",views.toggle_comment_like,name="toggle_comment_like"),
    path("api/authors/<uuid:author_uuid>/entries/<uuid:entry_uuid>/image", views.entry_image, name="entry_image"),
]
