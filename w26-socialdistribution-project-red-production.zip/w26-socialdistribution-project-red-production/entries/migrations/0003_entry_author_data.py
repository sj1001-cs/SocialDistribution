from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("entries", "0002_alter_entry_options_comment_like"),
    ]

    operations = [
        migrations.AddField(
            model_name="entry",
            name="author_data",
            field=models.JSONField(blank=True, null=True),
        ),
    ]
