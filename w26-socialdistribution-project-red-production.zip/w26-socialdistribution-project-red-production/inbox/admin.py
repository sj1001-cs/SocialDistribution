from django.contrib import admin
from .models import InboxItem
admin.site.register(InboxItem)

# Register your models here.
