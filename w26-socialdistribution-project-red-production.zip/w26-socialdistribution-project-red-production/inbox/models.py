from django.db import models
import uuid

# Create your models here.

class InboxItem(models.Model):
    """
    Used for node-to-node communication
    This model represents a single object deliviered to a local author

    Remote nodes will POST new objects (-> e.g. entries, likes,
    comments, follows) to an authors inbox endpoint
    
    Inbox stores the raw JSON exactly as recieved 
    """
    class ItemType(models.TextChoices):
        ENTRY = "entry"
        COMMENT = "comment"
        LIKE = "like"
        FOLLOW = "follow"

    ## Internal UUID for db tracking, FQID of author receiving
    uuid = models.UUIDField(default=uuid.uuid4,editable=False, unique=True)
    recipient_author_fqid = models.URLField(db_index=True)
    item_type = models.CharField(max_length=20, choices=ItemType.choices)
    object_fqid = models.URLField(blank=True, null=True) #distributed ID fo the object itself (entry,comment,like)

    # Full raw JSON as received form the remote node
    raw_json = models.JSONField() 
    # whether his inbox item has been processed into local db models
    processed = models.BooleanField(default = True) 
    # time stamp of receipt
    received_at = models.DateTimeField(auto_now_add=True)

    # the latest
    class Meta:
        ordering = ["-received_at"]

    def __str__(self):
        return f"[{self.item_type}] sent to {self.recipient_author_fqid}"