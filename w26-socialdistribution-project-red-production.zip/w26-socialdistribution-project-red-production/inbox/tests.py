from django.test import TestCase

from inbox.models import InboxItem


class InboxItemModelTests(TestCase):
    def make_item(self, **overrides):
        """
        helper function so each test only overrides the fields relevant to
        the behaviour it is checking
        """
        payload = {
            "recipient_author_fqid": "http://testserver/api/authors/alice",
            "item_type": InboxItem.ItemType.ENTRY,
            "object_fqid": "http://testserver/api/authors/alice/entries/1",
            "raw_json": {"type": "entry", "id": "http://testserver/api/authors/alice/entries/1"},
        }
        payload.update(overrides)
        return InboxItem.objects.create(**payload)

    def test_inbox_item_defaults_processed_to_true(self):
        item = self.make_item()

        # The model defaults processed=True until an API view chooses otherwise
        self.assertTrue(item.processed)

    def test_inbox_items_are_ordered_newest_first(self):
        older = self.make_item(object_fqid="http://testserver/api/authors/alice/entries/1")
        newer = self.make_item(object_fqid="http://testserver/api/authors/alice/entries/2")

        # should return the most recently received inbox item first.
        items = list(InboxItem.objects.all())
        self.assertEqual(items, [newer, older])

    def test_inbox_item_string_representation_includes_type_and_recipient(self):
        item = self.make_item(item_type=InboxItem.ItemType.FOLLOW)

        # test that a follow was made to the correct fqid
        self.assertEqual(str(item), "[follow] sent to http://testserver/api/authors/alice")
