from django.shortcuts import render,redirect



def landing_view(request):
    
    """
    Shows the landing page at http://yournodeurl/
    If the user is already logged in, redirect them to their stream
    """

    if request.user.is_authenticated:
         return redirect('/stream/')

    return render(request, 'landing.html')