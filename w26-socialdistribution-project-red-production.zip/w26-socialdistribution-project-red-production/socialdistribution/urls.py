"""
URL configuration for socialdistribution project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from . import views 

urlpatterns = [
    # /admin/ --> Django's built in admin panel
    # This is where node admins can manage authors, approve accounts, etc.
    path('admin/', admin.site.urls),
    # "" means the root URL --> pulls in ALL urls from authors/urls.py
    # include() means "go look in authors/urls.py for the rest of the URL"
    path("", include("authors.urls")),

    path("", include("entries.urls")), # stream + entries related sauce

    path('', views.landing_view, name='landing'),   # landing page

    path("api/", include("api.urls")),
]
