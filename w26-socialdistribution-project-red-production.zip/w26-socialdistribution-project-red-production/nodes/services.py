import requests
from requests.auth import HTTPBasicAuth

from .models import Node


def normalize_url(url: str) -> str:
    return (url or "").strip().rstrip("/")


def find_node_for_fqid(fqid: str):
    """
    Return the configured Node whose host matches the given fqid.
    Example:
        fqid = https://jd-node-b-xxxxx.herokuapp.com/api/authors/<uuid>
    should match the Node with host/api_base on that Heroku app.
    """
    fqid = normalize_url(fqid)

    for node in Node.objects.filter(is_active=True, allow_outgoing=True):
        host = normalize_url(node.host)
        api_base = normalize_url(node.api_base)

        if host and fqid.startswith(host):
            return node
        if api_base and fqid.startswith(api_base):
            return node

    return None


def post_to_author_inbox(node: Node, recipient_author_fqid: str, payload: dict):
    """
    POST a JSON payload to a remote author's inbox using HTTP Basic Auth.
    recipient_author_fqid should look like:
        https://remote-node/api/authors/<uuid>
    inbox URL becomes:
        https://remote-node/api/authors/<uuid>/inbox/
    Falls back to no trailing slash if the first attempt returns 405.
    """
    recipient_author_fqid = normalize_url(recipient_author_fqid)
    auth = HTTPBasicAuth(node.username, node.password)

    resp = requests.post(
        f"{recipient_author_fqid}/inbox/",
        json=payload,
        auth=auth,
        timeout=15,
    )
    if resp.status_code == 405:
        resp = requests.post(
            f"{recipient_author_fqid}/inbox",
            json=payload,
            auth=auth,
            timeout=15,
        )
    return resp