from django.db import models

# Create your models here.

class Node(models.Model):
    """
    Stores a remote node we can communicate with for Part 3 distribution.
    """

    host = models.URLField(unique=True)
    api_base = models.URLField(blank=True)
    username = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    is_active = models.BooleanField(default=True)
    allow_incoming = models.BooleanField(default=True)
    allow_outgoing = models.BooleanField(default=True)

    def __str__(self):
        return self.host