import json
import uuid
from urllib.parse import quote
from django.test import TestCase, Client
from django.contrib.auth.models import User

from authors.models import Author, FollowRequest, Follower
from entries.models import Entry

# Create your tests here.

class AuthorsFlowTests(TestCase):
   """End-to-end tests for core author authentication flows.


   Covers:
   - Registration creates an inactive User and unapproved Author (admin approval needed)
   - Login is blocked when Author is not approved
   - Login succeeds when both User is active and Author is approved
   - Logout redirects away from the authenticated area


   These tests map to node-management and identity user stories related to
   account creation and approval gating.
   """


   def test_register_creates_inactive_user_and_unapproved_author(self):
       """POST /register/ creates an inactive Django User and unapproved Author.


       Expected:
       - Redirect (302) on success
       - New user is_active=False
       - New author is_approved=False
       - Author FQID/web fields are initialized (not placeholders)
       """
       resp = self.client.post("/register/", data={
           "username": "newuser",
           "password": "pass12345",
           "display_name": "New User",
       })


       self.assertEqual(resp.status_code, 302)


       u = User.objects.get(username="newuser")
       self.assertFalse(u.is_active)


       a = Author.objects.get(user=u)
       self.assertFalse(a.is_approved)
       self.assertNotEqual(a.fqid, "placeholder")
       self.assertIn("/api/authors/", a.fqid)
       self.assertTrue(a.web)


   def test_register_rejects_missing_fields(self):
       """
       POST /register/ re-renders form when required fields are missing.
       """
       resp = self.client.post("/register/", data={
           "username": "",
           "password": "pass12345",
           "display_name": "X",
       })
       self.assertEqual(resp.status_code, 200)
       self.assertFalse(User.objects.filter(username="").exists())


   def test_login_blocks_unapproved_author_even_if_password_correct(self):
       """
       POST /login/ should not authenticate if Author is not approved (even if User is active).
       """
       u = User.objects.create_user(username="alice", password="pass12345", is_active=True)
       Author.objects.create(
           user=u,
           display_name="Alice",
           host="http://testserver/api/",
           fqid="http://testserver/api/authors/alice",
           is_approved=False,
       )


       resp = self.client.post("/login/", data={"username": "alice", "password": "pass12345"})
       self.assertEqual(resp.status_code, 200)
       self.assertFalse(resp.wsgi_request.user.is_authenticated)


   def test_login_succeeds_when_user_active_and_author_approved(self):
       """
       POST /login/ should redirect when both User is active and Author is approved.
       """
       u = User.objects.create_user(username="alice", password="pass12345", is_active=True)
       Author.objects.create(
           user=u,
           display_name="Alice",
           host="http://testserver/api/",
           fqid="http://testserver/api/authors/alice",
           is_approved=True,
       )


       resp = self.client.post("/login/", data={"username": "alice", "password": "pass12345"})
       self.assertEqual(resp.status_code, 302)


   def test_logout_redirects_to_login(self):
       """
       GET /logout/ logs out and redirects (302).
       """
       u = User.objects.create_user(username="alice", password="pass12345", is_active=True)
       Author.objects.create(
           user=u,
           display_name="Alice",
           host="http://testserver/api/",
           fqid="http://testserver/api/authors/alice",
           is_approved=True,
       )
       self.client.login(username="alice", password="pass12345")


       resp = self.client.get("/logout/")
       self.assertEqual(resp.status_code, 302)


class ProfileViewTests(TestCase):
   """Tests for the public profile page rendering.


   Validates that only PUBLIC + non-deleted entries appear on an author's public profile page.
   """


   def make_author(self, username: str, approved=True, active=True):
       """Create a local approved Author tied to a Django User."""
       u = User.objects.create_user(username=username, password="pass12345", is_active=active)
       a = Author.objects.create(
           user=u,
           display_name=username,
           host="http://testserver/api/",
           fqid=f"http://testserver/api/authors/{username}",
           is_approved=approved,
       )
       return u, a


   def test_profile_page_shows_only_public_non_deleted_entries(self):
       """
       Profile page should show PUBLIC entries only and exclude FRIENDS + deleted entries.
      
       """
       _, a = self.make_author("alice")
       url = f"/authors/{a.uuid}/"


       Entry.objects.create(
           uuid=uuid.uuid4(),
           fqid="http://testserver/api/authors/alice/entries/1",
           author_fqid=a.fqid,
           content="pub",
           content_type="text/plain",
           visibility=Entry.Visibility.PUBLIC,
           is_deleted=False,
       )
       Entry.objects.create(
           uuid=uuid.uuid4(),
           fqid="http://testserver/api/authors/alice/entries/2",
           author_fqid=a.fqid,
           content="friends",
           content_type="text/plain",
           visibility=Entry.Visibility.FRIENDS,
           is_deleted=False,
       )
       Entry.objects.create(
           uuid=uuid.uuid4(),
           fqid="http://testserver/api/authors/alice/entries/3",
           author_fqid=a.fqid,
           content="deleted",
           content_type="text/plain",
           visibility=Entry.Visibility.PUBLIC,
           is_deleted=True,
       )


       resp = self.client.get(url)
       self.assertEqual(resp.status_code, 200)
       html = resp.content.decode()


       self.assertIn("pub", html)
       self.assertNotIn("friends", html)
       self.assertNotIn("deleted", html)




class EditProfileTests(TestCase):
   """Tests for editing author profile fields via the API.


   Confirms:
   - UI route requires login
   - API author update endpoint persists updates to display name, description, github, profile image
   """


   def make_author(self, username: str, approved=True, active=True):
       """Create a local Author with editable fields set."""
       u = User.objects.create_user(username=username, password="pass12345", is_active=active)
       a = Author.objects.create(
           user=u,
           display_name=username,
           host="http://testserver/api/",
           fqid=f"http://testserver/api/authors/{username}",
           is_approved=approved,
           description="old",
           github="",
       )
       return u, a


   def test_edit_profile_requires_login(self):
       """
       GET /profile/edit/ redirects if not logged in.
       """
       resp = self.client.get("/profile/edit/")
       self.assertEqual(resp.status_code, 302)


   def test_edit_profile_updates_fields(self):
       """
       PUT /api/authors/<uuid>/ updates profile fields and persists them in DB.
      
       """
       _, a = self.make_author("alice", approved=True, active=True)
       self.client.login(username="alice", password="pass12345")


       resp = self.client.put(
           f"/api/authors/{a.uuid}/",
           data=json.dumps({
               "displayName": "Alice Updated",
               "description": "new desc",
               "github": "https://github.com/alice",
               "profileImage": "https://example.com/pic.png",
           }),
           content_type="application/json",
       )
       self.assertEqual(resp.status_code, 200)


       a.refresh_from_db()
       self.assertEqual(a.display_name, "Alice Updated")
       self.assertEqual(a.description, "new desc")
       self.assertEqual(a.github, "https://github.com/alice")
       self.assertEqual(a.profile_image, "https://example.com/pic.png")




class FollowRequestFlowTests(TestCase):
   """Tests for follow request lifecycle through API and UI routes.


   Covers:
   - Creating a pending follow request via following API
   - Viewing pending requests page
   - Accepting requests (creates follower + marks accepted)
   - Rejecting requests (marks rejected + does not create follower)
   """


   def make_author(self, username: str, approved=True, active=True):
       """
       Create a local approved Author tied to a Django User.
       """
       u = User.objects.create_user(username=username, password="pass12345", is_active=active)
       a = Author.objects.create(
           user=u,
           display_name=username,
           host="http://testserver/api/",
           fqid=f"http://testserver/api/authors/{username}",
           is_approved=approved,
       )
       return u, a


   def test_send_follow_request_creates_pending_request(self):
       """
       PUT /api/authors/<me>/following/<target_fqid>/ creates a pending FollowRequest.
       """
       _, bob_a = self.make_author("bob")
       _, alice_a = self.make_author("alice")


       self.client.login(username="bob", password="pass12345")


       resp = self.client.put(
           f"/api/authors/{bob_a.uuid}/following/{quote(alice_a.fqid, safe='')}/"
       )
       self.assertIn(resp.status_code, (200, 201))


       fr = FollowRequest.objects.get(requester_fqid=bob_a.fqid, target=alice_a)
       self.assertEqual(fr.status, FollowRequest.Status.PENDING)


   def test_cannot_follow_self(self):
       """
       Following yourself should not create a FollowRequest.
       """
       _, alice_a = self.make_author("alice")
       self.client.login(username="alice", password="pass12345")


       resp = self.client.post(f"/authors/{alice_a.uuid}/follow/")
       self.assertEqual(resp.status_code, 302)
       self.assertFalse(FollowRequest.objects.filter(target=alice_a, requester_fqid=alice_a.fqid).exists())


   def test_follow_requests_view_lists_pending_for_target(self):
       """
       GET /follow-requests/ shows pending follow requests for the logged-in target author.
       """
       _, bob_a = self.make_author("bob")
       _, alice_a = self.make_author("alice")


       FollowRequest.objects.create(requester_fqid=bob_a.fqid, requester_data=bob_a.to_json(), target=alice_a)


       self.client.login(username="alice", password="pass12345")
       resp = self.client.get("/follow-requests/")
       self.assertEqual(resp.status_code, 200)
       self.assertIn("bob", resp.content.decode())


   def test_accept_follow_request_marks_accepted_and_creates_follower(self):
       """
       PUT /api/authors/<target>/followers/<requester_fqid>/ accepts and creates a follower row.
       """
       _, bob_a = self.make_author("bob")
       _, alice_a = self.make_author("alice")


       fr = FollowRequest.objects.create(
           requester_fqid=bob_a.fqid,
           requester_data=bob_a.to_json(),
           target=alice_a,
           status=FollowRequest.Status.PENDING,
       )


       self.client.login(username="alice", password="pass12345")


       resp = self.client.put(
           f"/api/authors/{alice_a.uuid}/followers/{quote(bob_a.fqid, safe='')}/"
       )
       self.assertEqual(resp.status_code, 200)


       fr.refresh_from_db()
       self.assertEqual(fr.status, FollowRequest.Status.ACCEPTED)
       self.assertTrue(Follower.objects.filter(author=alice_a, follower_fqid=bob_a.fqid).exists())


   def test_reject_follow_request_marks_rejected_and_does_not_create_follower(self):
       """
       DELETE /api/authors/<target>/followers/<requester_fqid>/ rejects a pending request.
       """
       _, bob_a = self.make_author("bob")
       _, alice_a = self.make_author("alice")


       fr = FollowRequest.objects.create(
           requester_fqid=bob_a.fqid,
           requester_data=bob_a.to_json(),
           target=alice_a,
           status=FollowRequest.Status.PENDING,
       )


       self.client.login(username="alice", password="pass12345")


       resp = self.client.delete(
           f"/api/authors/{alice_a.uuid}/followers/{quote(bob_a.fqid, safe='')}/"
       )
       self.assertEqual(resp.status_code, 200)


       fr.refresh_from_db()
       self.assertEqual(fr.status, FollowRequest.Status.REJECTED)
       self.assertFalse(Follower.objects.filter(author=alice_a, follower_fqid=bob_a.fqid).exists())

class NodeAdminHostMultipleAuthorsTest(TestCase):
   """Tests the ability for a node to host multiple local authors (node admin story).


   User story:
   IDENTITY-NODE_ADMIN.1:
   "As a node admin, I want to host multiple authors on my node, so I can have a friendly online community."
   """


   def setUp(self):
       """Initialize a separate client and a default API host string."""
       self.client = Client()
       self.host = "http://testserver/api/"


   def _make_author(self, username, approved=True):
       """Helper to create an Author with a unique FQID and an associated User."""
       user = User.objects.create_user(
           username=username,
           password="testpass123",
           is_active=approved
       )
       author = Author.objects.create(
           user=user,
           display_name=username,
           host=self.host,
           fqid=f"{self.host}authors/{username}",
           is_approved=approved
       )
       return author


   def test_multiple_authors_can_exist(self):
       """
       Multiple authors can be created and stored simultaneously.
       """
       self._make_author("alice")
       self._make_author("bob")
       self._make_author("carol")
       self.assertEqual(Author.objects.count(), 3)


   def test_each_author_has_unique_fqid(self):
       """
       Each author must have a unique FQID (global identifier).
       """
       self._make_author("alice")
       self._make_author("bob")
       fqids = list(Author.objects.values_list("fqid", flat=True))
       self.assertEqual(len(fqids), len(set(fqids)))


   def test_unapproved_author_cannot_login(self):
       """
       Unapproved authors should not be able to login (approval gating).
       """
       self._make_author("pending_user", approved=False)
       logged_in = self.client.login(username="pending_user", password="testpass123")
       self.assertFalse(logged_in)


   def test_approved_author_can_login(self):
       """
       Approved authors should be able to login.
       """
       self._make_author("approved_user", approved=True)
       logged_in = self.client.login(username="approved_user", password="testpass123")
       self.assertTrue(logged_in)


   def test_api_returns_all_approved_authors(self):
       """
       GET /api/authors/ returns only approved authors in this node.
       """
       self._make_author("alice")
       self._make_author("bob")
       self._make_author("pending", approved=False)
       response = self.client.get("/api/authors/")
       self.assertEqual(response.status_code, 200)
       data = response.json()
       self.assertEqual(data["type"], "authors")
       self.assertEqual(len(data["authors"]), 2)


   def test_api_author_objects_have_required_fields(self):
       """
       Author objects returned by API contain required fields.
       """
       self._make_author("alice")
       response = self.client.get("/api/authors/")
       author_data = response.json()["authors"][0]
       self.assertEqual(author_data["type"], "author")
       self.assertIn("id", author_data)
       self.assertIn("host", author_data)
       self.assertIn("displayName", author_data)
       self.assertIn("github", author_data)
       self.assertIn("profileImage", author_data)


   def test_api_author_fqid_is_full_url(self):
       """
       Author 'id' should be a full URL, not a local integer.
       """
       self._make_author("alice")
       response = self.client.get("/api/authors/")
       author_data = response.json()["authors"][0]
       self.assertTrue(author_data["id"].startswith("http"))
       self.assertIn("authors/", author_data["id"])


   def test_admin_approval_activates_user(self):
       """
       Approving an author should activate the linked Django User.
       """
       author = self._make_author("pending", approved=False)
       self.assertFalse(author.user.is_active)
       author.is_approved = True
       author.user.is_active = True
       author.user.save()
       author.save()
       author.refresh_from_db()
       self.assertTrue(author.is_approved)
       self.assertTrue(author.user.is_active)