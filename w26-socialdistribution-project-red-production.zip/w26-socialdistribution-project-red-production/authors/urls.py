from django.urls import path
from . import views

urlpatterns = [
    path("register/", views.register, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("authors/<uuid:author_uuid>/", views.profile, name="profile"),
    path("profile/edit/", views.edit_profile, name="edit_profile"),
    path("authors/<uuid:author_uuid>/follow/", views.send_follow_request, name="follow_author"),
    path("authors/<uuid:author_uuid>/unfollow/", views.unfollow_author, name="unfollow_author"),
    path("authors/<uuid:author_uuid>/follow_requests/cancel/",views.cancel_follow_request,name="cancel_follow_request",),
    path("authors/follow_requests/cancel-by-fqid/",views.cancel_follow_request_by_fqid,name="cancel_follow_request_by_fqid"),
    path("authors/<uuid:author_uuid>/connections/", views.connections_view, name="connections"),
    path("follow-requests/", views.follow_requests_view, name="follow_requests"),
    path("follow-requests/<uuid:request_uuid>/accept/", views.accept_follow_request, name="accept_follow_request"),
    path("follow-requests/<uuid:request_uuid>/reject/", views.reject_follow_request, name="reject_follow_request"),
    path("follow/by-fqid/", views.send_follow_request_by_fqid, name="send_follow_request_by_fqid"),
    
    #path("api/authors/", views.api_get_authors, name="api_authors"),
    #path("api/authors/<uuid:author_uuid>/", views.api_author_detail, name="api_author_detail"),

    path('discover/', views.discover_view, name='discover'),
]
