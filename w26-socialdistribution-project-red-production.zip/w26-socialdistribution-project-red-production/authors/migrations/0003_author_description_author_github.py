from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("authors", "0002_author_is_approved_author_user_followrequest_and_more"),
    ]

    operations = [
        migrations.AddField(
            model_name="author",
            name="description",
            field=models.TextField(blank=True, default=""),
        ),
        migrations.AddField(
            model_name="author",
            name="github",
            field=models.URLField(blank=True, default=""),
        ),
    ]
