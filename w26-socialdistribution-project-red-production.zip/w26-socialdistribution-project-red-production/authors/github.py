"""
Pulls public GitHub activity for an author and turns it into
entries on their profile.
"""
from __future__ import annotations

import uuid
import requests

from entries.models import Entry


GITHUB_EVENT_SOURCE = "github-event:"

SUPPORTED_EVENTS = {
    "PushEvent",
    "CreateEvent",
    "WatchEvent",
    "ForkEvent",
    "IssuesEvent",
    "PullRequestEvent",
    "PublicEvent",
}


def _extract_username(github_url: str) -> str | None:
    if not github_url:
        return None
    parts = github_url.rstrip("/").split("/")
    return parts[-1] if parts else None


def _event_to_title_and_body(event: dict) -> tuple[str, str]:
    etype = event.get("type", "")
    repo = event.get("repo", {}).get("name", "unknown/repo")
    payload = event.get("payload", {})

    if etype == "PushEvent":
        commits = payload.get("commits", [])
        count = len(commits)
        msgs = "\n".join(f"- {c['message']}" for c in commits[:5])
        return (
            f"Pushed {count} commit(s) to {repo}",
            msgs or "No commit messages.",
        )

    if etype == "CreateEvent":
        ref_type = payload.get("ref_type", "repository")
        ref = payload.get("ref") or repo
        return (
            f"Created {ref_type} {ref} on {repo}",
            payload.get("description") or f"New {ref_type} on GitHub.",
        )

    if etype == "WatchEvent":
        return (
            f"Starred {repo}",
            f"Starred the repository {repo} on GitHub.",
        )

    if etype == "ForkEvent":
        fork = payload.get("forkee", {}).get("full_name", repo)
        return (
            f"Forked {repo}",
            f"Forked {repo} -> {fork}.",
        )

    if etype == "IssuesEvent":
        action = payload.get("action", "updated")
        title = payload.get("issue", {}).get("title", "an issue")
        return (
            f"{action.capitalize()} issue: {title}",
            f'{action.capitalize()} issue "{title}" on {repo}.',
        )

    if etype == "PullRequestEvent":
        action = payload.get("action", "updated")
        title = payload.get("pull_request", {}).get("title", "a PR")
        return (
            f"{action.capitalize()} PR: {title}",
            f'{action.capitalize()} pull request "{title}" on {repo}.',
        )

    if etype == "PublicEvent":
        return (
            f"Made {repo} public",
            f"The repository {repo} is now public on GitHub.",
        )

    return (
        f"GitHub activity on {repo}",
        f"Event type: {etype} on {repo}.",
    )


def sync_github_activity(author) -> list[Entry]:
    """
    Hits the GitHub API for the author's public events and creates
    a PUBLIC entry for each new one.

    Returns the list of newly created entries.
    """
    username = _extract_username(author.github)
    if not username:
        return []

    try:
        resp = requests.get(
            f"https://api.github.com/users/{username}/events/public",
            headers={"Accept": "application/vnd.github+json"},
            timeout=5,
        )
        resp.raise_for_status()
        events = resp.json()
    except Exception:
        return []

    if not isinstance(events, list):
        return []

    created_entries = []
    host = author.host.rstrip("/").removesuffix("/api")

    for event in events:
        etype = event.get("type")
        if etype not in SUPPORTED_EVENTS:
            continue

        event_id = str(event.get("id", ""))
        if not event_id:
            continue

        description = f"{GITHUB_EVENT_SOURCE}{event_id}"

        if Entry.objects.filter(
            author_fqid=author.fqid,
            description=description,
        ).exists():
            continue

        title, content = _event_to_title_and_body(event)
        entry_uuid = uuid.uuid4()
        fqid = f"{host}/api/authors/{author.uuid}/entries/{entry_uuid}"

        entry = Entry.objects.create(
            uuid=entry_uuid,
            fqid=fqid,
            author_fqid=author.fqid,
            title=title,
            description=description,
            content=content,
            content_type="text/plain",
            visibility=Entry.Visibility.PUBLIC,
        )
        created_entries.append(entry)

    return created_entries