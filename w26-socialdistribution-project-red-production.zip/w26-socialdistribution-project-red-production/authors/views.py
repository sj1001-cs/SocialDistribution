from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt  
from django.core.paginator import Paginator           
from django.http import JsonResponse          
from django.urls import reverse   
from urllib.parse import urlparse     
import json   

from urllib.parse import quote

from entries.models import Entry, Comment, Like
from .models import Author, Follower, FollowRequest
from nodes.services import find_node_for_fqid, post_to_author_inbox, normalize_url
import requests
from requests.auth import HTTPBasicAuth
from nodes.models import Node


# Create your views here.
def register(request):
    """
    Registration page for new authors.
    Creates a Django User and Author object.
    Author is not approved until admin approves.
    """
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()
        display_name = request.POST.get("display_name", "").strip()

        # Basic validation
        if not username or not password or not display_name:
            messages.error(request, "All fields are required.")
            return render(request, "authors/register.html")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return render(request, "authors/register.html")

        # Create the Django User (inactive until approved)
        user = User.objects.create_user(
            username=username,
            password=password,
            is_active=False  # cant log in until admin approves
        )

        # Build the host URL from the request
        host = request.build_absolute_uri("/api/")

        # Create the Author object
        # We use a placeholder fqid for now, will be set properly after save
        author = Author.objects.create(
            user=user,
            display_name=display_name,
            host=host,
            fqid="placeholder",  # temporary
            is_approved=False
        )

        # Now set the real fqid using the author's uuid
        author.fqid = f"{host}authors/{author.uuid}"
        author.web = request.build_absolute_uri(f"/authors/{author.uuid}")
        author.save()

        messages.success(request, "Account created! Wait for admin approval before logging in.")
        return redirect("login")

    return render(request, "authors/register.html")


def login_view(request):
    """
    Login page.
    Only approved authors can log in.
    """
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        user = authenticate(request, username=username, password=password)

        if user is None:
            existing_user = User.objects.filter(username=username).first()
            if existing_user and existing_user.check_password(password):
                try:
                    author = existing_user.author
                    if not author.is_approved:
                        messages.error(request, "Your account is pending admin approval.")
                        return render(request, "authors/login.html")
                except Author.DoesNotExist:
                    messages.error(request, "Your account is missing an author profile.")
                    return render(request, "authors/login.html")

            messages.error(request, "Invalid username or password.")
            return render(request, "authors/login.html")

        try:
            author = user.author
        except Author.DoesNotExist:
            messages.error(request, "Your account is missing an author profile.")
            return render(request, "authors/login.html")

        if not author.is_approved:
            messages.error(request, "Your account is pending admin approval.")
            return render(request, "authors/login.html")

        login(request, user)
        next_url = request.POST.get("next") or request.GET.get("next") or "stream"
        return redirect(next_url)

    next_url = request.GET.get("next", "")
    return render(request, "authors/login.html", {"next": next_url})


def logout_view(request):
    """Logs the user out and redirects to login page."""
    logout(request)
    return redirect("login")


def profile(request, author_uuid):
    """
    Public profile page for an author
    Shows the author's info and their public entries
    """
    author = get_object_or_404(Author, uuid=author_uuid)
    profile_comments = Comment.objects.filter(author_fqid=author.fqid).order_by("-published")[:50]

    viewer = None
    is_self = False
    is_following = False
    pending_request = False
    is_friend = False
    viewer_fqid = None
    author_fqid = author.fqid.rstrip("/")

    followers_list = []
    following_list = []
    friends_list = []

    if request.user.is_authenticated and hasattr(request.user, "author"):
        try:
            viewer = request.user.author
            viewer_fqid = viewer.fqid.rstrip("/")
        except Author.DoesNotExist:
            viewer = None
            viewer_fqid = None

        is_self = (viewer is not None and viewer.uuid == author.uuid)

        if not is_self and viewer is not None:
            is_following = Follower.objects.filter(
                author=author,
                follower_fqid=viewer_fqid,
            ).exists()

            pending_request = FollowRequest.objects.filter(
                requester_fqid=viewer_fqid,
                target=author,
                status=FollowRequest.Status.PENDING,
            ).exists()

            is_friend = viewer.is_friends_with(author_fqid)

            # If this is a remote author and our DB still says pending,
            # ask the remote node directly whether we are already a follower.
            if pending_request and not author.is_local():
                node = find_node_for_fqid(author_fqid)

                if node:
                    try:
                        encoded_viewer_fqid = quote(viewer_fqid, safe="")
                        auth = HTTPBasicAuth(node.username, node.password)

                        resp = requests.get(
                            f"{author_fqid}/followers/{encoded_viewer_fqid}/",
                            auth=auth,
                            timeout=6,
                        )
                        if resp.status_code == 405:
                            resp = requests.get(
                                f"{author_fqid}/followers/{encoded_viewer_fqid}",
                                auth=auth,
                                timeout=6,
                            )

                        if 200 <= resp.status_code < 300:
                            Follower.objects.update_or_create(
                                author=author,
                                follower_fqid=viewer_fqid,
                                defaults={"follower_data": viewer.to_json()},
                            )

                            FollowRequest.objects.filter(
                                requester_fqid=viewer_fqid,
                                target=author,
                            ).update(status=FollowRequest.Status.ACCEPTED)

                            is_following = True
                            pending_request = False
                            is_friend = viewer.is_friends_with(author_fqid)

                    except Exception as exc:
                        print("REMOTE FOLLOW CHECK FAILED:", exc)

        elif is_self:
            follower_fqids = list(author.follower_fqids())
            following_fqids = list(author.following_fqids())
            friend_fqids = list(author.friend_fqids())

            followers_list = [_display_author_from_fqid(fqid) for fqid in follower_fqids]
            following_list = [_display_author_from_fqid(fqid) for fqid in following_fqids]
            friends_list = [_display_author_from_fqid(fqid) for fqid in friend_fqids]

    # Follower/following counts — try the remote node for remote authors, fall back to local DB
    local_followers_count = Follower.objects.filter(author=author).count()
    followers_count = local_followers_count
    following_count = None  # only shown if we can fetch it

    if not author.is_local() and not is_self:
        node = find_node_for_fqid(author_fqid)
        if node:
            auth = HTTPBasicAuth(node.username, node.password)
            # Try followers count
            try:
                resp = requests.get(f"{author_fqid}/followers/", auth=auth, timeout=5)
                if resp.ok:
                    data = resp.json()
                    items = data.get("followers") or data.get("items") or []
                    followers_count = len(items)
            except Exception:
                pass
            # Try following count
            try:
                resp = requests.get(f"{author_fqid}/following/", auth=auth, timeout=5)
                if resp.ok:
                    data = resp.json()
                    items = data.get("following") or data.get("items") or []
                    following_count = len(items)
            except Exception:
                pass

    visible = [Entry.Visibility.PUBLIC]
    if is_self:
        visible = [Entry.Visibility.PUBLIC, Entry.Visibility.UNLISTED, Entry.Visibility.FRIENDS]
    elif is_friend:
        visible = [Entry.Visibility.PUBLIC, Entry.Visibility.UNLISTED, Entry.Visibility.FRIENDS]
    elif is_following:
        visible = [Entry.Visibility.PUBLIC, Entry.Visibility.UNLISTED]

    entries = Entry.objects.filter(
        author_fqid=author.fqid,
        visibility__in=visible,
        is_deleted=False,
    ).order_by("-published")

    entries = list(entries)
    for e in entries:
        e.like_count = Like.objects.filter(object_fqid=e.fqid).count()
        e.liked_by_me = (
            viewer is not None
            and Like.objects.filter(object_fqid=e.fqid, author_fqid=viewer.fqid).exists()
        )

    return render(
        request,
        "authors/profile.html",
        {
            "author": author,
            "entries": entries,
            "is_self": is_self,
            "is_following": is_following,
            "pending_request": pending_request,
            "is_friend": is_friend,
            "followers_count": followers_count,
            "following_count": following_count,
            "followers_list": followers_list,
            "following_list": following_list,
            "friends_list": friends_list,
            "profile_comments": profile_comments,
        },
    )



@login_required
def edit_profile(request):
    try:
        author = request.user.author
    except Author.DoesNotExist:
        messages.error(request, "Your account is missing an author profile.")
        return redirect("login")

    if request.method == "POST":
        author.display_name = request.POST.get("display_name", author.display_name).strip()
        author.description = request.POST.get("description", author.description or "").strip()
        author.github = request.POST.get("github", author.github or "").strip()
        author.profile_image = request.POST.get("profile_image", author.profile_image or "").strip()
        author.save()

        _broadcast_author_update(author)

        messages.success(request, "Profile updated.")
        return redirect("profile", author_uuid=author.uuid)

    return render(request, "authors/edit_profile.html", {"author": author})


def _author_payload(author: Author) -> dict:
    return {
        "type": "author",
        "id": author.fqid,
        "host": author.host,
        "displayName": author.display_name,
        "description": author.description or "",
        "github": author.github or "",
        "profileImage": author.profile_image or "",
        "url": author.fqid,
        "web": author.web or "",
    }


def _broadcast_author_update(author: Author):
    remote_fqids = set()

    remote_fqids.update(fqid.rstrip("/") for fqid in author.follower_fqids())
    remote_fqids.update(fqid.rstrip("/") for fqid in author.following_fqids())

    remote_fqids.update(
        fqid.rstrip("/")
        for fqid in FollowRequest.objects.filter(requester_fqid=author.fqid)
        .values_list("target__fqid", flat=True)
    )

    payload = {
        "type": "author_update",
        "summary": f"{author.display_name} updated their profile",
        "author": _author_payload(author),
    }

    for remote_fqid in remote_fqids:
        node = find_node_for_fqid(remote_fqid)
        if not node:
            continue

        try:
            post_to_author_inbox(node, remote_fqid, payload)
        except Exception as e:
            print("AUTHOR UPDATE PUSH FAILED:", e)


def _send_remote_follow(me: Author, foreign_fqid: str):
    foreign_fqid = (foreign_fqid or "").rstrip("/")
    node = find_node_for_fqid(foreign_fqid)
    if not node:
        raise ValueError("No configured remote node matches that author FQID.")

    target_local = Author.objects.filter(fqid=foreign_fqid).first()
    if target_local:
        object_payload = _author_payload(target_local)
    else:
        object_payload = {
            "type": "author",
            "id": foreign_fqid,
            "url": foreign_fqid,
            "host": "/".join(foreign_fqid.split("/")[:3]) + "/api/",
            "displayName": "",
            "github": "",
            "profileImage": "",
            "web": foreign_fqid,
        }

    payload = {
        "type": "follow",
        "summary": f"{me.display_name} wants to follow you",
        "actor": _author_payload(me),
        "object": object_payload,
    }

    return post_to_author_inbox(node, foreign_fqid, payload)


def _display_author_from_fqid(fqid: str):
    """
    Return a local Author if present, otherwise a small object built from
    cached follower/requester JSON.
    """
    local = Author.objects.filter(fqid=fqid).first()
    if local:
        return local

    follower_record = Follower.objects.filter(follower_fqid=fqid).exclude(
        follower_data__isnull=True
    ).first()
    if follower_record and follower_record.follower_data:
        data = follower_record.follower_data
        return {
            "fqid": fqid,
            "display_name": data.get("displayName") or fqid,
            "github": data.get("github", ""),
            "profile_image": data.get("profileImage", ""),
            "web": data.get("web") or data.get("url") or fqid,
            "is_remote_stub": True,
        }

    request_record = FollowRequest.objects.filter(requester_fqid=fqid).exclude(
        requester_data__isnull=True
    ).first()
    if request_record and request_record.requester_data:
        data = request_record.requester_data
        return {
            "fqid": fqid,
            "display_name": data.get("displayName") or fqid,
            "github": data.get("github", ""),
            "profile_image": data.get("profileImage", ""),
            "web": data.get("web") or data.get("url") or fqid,
            "is_remote_stub": True,
        }

    return {
        "fqid": fqid,
        "display_name": fqid,
        "github": "",
        "profile_image": "",
        "web": fqid,
        "is_remote_stub": True,
    }


def get_or_create_remote_author_stub(fqid: str) -> Author:
    fqid = fqid.rstrip("/")

    existing = Author.objects.filter(fqid=fqid).first()
    if existing:
        return existing

    parsed = urlparse(fqid)
    host = f"{parsed.scheme}://{parsed.netloc}/"

    return Author.objects.create(
        fqid=fqid,
        host=host,
        display_name=fqid,  
        web=fqid,
        is_approved=False,
        user=None,
    )

@login_required
@require_POST
def send_follow_request(request, author_uuid):
    """
    Existing local UI follow, but now remote-aware if the target Author row
    is a cached remote author.
    """
    me = request.user.author
    target = get_object_or_404(Author, uuid=author_uuid)

    if me.uuid == target.uuid:
        messages.error(request, "You cannot follow yourself.")
        return redirect("profile", author_uuid=author_uuid)

    # Remote cached author -> send to remote inbox
    if not target.is_local():
        try:
            resp = _send_remote_follow(me, target.fqid)
        except Exception as exc:
            messages.error(request, f"Failed to contact remote node: {exc}")
            return redirect("profile", author_uuid=author_uuid)

        if 200 <= resp.status_code < 300:
            messages.success(request, "Remote follow request sent.")
            FollowRequest.objects.update_or_create(
                requester_fqid=me.fqid,
                target=target,
                defaults={
                    "requester_data": me.to_json(),
                    "status": FollowRequest.Status.PENDING,
                },
            )
            # Create a Follower record so the stream can show their unlisted/friends entries.
            # This is optimistic — if the remote node requires manual approval we'll
            # reconcile on the next profile load (the pending-check block in profile view).
            Follower.objects.get_or_create(
                author=target,
                follower_fqid=me.fqid,
                defaults={"follower_data": target.to_json()},
            )
        else:
            messages.error(
                request,
                f"Remote node rejected follow request ({resp.status_code})."
            )
        return redirect("profile", author_uuid=author_uuid)

    # Local target -> keep existing behavior
    follow_request, created = FollowRequest.objects.get_or_create(
        requester_fqid=me.fqid,
        target=target,
        defaults={"requester_data": me.to_json()},
    )

    if not created:
        follow_request.status = FollowRequest.Status.PENDING
        follow_request.requester_data = me.to_json()
        follow_request.save()

    messages.success(request, "Follow request sent.")
    return redirect("profile", author_uuid=author_uuid)

@login_required
def follow_requests_view(request):
    me = request.user.author
    requests = FollowRequest.objects.filter(
        target=me,
        status=FollowRequest.Status.PENDING,
    ).order_by("-created_at")

    following_fqids = me.following_fqids()
    for req in requests:
        req.already_following = req.requester_fqid in following_fqids

    return render(
        request,
        "authors/follow_requests.html",
        {"follow_requests": requests},
    )


@login_required
@require_POST
def accept_follow_request(request, request_uuid):
    follow_request = get_object_or_404(
        FollowRequest,
        uuid=request_uuid,
        target=request.user.author,
        status=FollowRequest.Status.PENDING,
    )

    follow_request.status = FollowRequest.Status.ACCEPTED
    follow_request.save(update_fields=["status"])

    Follower.objects.get_or_create(
        author=follow_request.target,
        follower_fqid=follow_request.requester_fqid,
        defaults={"follower_data": follow_request.requester_data},
    )

    requester_fqid = follow_request.requester_fqid.rstrip("/")
    requester_node = find_node_for_fqid(requester_fqid)

    if requester_node:
        payload = {
            "type": "follow_accepted",
            "summary": f"{follow_request.target.display_name} accepted your follow request.",
            "actor": follow_request.target.to_json(),
            "object": {
                "type": "author",
                "id": requester_fqid,
            },
        }

        try:
            post_to_author_inbox(requester_node, requester_fqid, payload)
        except Exception as e:
             print("REMOTE FOLLOW ACCEPT FAILED:", e)

    messages.success(request, "Follow request accepted.")
    return redirect("follow_requests")

@login_required
@require_POST
def reject_follow_request(request, request_uuid):
    follow_request = get_object_or_404(
        FollowRequest,
        uuid=request_uuid,
        target=request.user.author,
        status=FollowRequest.Status.PENDING,
    )

    follow_request.status = FollowRequest.Status.REJECTED
    follow_request.save(update_fields=["status"])

    messages.success(request, "Follow request rejected.")
    return redirect("follow_requests")


@login_required
@require_POST
def unfollow_author(request, author_uuid):
    me = request.user.author
    target = get_object_or_404(Author, uuid=author_uuid)

    Follower.objects.filter(
        author=target,
        follower_fqid=me.fqid,
    ).delete()

    messages.success(request, "You unfollowed this author.")
    return redirect("profile", author_uuid=author_uuid)

@login_required
@require_POST
def cancel_follow_request(request, author_uuid):
    me = request.user.author
    target = get_object_or_404(Author, uuid=author_uuid)

    follow_request = FollowRequest.objects.filter(
        requester_fqid=me.fqid,
        target=target,
        status=FollowRequest.Status.PENDING,
    ).first()

    if not follow_request:
        messages.error(request, "No pending follow request found.")
        return redirect(request.POST.get("next") or "discover")

    follow_request.delete()
    return redirect(request.POST.get("next") or "discover")

@login_required
def connections_view(request, author_uuid):
    author = get_object_or_404(Author, uuid=author_uuid)

    if not hasattr(request.user, "author") or request.user.author.uuid != author.uuid:
        messages.error(request, "You can only view your own connections.")
        return redirect("profile", author_uuid=author.uuid)

    follower_fqids = list(author.follower_fqids())
    following_fqids = list(author.following_fqids())
    friend_fqids = list(author.friend_fqids())

    followers_list = [_display_author_from_fqid(fqid) for fqid in follower_fqids]
    following_list = [_display_author_from_fqid(fqid) for fqid in following_fqids]
    friends_list = [_display_author_from_fqid(fqid) for fqid in friend_fqids]

    return render(
        request,
        "authors/connections.html",
        {
            "author": author,
            "followers_list": followers_list,
            "following_list": following_list,
            "friends_list": friends_list,
        },
    )


@login_required
@require_POST
def send_follow_request_by_fqid(request):
    """
    UI endpoint for remote follow/follow-back using a raw FQID string.
    """

    me = request.user.author
    foreign_fqid = (request.POST.get("foreign_fqid") or "").strip().rstrip("/")
    next_url = request.POST.get("next") or request.META.get("HTTP_REFERER") or "/"

    if not foreign_fqid:
        messages.error(request, "Missing remote author URL.")
        return redirect(next_url)

    if foreign_fqid == me.fqid.rstrip("/"):
        messages.error(request, "You cannot follow yourself.")
        return redirect(next_url)

    # If we already have them locally, and they are local-local, use the old path
    target = Author.objects.filter(fqid=foreign_fqid).first()
    if not target:
        target = get_or_create_remote_author_stub(foreign_fqid)
    if target and target.is_local():
        follow_request, created = FollowRequest.objects.get_or_create(
            requester_fqid=me.fqid,
            target=target,
            defaults={"requester_data": me.to_json()},
        )
        if not created:
            follow_request.status = FollowRequest.Status.PENDING
            follow_request.requester_data = me.to_json()
            follow_request.save()
        messages.success(request, "Follow request sent.")
        return redirect(next_url)

    # Otherwise treat it as remote
    try:
        resp = _send_remote_follow(me, foreign_fqid)
    except Exception as exc:
        messages.error(request, f"Failed to contact remote node: {exc}")
        return redirect(next_url)

    if 200 <= resp.status_code < 300:
        FollowRequest.objects.update_or_create(
            requester_fqid=me.fqid,
            target=target,
            defaults={
                "requester_data": me.to_json(),
                "status": FollowRequest.Status.ACCEPTED,
            },
        )
        Follower.objects.get_or_create(
            author=target,
            follower_fqid=me.fqid,
        )
        messages.success(request, "Remote follow request sent.")
    else:
        messages.error(request, f"Remote node rejected follow request ({resp.status_code}).")

    return redirect(next_url)

@login_required
@require_POST
def cancel_follow_request_by_fqid(request):
    me = request.user.author
    foreign_fqid = (request.POST.get("foreign_fqid") or "").strip().rstrip("/")
    next_url = request.POST.get("next") or request.META.get("HTTP_REFERER") or reverse("discover")

    if not foreign_fqid:
        messages.error(request, "Missing remote author URL.")
        return redirect(next_url)

    target = Author.objects.filter(fqid=foreign_fqid).first()
    if not target:
        messages.error(request, "Remote author not found locally.")
        return redirect(next_url)

    follow_request = FollowRequest.objects.filter(
        requester_fqid=me.fqid,
        target=target,
        status=FollowRequest.Status.PENDING,
    ).first()

    if not follow_request:
        messages.error(request, "No pending follow request found.")
        return redirect(next_url)

    follow_request.delete()
    return redirect(next_url)


@login_required
def discover_view(request):
    """
    GET /discover/

    Shows all authors the logged-in user can follow:
      - Local authors on this node (excluding themselves)
      - Remote authors fetched live from all active connected nodes
    """
    

    me = request.user.author

    local_authors = Author.objects.filter(
        is_approved=True,
        user__isnull=False,
    ).exclude(uuid=me.uuid).order_by("display_name")

    following_fqids = me.following_fqids()

    pending_fqids = set(
        FollowRequest.objects.filter(
            requester_fqid=me.fqid,
            status=FollowRequest.Status.PENDING,
        ).values_list("target__fqid", flat=True)
    )

    remote_authors = []
    seen_remote_ids = set()
    nodes = Node.objects.filter(is_active=True, allow_outgoing=True)

    for node in nodes:
        try:
            base = normalize_url(node.api_base) or normalize_url(node.host)
            if not base:
                print(f"DISCOVER SKIP: node {node} has no usable host/api_base")
                continue
            
            url = f"{base}/authors/"
            resp = requests.get(
                url,
                auth=HTTPBasicAuth(node.username, node.password),
                headers={"Accept":"application/json"},
                timeout=8,
            )
            # if resp.ok:
            #     data = resp.json()
            #     authors = data.get("authors", [])
            #     if authors:
            #         remote_authors.append({
            #             "host": node.host,
            #             "authors": authors,
            #         })
            resp.raise_for_status()

            data = resp.json()

            if isinstance(data, dict):
                authors = data.get("authors") or data.get("items") or []
            elif isinstance(data, list):
                authors = data
            else:
                authors = []

            cleaned_authors = []
            for author in authors:
                author_id = normalize_url(author.get("id") or author.get("url") or "")
                if not author_id:
                    continue

                if author_id == normalize_url(me.fqid):
                    continue

                if author_id in seen_remote_ids:
                    continue

                seen_remote_ids.add(author_id)

                cleaned_authors.append({
                    "id": author_id,
                    "displayName": author.get("displayName") or author.get("display_name") or "Unknown",
                    "profileImage": author.get("profileImage") or author.get("profile_image") or "",
                    "host": author.get("host") or node.host,
                    "github": author.get("github") or "",
                    "web": author.get("web") or author_id,
                })
            if cleaned_authors:
                remote_authors.append({
                    "host": node.host,
                    "authors": cleaned_authors,
                })

        except Exception as e:
            print(f"DISCOVER FETCH FAILED for node {node.host}: {e}")

    return render(request, "authors/discover.html", {
        "me": me,
        "local_authors": local_authors,
        "remote_authors": remote_authors,
        "following_fqids": following_fqids,
        "pending_fqids": pending_fqids,
        "nodes": nodes,
    })