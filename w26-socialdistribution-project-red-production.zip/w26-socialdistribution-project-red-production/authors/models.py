from django.db import models
import uuid

from django.contrib.auth.models import User

# Create your models here.
class Author(models.Model):
    """
    Author: represents both local and remote authors

    Every author is uniquely identified by their fqid,
    which is the full URL of the author object.

    e.g --> http://node1/api/authors/1234

    NOTICE:
    LOCAL authors also have a linked Django User (for login).
    REMOTE authors do NOT have a linked User --> come from
    other nodes via the inbox --> perhaps store here for caching
    """

    # Internal uuid for our local db use only
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique = True)
    # FQID --> This must be globally unique across all nodes
    fqid = models.URLField(unique=True)
    host = models.URLField() # base api rule of the authors homef node
    # Display name chosen be an author
    display_name = models.CharField(max_length=255)
    # URL to the authors profile image 
    profile_image = models.URLField(blank=True, null=True, max_length=2048)
    web = models.URLField(blank=True,null=True) # html profile  page
    created_at = models.DateTimeField(auto_now_add = True)
    github = models.URLField(blank=True, default="", max_length=2048)
    description = models.TextField(blank=True, default="")


    # How do we know if a user is logged in without doing all the hashing and observer nonsense?
    # ANS: this chunk of code
    #   --> Links to Django's built-in User model for LOCAL authors only
    #   --> null=True means remote authors don't need a User account.
    #   --> creates a reverse one-to-one relation between author & user
    user = models.OneToOneField( # each author can be linked to one django user
        User, 
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="author",
    )

    # True = local author approved by admin --> log in and post
    # False = pending approval OR this is a remote author (no login needed)
    is_approved = models.BooleanField(default=False)
    
    def __str__(self) -> str:
        return f"{self.display_name} ({self.fqid})"


    def is_local(self):
        """Returns True if this author belongs to our node"""
        return self.user is not None

    def following_fqids(self):
        return set(
            Follower.objects.filter(follower_fqid=self.fqid).values_list(
                "author__fqid", flat=True
            )
        )

    def follower_fqids(self):
        return set(
            Follower.objects.filter(author=self).values_list("follower_fqid", flat=True)
        )

    def friend_fqids(self):
        return self.following_fqids() & self.follower_fqids()

    def is_following(self, author_fqid):
        return author_fqid in self.following_fqids()

    def is_followed_by(self, author_fqid):
        return author_fqid in self.follower_fqids()

    def is_friends_with(self, author_fqid):
        return author_fqid in self.friend_fqids()

    # DO NOT REMOVE UNLESS YOU ARE WILLING TO DEAL WITH THE CONSEQUENCES
    # IT GIVES US DATA ABOUT AN AUTHOR WITHOUT HAVING TO DO MULTIPLE LOOK UPS
    def to_json(self):
        """
        Returns the author as a dict hopefully matching the API spec.
        Used when building JSON responses.
        """
        return {
            "type": "author",
            "id": self.fqid,
            "host": self.host,
            "displayName": self.display_name,
            "github": self.github or "",
            "profileImage": self.profile_image or "",
            "web": self.web or "",
        }




class FollowRequest(models.Model):
    """
    A request from one author to follow another.

    requester  = WANTS to follow someone
    target = author being followed

    The target is always local because remote nodes POST
    follow requests to our inbox probs. Thus, we are probs always the target.
    *assuming i read things correctly teehee*

    States:
        PENDING  --> waiting for approve/deny from target
        ACCEPTED --> accepted follow request
        REJECTED --> rejected follow request
    """

    class Status(models.TextChoices):
        PENDING  = "PENDING"
        ACCEPTED = "ACCEPTED"
        REJECTED = "REJECTED"

    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True) #universal id

    # Full URL of the author who wants to follow (may be remote)
    requester_fqid = models.URLField()

    # requester's json info --> do not need to call the entire node for their info
    requester_data = models.JSONField(null=True, blank=True)

    # The LOCAL author being followed
    target = models.ForeignKey(
        Author,
        on_delete=models.CASCADE,
        related_name="follow_requests_received"
    )

    status = models.CharField(
        max_length=10,
        choices=Status.choices,
        default=Status.PENDING
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        # Only one follow request per (requester,target) pair at a time
        unique_together = ("requester_fqid", "target")
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.requester_fqid} → {self.target.display_name} [{self.status}]"


class Follower(models.Model):
    """
    An ACCEPTED follow relationship.

    author        = the LOCAL author being followed
    follower_fqid = the full URL of whoever is following them
                    (can be local OR remote)

    CREATED WHEN a FollowRequest is accepted.

    Example: Tj (remote, node2) follows Jinny (local, node1)
        author        = Jinny
        follower_fqid = "http://node2/api/authors/Tj or http://node2/authors/Tj" --> idk yet

    Two authors are FRIENDS when they have a Follower record
    for each other 
    """

    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    # The local author who is being followed
    # Basically, the target from followRequest
    author = models.ForeignKey(
        Author,
        on_delete=models.CASCADE,
        related_name="followers"
    )

    # Full URL of whoever is following them (local or remote)
    # Basically, the requester from followRequest
    follower_fqid = models.URLField()

    # requester's/follower's author JSON
    follower_data = models.JSONField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        # One follow per pair. no dups
        unique_together = ("author", "follower_fqid")
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.follower_fqid} follows {self.author.display_name}"

    def is_friend(self):
        """
        Returns True if this follow is mutual.
        --> author also follows follower_fqid back.
        """
        return Follower.objects.filter(
            author__fqid=self.follower_fqid,
            follower_fqid=self.author.fqid
        ).exists()