from django.contrib import admin
from .models import Author,FollowRequest,Follower
# admin.site.register(Author)

admin.site.register(FollowRequest)
admin.site.register(Follower)
# Register your models here.
from django.contrib import admin
from .models import Author, FollowRequest, Follower

# Used to help auto do approval process
@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display  = ("display_name", "fqid", "is_approved", "created_at")
    list_filter   = ("is_approved",)
    search_fields = ("display_name", "fqid")


    def save_model(self, request, obj, form, change):
        """
        When admin approves an author (sets is_approved=True),
        also set the linked Django User to is_active=True so
        they can actually log in. authenticate() refuses inactive users.
        """
        if obj.user:
            obj.user.is_active = obj.is_approved
            obj.user.save()
        super().save_model(request, obj, form, change)


# The following is used to help searching in admin panel, but for now i commented them out simplicity
# @admin.register(FollowRequest)
# class FollowRequestAdmin(admin.ModelAdmin):
#     list_display  = ("requester_fqid", "target", "status", "created_at")
#     list_filter   = ("status",)


# @admin.register(Follower)
# class FollowerAdmin(admin.ModelAdmin):
#     list_display = ("follower_fqid", "author", "created_at")